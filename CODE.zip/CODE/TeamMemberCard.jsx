import React, { useState } from 'react';
import { Check, Loader2, Save, ShieldCheck, ShieldOff, UserCheck, UserX } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import RoleBadge from '@/components/RoleBadge';
import { userRole } from '@/lib/roles';

function initials(name) {
  return (name || 'U')
    .split(' ')
    .map((part) => part[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
}

/** One team member: name, role, client group, account status and branch-admin rights. */
export default function TeamMemberCard({ record, borrowers, groups, onSave, saving }) {
  const [name, setName] = useState(record.full_name || '');
  const [saved, setSaved] = useState(false);
  const role = userRole(record);
  const disabled = record.account_status === 'disabled';
  const isAdmin = record.role === 'admin';
  const dirty = name.trim() !== (record.full_name || '').trim();

  const centers = Array.isArray(record.assigned_groups)
    ? record.assigned_groups
    : record.assigned_group
      ? [record.assigned_group]
      : [];

  const toggleCenter = (group) => {
    const next = centers.includes(group)
      ? centers.filter((name) => name !== group)
      : [...centers, group];
    save({ assigned_groups: next, assigned_group: next[0] || '' });
  };

  const save = async (patch) => {
    setSaved(false);
    await onSave(record, patch);
    setSaved(true);
  };

  const saveName = async () => {
    if (!name.trim()) return;
    await save({ full_name: name.trim() });
  };

  return (
    <div className={`rounded-2xl border bg-card p-3.5 ${disabled ? 'border-dashed opacity-80' : 'border-border'}`}>
      <div className="flex items-center gap-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[11px] font-semibold text-primary">
          {initials(record.full_name)}
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium">{record.full_name || record.email}</p>
          <p className="truncate text-[11px] text-muted-foreground">{record.email}</p>
        </div>
        <RoleBadge user={record} size="sm" />
      </div>

      <div className="mt-3 flex gap-2">
        <Input
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder="Full name"
          className="h-9"
        />
        <Button
          type="button"
          size="sm"
          variant={dirty ? 'default' : 'outline'}
          onClick={saveName}
          disabled={!dirty || saving}
          className="h-9 shrink-0"
        >
          {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
        </Button>
      </div>

      <div className="mt-2 grid gap-2 sm:grid-cols-2">
        <Select
          value={role}
          onValueChange={(value) => save({ staff_role: value })}
          disabled={saving}
        >
          <SelectTrigger className="h-9">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="manager">Branch manager</SelectItem>
            <SelectItem value="account_officer">Account officer</SelectItem>
            <SelectItem value="client">Client</SelectItem>
          </SelectContent>
        </Select>

        {role === 'client' && (
          <Select
            value={record.borrower_id || ''}
            onValueChange={(value) => save({ borrower_id: value })}
            disabled={saving}
          >
            <SelectTrigger className="h-9">
              <SelectValue placeholder="Link client record" />
            </SelectTrigger>
            <SelectContent>
              {borrowers.map((borrower) => (
                <SelectItem key={borrower.id} value={borrower.id}>
                  {borrower.borrower_no} · {borrower.full_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        {role === 'account_officer' && (
          <div className="sm:col-span-2">
            <p className="text-[11px] font-medium text-muted-foreground">Centers handled</p>
            <div className="mt-1.5 max-h-40 space-y-0.5 overflow-y-auto rounded-xl border border-border p-1.5">
              {groups.map((group) => (
                <label
                  key={group}
                  className="flex cursor-pointer items-center gap-2 rounded-lg px-1.5 py-1 text-xs transition hover:bg-muted/60"
                >
                  <input
                    type="checkbox"
                    checked={centers.includes(group)}
                    onChange={() => toggleCenter(group)}
                    disabled={saving}
                    className="h-3.5 w-3.5 accent-[hsl(var(--primary))]"
                  />
                  <span className="truncate">{group}</span>
                </label>
              ))}
              {!groups.length && (
                <p className="px-1.5 py-1 text-[11px] text-muted-foreground">
                  No client center on file yet.
                </p>
              )}
            </div>
            <p className="mt-1 text-[10px] text-muted-foreground">
              Only checked centers — and the clients in them — show in this officer's window.
            </p>
          </div>
        )}
      </div>

      {role === 'account_officer' && centers.length > 0 && (
        <p className="mt-2 text-[11px] text-muted-foreground">
          {centers.length} center{centers.length === 1 ? '' : 's'} assigned — files the CI and
          recommendation for these clients.
        </p>
      )}

      <div className="mt-3 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => save({ account_status: disabled ? 'active' : 'disabled' })}
          disabled={saving}
          className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[11px] font-medium transition ${
            disabled
              ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
              : 'border-border text-muted-foreground hover:bg-muted'
          }`}
        >
          {disabled ? <UserCheck className="h-3.5 w-3.5" /> : <UserX className="h-3.5 w-3.5" />}
          {disabled ? 'Enable account' : 'Disable account'}
        </button>

        <button
          type="button"
          onClick={() => save({ role: isAdmin ? 'user' : 'admin' })}
          disabled={saving}
          className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[11px] font-medium transition ${
            isAdmin
              ? 'border-primary/30 bg-primary/10 text-primary'
              : 'border-border text-muted-foreground hover:bg-muted'
          }`}
        >
          {isAdmin ? <ShieldCheck className="h-3.5 w-3.5" /> : <ShieldOff className="h-3.5 w-3.5" />}
          {isAdmin ? 'Branch admin' : 'Make branch admin'}
        </button>
      </div>

      {saved && !saving && (
        <p className="mt-2 flex items-center gap-1 text-[11px] text-emerald-700">
          <Check className="h-3 w-3" /> Saved
        </p>
      )}
    </div>
  );
}