/** Contact number rules shared by every input in the app: 11 digits, nothing else. */

export const CONTACT_DIGITS = 11;

export const digitsOnly = (value) =>
  String(value ?? '').replace(/\D/g, '').slice(0, CONTACT_DIGITS);

export const isContactNumber = (value) =>
  new RegExp(`^\\d{${CONTACT_DIGITS}}$`).test(String(value ?? '').trim());

export const CONTACT_HINT = '11 digits only, e.g. 09171234567';

/** Field-level error message for an optional contact, or '' when it is fine. */
export function contactError(value, { required = false } = {}) {
  const raw = String(value ?? '').trim();
  if (!raw) return required ? 'Enter the 11-digit contact number.' : '';
  if (!isContactNumber(raw)) return `Contact number must be exactly ${CONTACT_DIGITS} digits.`;
  return '';
}