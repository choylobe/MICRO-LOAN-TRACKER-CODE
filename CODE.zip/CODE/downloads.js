import { base44 } from '@/api/base44Client';

/** Turns a record set into a downloadable CSV in the browser. */
export function downloadCsv(filename, columns, rows) {
  const escape = (value) => {
    const text = value === null || value === undefined ? '' : String(value);
    return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  };
  const body = [
    columns.map((column) => escape(column.label)).join(','),
    ...rows.map((row) => columns.map((column) => escape(column.value(row))).join(',')),
  ].join('\n');
  const blob = new Blob([body], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

const stamp = () => new Date().toISOString().slice(0, 10);

/** Audit log for everything, or only what happened inside the chosen dates. */
export async function downloadAuditLogs({ from, to } = {}) {
  const query = {};
  if (from || to) {
    query.occurred_at = {};
    if (from) query.occurred_at.$gte = new Date(`${from}T00:00:00`).toISOString();
    if (to) query.occurred_at.$lte = new Date(`${to}T23:59:59`).toISOString();
  }
  const page = await base44.entities.AuditLog.filter(query, { sort: '-occurred_at', limit: 1000 });
  downloadCsv(
    `audit-log-${from || 'start'}-to-${to || stamp()}.csv`,
    [
      { label: 'Date & time', value: (row) => row.occurred_at },
      { label: 'Person', value: (row) => row.actor_name },
      { label: 'Email', value: (row) => row.actor_email },
      { label: 'Role', value: (row) => row.actor_role },
      { label: 'Action', value: (row) => row.action },
      { label: 'Module', value: (row) => row.entity_type },
      { label: 'Reference', value: (row) => row.reference },
      { label: 'Details', value: (row) => row.details },
      { label: 'Amount', value: (row) => row.amount },
    ],
    page.items
  );
  return page.items.length;
}

const ROLE_FILE = {
  manager: 'managers',
  account_officer: 'account-officers',
  client: 'clients',
};

/** Team records: all managers, all account officers, or all clients. */
export async function downloadTeamRecords(scope) {
  const users = await base44.entities.User.list();
  const rows = (users || []).filter((member) => (member.staff_role || 'account_officer') === scope);
  downloadCsv(
    `${ROLE_FILE[scope] || 'team'}-${stamp()}.csv`,
    [
      { label: 'Full name', value: (row) => row.full_name },
      { label: 'Email', value: (row) => row.email },
      { label: 'System role', value: (row) => row.role },
      { label: 'Branch role', value: (row) => row.staff_role },
      { label: 'Assigned centers', value: (row) => (row.assigned_groups || []).join(' / ') },
      { label: 'Account status', value: (row) => row.account_status || 'active' },
      { label: 'Joined', value: (row) => row.created_date },
    ],
    rows
  );
  return rows.length;
}