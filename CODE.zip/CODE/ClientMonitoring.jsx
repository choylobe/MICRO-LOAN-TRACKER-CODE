import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, AlertTriangle, RotateCcw, Users, Wallet, ClipboardList } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ClientRow from '@/components/clients/ClientRow';
import { Input } from '@/components/ui/input';
import { STAGE_META, STAGE_FILTERS, computeClientProfile, sortProfiles } from '@/lib/monitoring';

function Stat({ label, value, hint, icon: Icon, tone }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-center gap-1.5 text-muted-foreground">
        <Icon className="h-3.5 w-3.5" strokeWidth={1.75} />
        <p className="text-[10px] uppercase tracking-[0.12em]">{label}</p>
      </div>
      <p className={`mt-2 font-heading text-2xl font-semibold leading-none tabular-nums ${tone || ''}`}>
        {value}
      </p>
      <p className="mt-1.5 text-[11px] text-muted-foreground">{hint}</p>
    </div>
  );
}

export default function ClientMonitoring() {
  const [profiles, setProfiles] = useState(null);
  const [stage, setStage] = useState('all');
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      const [borrowerPage, loanPage] = await Promise.all([
        base44.entities.Borrower.list({ sort: 'full_name', limit: 100 }),
        base44.entities.Loan.list({ sort: '-created_date', limit: 200 }),
      ]);
      setProfiles(sortProfiles(borrowerPage.items.map((borrower) => computeClientProfile(borrower, loanPage.items))));
    })();
  }, []);

  if (!profiles) {
    return (
      <div className="space-y-4">
        <div className="h-16 animate-pulse rounded-2xl bg-muted" />
        <div className="grid gap-3 md:grid-cols-2">
          {[0, 1, 2, 3].map((key) => (
            <div key={key} className="h-32 animate-pulse rounded-2xl bg-muted" />
          ))}
        </div>
      </div>
    );
  }

  const counts = profiles.reduce(
    (acc, profile) => ({ ...acc, [profile.stage]: (acc[profile.stage] || 0) + 1 }),
    {}
  );

  const term = search.trim().toLowerCase();
  const visible = profiles.filter((profile) => {
    if (stage !== 'all' && profile.stage !== stage) return false;
    if (!term) return true;
    return (
      profile.borrower.full_name?.toLowerCase().includes(term) ||
      profile.borrower.borrower_no?.toLowerCase().includes(term) ||
      profile.borrower.center_group?.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="font-heading text-[26px] font-semibold leading-tight">Client monitoring</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {profiles.length} clients · from application to repayment and re-application
          </p>
        </div>
        <Link
          to="/borrowers"
          className="hidden shrink-0 items-center gap-1 rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-medium text-muted-foreground hover:text-foreground md:flex"
        >
          <Users className="h-3.5 w-3.5" /> Directory
        </Link>
      </div>

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="In repayment" value={counts.repayment || 0} hint="Active loans being collected" icon={Wallet} />
        <Stat
          label="In arrears"
          value={counts.arrears || 0}
          hint="Clients with missed installments"
          icon={AlertTriangle}
          tone="text-rose-700"
        />
        <Stat
          label="Ready for re-loan"
          value={counts.reloan || 0}
          hint="Fully paid, no open loan"
          icon={RotateCcw}
          tone="text-emerald-700"
        />
        <Stat
          label="In process"
          value={(counts.application || 0) + (counts.approval || 0)}
          hint="Applications and approved loans"
          icon={ClipboardList}
        />
      </section>

      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search client, borrower no. or center"
          className="h-11 rounded-xl pl-9"
        />
      </div>

      <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1 md:mx-0 md:px-0">
        <button
          onClick={() => setStage('all')}
          className={`shrink-0 rounded-full border px-3.5 py-1.5 text-xs font-medium transition ${
            stage === 'all'
              ? 'border-primary bg-primary text-primary-foreground'
              : 'border-border bg-card text-muted-foreground hover:text-foreground'
          }`}
        >
          All clients
        </button>
        {STAGE_FILTERS.map((key) => (
          <button
            key={key}
            onClick={() => setStage(key)}
            className={`shrink-0 rounded-full border px-3.5 py-1.5 text-xs font-medium transition ${
              stage === key
                ? 'border-primary bg-primary text-primary-foreground'
                : 'border-border bg-card text-muted-foreground hover:text-foreground'
            }`}
          >
            {STAGE_META[key].label}
            {counts[key] ? ` · ${counts[key]}` : ''}
          </button>
        ))}
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        {visible.map((profile) => (
          <ClientRow key={profile.borrower.id} profile={profile} />
        ))}
      </div>

      {!visible.length && (
        <div className="rounded-2xl border border-dashed border-border p-8 text-center">
          <p className="font-heading text-base font-medium">No client in this stage</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Clear the filter, or file an application to start a new client record.
          </p>
        </div>
      )}
    </div>
  );
}