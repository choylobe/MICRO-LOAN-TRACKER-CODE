import React, { useEffect, useState } from 'react';
import { peso, disclosureFigures, INSURANCE_LABEL } from '@/lib/loan';
import {
  acceptByClient,
  acceptByCoBorrower,
  declineByClient,
  signaturesForLoan,
} from '@/lib/signatures';
import SignatureCapture from '@/components/signatures/SignatureCapture';
import SignaturePreview from '@/components/signatures/SignaturePreview';
import { Button } from '@/components/ui/button';
import { CheckCircle2, ShieldCheck, UserRound, XCircle } from 'lucide-react';

function Row({ label, value, strong }) {
  return (
    <div className="flex items-center justify-between gap-3 py-1.5">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={`tabular-nums ${strong ? 'text-sm font-semibold' : 'text-sm'}`}>{value}</span>
    </div>
  );
}

/** Client verification, touch signature, then the co-borrower countersigns the same disclosure. */
export default function DisclosureCard({ loan, user, onDone }) {
  const figures = disclosureFigures(loan);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [signatures, setSignatures] = useState([]);

  const decided = loan.client_decision;
  const clientSig = signatures.find((row) => row.signer_role === 'client');
  const coSig = signatures.find((row) => row.signer_role === 'co_borrower');

  const load = async () => {
    setSignatures(await signaturesForLoan(loan.id));
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loan.id]);

  const sign = async (payload, role) => {
    setError('');
    setSaving(true);
    try {
      if (role === 'client') {
        await acceptByClient({ loan, user, signerName: payload.name, blob: payload.blob, figures });
      } else {
        await acceptByCoBorrower({
          loan,
          user,
          signerName: payload.name,
          contactNumber: payload.contact,
          blob: payload.blob,
          figures,
        });
      }
      await load();
      await onDone?.();
    } catch (err) {
      setError('The signature could not be saved. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const decline = async () => {
    setError('');
    setSaving(true);
    try {
      await declineByClient({ loan, user, signerName: loan.borrower_name });
      await load();
      await onDone?.();
    } catch (err) {
      setError('Your response could not be saved. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="rounded-2xl border border-primary/25 bg-card p-4">
      <div className="flex items-center gap-2">
        <ShieldCheck className="h-4 w-4 text-primary" />
        <h2 className="font-heading text-base font-semibold">Loan Disclosure Agreement</h2>
      </div>
      <p className="mt-1 text-xs text-muted-foreground">
        Review your net loan proceeds. The client signs first, then the co-borrower countersigns. Only
        then does the application go to the branch manager for validation.
      </p>

      <div className="mt-3 divide-y divide-border rounded-xl bg-muted/40 px-3">
        <Row label="Principal" value={peso(figures.principal)} />
        <Row label={`Interest (${loan.interest_rate || 0}% monthly)`} value={peso(figures.interest)} />
        <Row label="Effective interest (principal + interest)" value={peso(figures.effective)} />
        <Row label={INSURANCE_LABEL} value={`− ${peso(figures.insurance)}`} />
        <Row label="Loan balance carried" value={`− ${peso(figures.balance)}`} />
        <Row label="Other deductions" value={`− ${peso(figures.deductions)}`} />
        <Row label="Net loan proceeds" value={peso(figures.net)} strong />
      </div>

      {decided === 'declined' ? (
        <div className="mt-3 flex items-start gap-2 rounded-xl bg-rose-50 px-3 py-2.5 text-xs text-rose-700">
          <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <p>Declined. Your account officer will contact you to revisit the terms.</p>
        </div>
      ) : !decided ? (
        <div className="mt-3 space-y-3">
          <SignatureCapture
            defaultName={loan.client_signature_name || user?.full_name || ''}
            buttonLabel="Accept & sign"
            busy={saving}
            onSubmit={(payload) => sign(payload, 'client')}
            hint="Your signature is stored privately and kept with this loan record."
          />
          {error && <p className="text-xs text-destructive">{error}</p>}
          <Button variant="outline" className="w-full" onClick={decline} disabled={saving}>
            Decline the terms
          </Button>
        </div>
      ) : (
        <div className="mt-3 space-y-3">
          <div className="flex items-start gap-2 rounded-xl bg-emerald-50 px-3 py-2.5 text-xs text-emerald-800">
            <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            <div>
              <p>Client accepted and signed{clientSig ? ` — ${clientSig.signer_name}` : ''}.</p>
              {clientSig?.signature_uri && (
                <SignaturePreview signatureUri={clientSig.signature_uri} label="View client signature" />
              )}
            </div>
          </div>

          {coSig ? (
            <div className="flex items-start gap-2 rounded-xl bg-emerald-50/70 px-3 py-2.5 text-xs text-emerald-800">
              <UserRound className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              <div>
                <p>Co-borrower countersigned — {coSig.signer_name}.</p>
                {coSig.signature_uri && (
                  <SignaturePreview signatureUri={coSig.signature_uri} label="View co-borrower signature" />
                )}
              </div>
            </div>
          ) : (
            <div className="rounded-xl border border-border p-3">
              <p className="mb-2 text-xs font-semibold">
                Co-borrower&apos;s signature
              </p>
              <p className="mb-2 text-[11px] text-muted-foreground">
                Hand the device to the co-borrower to countersign the same disclosure.
              </p>
              <SignatureCapture
                defaultName={loan.co_borrower_name || ''}
                buttonLabel="Co-borrower signs"
                busy={saving}
                withContact
                onSubmit={(payload) => sign(payload, 'co_borrower')}
              />
              {error && <p className="mt-2 text-xs text-destructive">{error}</p>}
            </div>
          )}

          <p className="text-[10px] text-muted-foreground">
            Submitted to the branch manager for validation once signed.
          </p>
        </div>
      )}
    </section>
  );
}