import React, { useState } from 'react';
import SignaturePad from '@/components/SignaturePad';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CONTACT_HINT, contactError, digitsOnly } from '@/lib/validation';

/** Name + touch signature box, used for the client and then the co-borrower. */
export default function SignatureCapture({
  defaultName = '',
  buttonLabel = 'Accept & sign',
  onSubmit,
  busy,
  hint,
  withContact = false,
  defaultContact = '',
}) {
  const [blob, setBlob] = useState(null);
  const [name, setName] = useState(defaultName);
  const [contact, setContact] = useState(defaultContact);
  const [error, setError] = useState('');

  const submit = () => {
    setError('');
    if (!name.trim()) return setError('Type the full name of the signer.');
    if (!blob) return setError('Please sign in the box before accepting.');
    if (withContact && contactError(contact)) return setError(contactError(contact));
    onSubmit({ name: name.trim(), blob, contact });
  };

  return (
    <div className="space-y-3">
      <div>
        <Label htmlFor="signer-name">Full name of signer</Label>
        <Input
          id="signer-name"
          value={name}
          onChange={(event) => setName(event.target.value)}
          className="mt-1.5"
        />
      </div>
      {withContact && (
        <div>
          <Label htmlFor="signer-contact">Contact number</Label>
          <Input
            id="signer-contact"
            inputMode="numeric"
            maxLength={11}
            value={contact}
            onChange={(event) => setContact(digitsOnly(event.target.value))}
            placeholder="09171234567"
            className="mt-1.5"
          />
          <p className="mt-1 text-[10px] text-muted-foreground">{CONTACT_HINT}</p>
        </div>
      )}
      <SignaturePad onChange={setBlob} />
      {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
      {error && <p className="text-xs text-destructive">{error}</p>}
      <Button className="w-full" onClick={submit} disabled={busy}>
        {busy ? 'Saving…' : buttonLabel}
      </Button>
    </div>
  );
}