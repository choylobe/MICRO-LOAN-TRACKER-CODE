import { collectionPosition } from '@/lib/loan';

export const STAGE_META = {
  arrears: {
    label: 'In arrears',
    badge: 'bg-rose-50 text-rose-700 border-rose-200',
    dot: 'bg-rose-500',
  },
  application: {
    label: 'Application',
    badge: 'bg-amber-50 text-amber-800 border-amber-200',
    dot: 'bg-amber-500',
  },
  approval: {
    label: 'For approval',
    badge: 'bg-sky-50 text-sky-800 border-sky-200',
    dot: 'bg-sky-500',
  },
  repayment: {
    label: 'In repayment',
    badge: 'bg-teal-50 text-teal-800 border-teal-200',
    dot: 'bg-teal-500',
  },
  reloan: {
    label: 'Ready for re-loan',
    badge: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    dot: 'bg-emerald-500',
  },
  rejected: {
    label: 'Rejected',
    badge: 'bg-stone-100 text-stone-600 border-stone-300',
    dot: 'bg-stone-400',
  },
  prospect: {
    label: 'Prospect',
    badge: 'bg-stone-100 text-stone-600 border-stone-300',
    dot: 'bg-stone-400',
  },
};

export const STAGE_FILTERS = ['application', 'approval', 'repayment', 'arrears', 'reloan'];

const STAGE_SORT = ['arrears', 'application', 'approval', 'repayment', 'reloan', 'prospect', 'rejected'];

const OPEN_STATUSES = ['submitted', 'under_review', 'approved', 'released'];

const loanDate = (loan) => new Date(loan.submitted_at || loan.created_date);

/** Rolls a borrower's loans, payments and schedule into one monitoring profile. */
export function computeClientProfile(borrower, loans) {
  const own = loans
    .filter((loan) => loan.borrower_id === borrower.id)
    .sort((a, b) => loanDate(b) - loanDate(a));

  const latest = own[0] || null;
  const openLoan = own.find((loan) => OPEN_STATUSES.includes(loan.status)) || null;
  const activeLoan = own.find((loan) => loan.status === 'released') || null;
  const closedLoans = own.filter((loan) => loan.status === 'closed');
  const position = activeLoan ? collectionPosition(activeLoan) : null;
  const arrears = position?.arrears || 0;

  let stage = 'prospect';
  if (latest) {
    if (activeLoan) stage = arrears > 1 ? 'arrears' : 'repayment';
    else if (['submitted', 'under_review'].includes(latest.status)) stage = 'application';
    else if (latest.status === 'approved') stage = 'approval';
    else if (latest.status === 'rejected') stage = 'rejected';
    else if (latest.status === 'closed') stage = closedLoans.length ? 'reloan' : 'prospect';
  }

  const borrowed = own.reduce((sum, loan) => sum + Number(loan.principal || 0), 0);
  const repaid = own.reduce((sum, loan) => sum + Number(loan.amount_paid || 0), 0);
  const outstanding = Number(activeLoan?.outstanding_balance || 0);
  const settled = position?.installments_paid || 0;
  const duePeriods = position?.schedule.length || 0;

  return {
    borrower,
    loans: own,
    cycles: own.length,
    latest,
    openLoan,
    activeLoan,
    position,
    arrears,
    stage,
    borrowed,
    repaid,
    outstanding,
    settled,
    duePeriods,
    nextDue: position?.next_due_date || null,
    isOverdue: arrears > 1,
    reloanFrom: closedLoans[0] || null,
    progress: borrowed > 0 && activeLoan ? Math.round((repaid / (repaid + outstanding)) * 100) : latest?.status === 'closed' ? 100 : 0,
  };
}

export function sortProfiles(profiles) {
  return [...profiles].sort((a, b) => {
    const order = STAGE_SORT.indexOf(a.stage) - STAGE_SORT.indexOf(b.stage);
    if (order !== 0) return order;
    return a.borrower.full_name.localeCompare(b.borrower.full_name);
  });
}