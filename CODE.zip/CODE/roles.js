/** Branch roles and what each one is allowed to do. */

import { base44 } from '@/api/base44Client';
import { consumePendingRole } from '@/lib/pendingRole';

export const ROLE_META = {
  manager: {
    value: 'manager',
    label: 'Branch manager',
    short: 'Manager',
    badge: 'bg-primary/10 text-primary border-primary/25',
    summary: 'Approves and releases loans · reassigns client groups · manages team roles',
    canDecide: true,
    canRecommend: false,
    canCollect: true,
  },
  account_officer: {
    value: 'account_officer',
    label: 'Account officer',
    short: 'Account officer',
    badge: 'bg-amber-100 text-amber-800 border-amber-300',
    summary: 'Screens documents, runs CI and recommends · cannot approve',
    canDecide: false,
    canRecommend: true,
    canCollect: true,
  },
  client: {
    value: 'client',
    label: 'Client',
    short: 'Client',
    badge: 'bg-sky-100 text-sky-800 border-sky-300',
    summary: 'Views their own loan only · read-only',
    canDecide: false,
    canRecommend: false,
    canCollect: false,
  },
};

/** Stored staff_role wins; otherwise platform admin maps to manager, everyone else to account officer. */
export function userRole(user) {
  const stored = user?.staff_role;
  if (stored === 'manager' || stored === 'account_officer' || stored === 'client') return stored;
  return user?.role === 'admin' ? 'manager' : 'account_officer';
}

export const roleMeta = (user) => ROLE_META[userRole(user)];

export const isClient = (user) => userRole(user) === 'client';

export const canApprove = (user) => roleMeta(user).canDecide;

export const canRecommend = (user) => roleMeta(user).canRecommend;

/**
 * Give an account that has no stored role one that matches the user record:
 * a login linked to a borrower is a client, an app admin is the branch manager,
 * and every other staff login is an account officer.
 */
export async function ensureUserRole(user) {
  if (!user?.id) return;

  // A role chosen at sign-up becomes this account's saved role on first login.
  const pending = consumePendingRole();
  if (pending && ROLE_META[pending] && pending !== user.staff_role) {
    await base44.auth.updateMe({ staff_role: pending });
    if (!user.staff_role) window.location.reload();
    return;
  }

  if (ROLE_META[user.staff_role]) return;
  const derived = user.borrower_id ? 'client' : user.role === 'admin' ? 'manager' : 'account_officer';
  await base44.auth.updateMe({ staff_role: derived });
}