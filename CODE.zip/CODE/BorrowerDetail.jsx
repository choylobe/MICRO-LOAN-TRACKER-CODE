import React from 'react';
import AsIsDiagram from '@/components/docs/AsIsDiagram';
import ToBeDiagram from '@/components/docs/ToBeDiagram';
import ContextDfd from '@/components/docs/ContextDfd';
import Level0Dfd from '@/components/docs/Level0Dfd';
import ErdDiagram from '@/components/docs/ErdDiagram';

function Section({ number, title, lead, children }) {
  return (
    <section className="space-y-4 border-t border-border pt-6">
      <div>
        <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Deliverable {number}</p>
        <h2 className="mt-1 font-heading text-xl font-semibold">{title}</h2>
        {lead && <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{lead}</p>}
      </div>
      {children}
    </section>
  );
}

function Table({ head, rows }) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-border">
      <table className="w-full min-w-[620px] text-left text-xs">
        <thead className="bg-muted/60 text-[10px] uppercase tracking-wide text-muted-foreground">
          <tr>
            {head.map((cell) => (
              <th key={cell} className="px-3 py-2 font-medium">
                {cell}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={index} className="border-t border-border/70 align-top">
              {row.map((cell, cellIndex) => (
                <td
                  key={cellIndex}
                  className={`px-3 py-2.5 leading-relaxed ${cellIndex === 0 ? 'font-medium' : 'text-foreground/80'}`}
                >
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function Blueprints() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-heading text-[26px] font-semibold leading-tight">Process blueprints</h1>
        <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
          The analysis this prototype follows: the observed branch process, the proposed workflow, the
          information flows and the data model.
        </p>
      </div>

      <Section
        number="1"
        title="The observed process and its problems"
        lead="Role: loan officer supporting branch operations for non-collateral micro-loans. The workflow covers application, credit investigation, approval, release and weekly collection at one branch."
      >
        <ol className="space-y-2 text-sm leading-relaxed">
          {[
            'A borrower walks in or is referred by a center leader and fills out a paper application form.',
            'The officer receives the folder of requirements and checks it against a printed checklist.',
            'Incomplete folders are handed back; the borrower is asked to return another day.',
            'The officer conducts a manual credit investigation — house visit, co-maker verification, income estimate.',
            'Amortization is computed in a spreadsheet and copied into a branch logbook.',
            'The folder is endorsed to the branch manager, who reviews it and signs the approval sheet.',
            'The officer requests cash from treasury, prepares the voucher, and releases the proceeds.',
            'Weekly collections are written into the borrower passbook and the officer tally sheet.',
            'Arrears are discovered only during follow-up, by phone or in person.',
          ].map((step, index) => (
            <li key={index} className="flex gap-3">
              <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[10px] font-semibold text-primary">
                {index + 1}
              </span>
              <span>{step}</span>
            </li>
          ))}
        </ol>

        <Table
          head={['Observed problem', 'Operational effect', 'System response']}
          rows={[
            [
              'Folders travel by hand between officer, manager and treasury',
              'Applications sit for days; borrowers are told to "come back"',
              'One record with a status that every role can see',
            ],
            [
              'No way to check status without asking the officer',
              'Repeated follow-up calls and counter visits consume staff time',
              'Status history and due dates visible on the loan record',
            ],
            [
              'Amortization computed in scattered spreadsheets',
              'Computation errors and inconsistent balances across copies',
              'Installments computed once, stored, and used to post payments',
            ],
            [
              'Collections recorded in passbooks and tally sheets only',
              'Arrears are found late; no branch-wide arrears view',
              'Payments post against the loan and flag arrears immediately',
            ],
          ]}
        />
      </Section>

      <Section
        number="2"
        title="BPMN 2.0 — as-is versus to-be"
        lead="The as-is model keeps every manual handoff and the rework loop; the to-be model shows what the system does on its own and what staff still decide."
      >
        <AsIsDiagram />
        <ToBeDiagram />
        <Table
          head={['As-is activity', 'To-be activity', 'Benefit']}
          rows={[
            [
              'Borrower fills out a paper application and waits without status',
              'User task: borrower/staff submits one mobile form; system saves the record as Submitted',
              'No re-encoding, no lost folders, status visible immediately',
            ],
            [
              'Officer checks a printed checklist and hands the folder back',
              'User task: officer records CI findings; system notifies the borrower of missing requirements',
              'Fewer counter trips; a documented basis for the decision',
            ],
            [
              'Manager reviews a paper folder and signs the approval sheet',
              'User task: manager decides in the app; system records the decision and starts the schedule on release',
              'Auditable approval trail, no folder queue',
            ],
            [
              'Amortization in Excel, collections in passbooks and tally sheets',
              'System task: computes the schedule, posts each payment, updates balances, flags past due',
              'Accurate balances and an instant arrears view',
            ],
          ]}
        />
      </Section>

      <Section
        number="3"
        title="Data flow diagrams"
        lead="The same information crosses the system boundary in the context diagram and is decomposed into four processes at level 0."
      >
        <ContextDfd />
        <Level0Dfd />
      </Section>

      <Section
        number="4"
        title="Entity relationship diagram"
        lead="Four entities carry the whole workflow; each data store in the level-0 diagram maps to one entity."
      >
        <ErdDiagram />
        <Table
          head={['Entity (prototype)', 'Stores', 'Relationships']}
          rows={[
            ['Borrower', 'Identity, contact, center, livelihood and co-maker', '1:M with Loan'],
            ['Loan', 'Terms, computed payable, status, balances, decisions', 'M:1 Borrower; 1:M Payment; 1:M LoanStatusHistory'],
            ['LoanStatusHistory', 'Every transition with actor, remarks and timestamp', 'M:1 Loan'],
            ['Payment', 'Receipt number, amount, date, method, resulting balance', 'M:1 Loan'],
          ]}
        />
      </Section>

      <Section
        number="5"
        title="Requirements, tests and limitations"
        lead="The prototype completes one end-to-end workflow: file an application, review it, approve and release it, then post collections and close it."
      >
        <div className="grid gap-2 text-sm md:grid-cols-2">
          {[
            'FR1 Dashboard summarising portfolio, queue and arrears',
            'FR2 Application form with computed amortization preview',
            'FR3 Loan register with status filter and search',
            'FR4 Loan record with full terms, borrower and history',
            'FR5 Officer screening and recommendation step',
            'FR6 Manager-only approval, rejection and release',
            'FR7 Collection posting that updates the balance',
            'FR8 Automatic closure when the balance reaches zero',
          ].map((item) => (
            <p key={item} className="rounded-xl border border-border bg-card px-3 py-2">
              {item}
            </p>
          ))}
        </div>

        <Table
          head={['Test case', 'Expected result', 'Actual result', 'Result']}
          rows={[
            [
              'Create transaction',
              'A valid application is saved as Submitted with computed installment',
              'Record saved, installment computed, opened on the loan page',
              'Pass',
            ],
            [
              'Retrieve transaction',
              'The saved record reappears with the same terms after reopening',
              'Found in the register by borrower name and loan number',
              'Pass',
            ],
            [
              'Update / process',
              'Screening, approval and release persist; status advances each time',
              'Status moved Submitted → Under Review → Approved → Released, with history entries',
              'Pass',
            ],
            [
              'Record collection',
              'Balance drops by the amount collected; receipt and history are added',
              'Balance and amount paid updated; payment row created',
              'Pass',
            ],
          ]}
        />

        <div className="rounded-2xl border border-border bg-card p-4 text-sm leading-relaxed">
          <p className="font-medium">Known limitations and next priorities</p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-muted-foreground">
            <li>Roles are mapped to the platform's admin (branch manager) and user (loan officer) accounts; a finer role model is next.</li>
            <li>Documents, co-maker signatures import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ChevronLeft, Plus } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import LoanCard from '@/components/loans/LoanCard';
import StagePill from '@/components/clients/StagePill';
import LifecycleTracker from '@/components/clients/LifecycleTracker';
import ShareLink from '@/components/clients/ShareLink';
import { isManager, peso } from '@/lib/loan';
import { computeClientProfile } from '@/lib/monitoring';

export default function BorrowerDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [borrower, setBorrower] = useState(null);
  const [loans, setLoans] = useState([]);
  const [missing, setMissing] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [record, loanPage] = await Promise.all([
          base44.entities.Borrower.get(id),
          base44.entities.Loan.filter({ borrower_id: id }, { sort: '-created_date', limit: 50 }),
        ]);
        setBorrower(record);
        setLoans(loanPage.items);
      } catch (err) {
        setMissing(true);
      }
    })();
  }, [id]);

  if (missing) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-8 text-center">
        <p className="font-heading text-lg font-medium">Borrower not found</p>
        <Link to="/borrowers" className="mt-2 inline-block text-sm text-primary">
          Back to borrowers
        </Link>
      </div>
    );
  }

  if (!borrower) {
    return <div className="h-40 animate-pulse rounded-2xl bg-muted" />;
  }

  const active = loans.find((loan) => loan.status === 'released');
  const totalBorrowed = loans.reduce((sum, loan) => sum + Number(loan.principal || 0), 0);
  const profile = computeClientProfile(borrower, loans);

  return (
    <div className="space-y-5">
      <Link
        to="/borrowers"
        className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground"
      >
        <ChevronLeft className="h-3.5 w-3.5" /> Borrowers
      </Link>

      <div className="rounded-2xl border border-border bg-card p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="truncate font-heading text-[24px] font-semibold leading-tight">
              {borrower.full_name}
            </h1>
            <p className="mt-1 text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
              {borrower.borrower_no} · {borrower.center_group || 'Walk-in'}
            </p>
            <p className="mt-1 text-[11px] text-muted-foreground">
              Account {borrower.account_no || '—'} · Group {borrower.group_code || '—'}
            </p>
          </div>
          {!isManager(user) && (
            <Link
              to={`/loans/new?borrower=${borrower.id}${
                profile.stage === 'reloan' && profile.reloanFrom ? `&from=${profile.reloanFrom.id}` : ''
              }`}
              className="flex shrink-0 items-center gap-1 rounded-lg bg-primary px-2.5 py-1.5 text-[11px] font-medium text-primary-foreground"
            >
              <Plus className="h-3 w-3" /> {profile.stage === 'reloan' ? 'Re-apply' : 'New loan'}
            </Link>
          )}
        </div>

        <div className="mt-3">
          <ShareLink borrowerNo={borrower.borrower_no} />
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
          <div className="rounded-xl bg-muted/50 px-3 py-2">
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Contact</p>
            <p className="mt-0.5 text-sm font-medium">{borrower.contact_number || '—'}</p>
          </div>
          <div className="rounded-xl bg-muted/50 px-3 py-2">
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Occupation</p>
            <p className="mt-0.5 truncate text-sm font-medium">{borrower.occupation || '—'}</p>
          </div>
          <div className="rounded-xl bg-muted/50 px-3 py-2">
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Monthly income</p>
            <p className="mt-0.5 text-sm font-medium tabular-nums">{peso(borrower.monthly_income)}</p>
          </div>
          <div className="rounded-xl bg-muted/50 px-3 py-2">
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Co-maker</p>
            <p className="mt-0.5 truncate text-sm font-medium">{borrower.co_maker_name || '—'}</p>
          </div>
          <div className="rounded-xl bg-muted/50 px-3 py-2">
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Address</p>
            <p className="mt-0.5 truncate text-sm font-medium">{borrower.address || '—'}</p>
          </div>
          <div className="rounded-xl bg-muted/50 px-3 py-2">
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Current balance</p>
            <p className="mt-0.5 text-sm font-medium tabular-nums">
              {active ? peso(active.outstanding_balance) : '—'}
            </p>
          </div>
        </div>

        <p className="mt-3 text-[11px] text-muted-foreground">
          {loans.length} loan record{loans.length === 1 ? '' : 's'} · {peso(totalBorrowed)} total principal
        </p>
      </div>

      <div className="rounded-2xl border border-border bg-card p-4">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h2 className="font-heading text-base font-semibold">Client journey</h2>
            <p className="mt-1 text-[11px] text-muted-foreground">
              {profile.cycles
                ? `Loan cycle ${profile.cycles} of this client · application → repayment → re-application`
                : 'No application filed yet'}
            </p>
          </div>
          <StagePill stage={profile.stage} size="sm" />
        </div>

        <div className="mt-4">
          <LifecycleTracker loan={profile.latest} />
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2">
          <div className="rounded-xl bg-muted/50 px-3 py-2">
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Loan cycles</p>
            <p className="mt-0.5 text-sm font-medium tabular-nums">{profile.cycles || '—'}</p>
          </div>
          <div className="rounded-xl bg-muted/50 px-3 py-2">
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Total repaid</p>
            <p className="mt-0.5 text-sm font-medium tabular-nums text-emerald-700">{peso(profile.repaid)}</p>
          </div>
          <div className="rounded-xl bg-muted/50 px-3 py-2">
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Arrears</p>
            <p
              className={`mt-0.5 text-sm font-medium tabular-nums ${
                profile.arrears > 1 ? 'text-rose-700' : ''
              }`}
            >
              {profile.arrears > 1 ? peso(profile.arrears) : '—'}
            </p>
          </div>
        </div>
      </div>

      <div>
        <h2 className="mb-3 font-heading text-lg font-semibold">Loan history</h2>
        <div className="grid gap-3 md:grid-cols-2">
          {loans.map((loan) => (
            <LoanCard key={loan.id} loan={loan} />
          ))}
          {!loans.length && (
            <p className="rounded-2xl border border-dashed border-border p-6 text-sm text-muted-foreground">
              No loans filed for this borrower yet.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}and e-wallet reconciliation are not captured yet.</li>
            <li>Interest is flat add-on only; declining-balance and penalty computation are planned.</li>
            <li>Collection sheets and branch reports are still read on screen rather than printed or exported.</li>
          </ul>
        </div>
      </Section>

      <p className="pb-2 text-xs text-muted-foreground">
        All names, amounts and records in this prototype are fictional.
      </p>
    </div>
  );
}