import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ClipboardCheck, FileSearch, Send } from 'lucide-react';
import StatusBadge from '@/components/loans/StatusBadge';
import { peso } from '@/lib/loan';
import { format } from 'date-fns';

const GROUPS = [
  {
    key: 'screening',
    title: 'For document screening',
    empty: 'No new applications to screen.',
    icon: FileSearch,
    match: (loan) => loan.status === 'submitted',
  },
  {
    key: 'ci',
    title: 'For CI and recommendation',
    empty: 'No credit investigations open.',
    icon: ClipboardCheck,
    match: (loan) => loan.status === 'under_review' && !loan.recommendation,
  },
  {
    key: 'forwarded',
    title: 'With the branch manager',
    empty: 'No recommendations awaiting decision.',
    icon: Send,
    match: (loan) =>
      loan.status === 'under_review' && (!!loan.recommendation || loan.client_decision === 'accepted'),
  },
];

function QueueRow({ loan }) {
  return (
    <Link
      to={`/loans/${loan.id}`}
      className="flex items-center justify-between gap-3 px-4 py-3 transition hover:bg-muted/50"
    >
      <div className="min-w-0">
        <p className="truncate text-sm font-medium">{loan.borrower_name}</p>
        <p className="truncate text-[11px] text-muted-foreground">
          {loan.loan_no} · {peso(loan.principal)}
          {loan.submitted_at ? ` · ${format(new Date(loan.submitted_at), 'd MMM')}` : ''}
        </p>
      </div>
      <div className="flex shrink-0 items-center gap-2">
        <StatusBadge status={loan.status} size="sm" />
        <ArrowRight className="h-4 w-4 text-muted-foreground" />
      </div>
    </Link>
  );
}

export default function OfficerQueue({ loans }) {
  const groups = GROUPS.map((group) => ({ ...group, items: loans.filter(group.match) }));
  const total = groups.reduce((sum, group) => sum + group.items.length, 0);

  return (
    <section>
      <div className="mb-3 flex items-end justify-between gap-3">
        <div>
          <h2 className="font-heading text-lg font-semibold">CI and recommendation queue</h2>
          <p className="text-[11px] text-muted-foreground">
            {total} application{total === 1 ? '' : 's'} on your desk
          </p>
        </div>
        <Link to="/loans" className="flex shrink-0 items-center gap-1 text-xs font-medium text-primary">
          Register <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>

      <div className="space-y-3">
        {groups.map(({ key, title, empty, icon: Icon, items }) => (
          <div key={key} className="overflow-hidden rounded-2xl border border-border bg-card">
            <div className="flex items-center justify-between gap-2 border-b border-border bg-muted/40 px-4 py-2.5">
              <div className="flex items-center gap-2">
                <Icon className="h-3.5 w-3.5 text-primary" strokeWidth={1.75} />
                <p className="text-[11px] font-medium uppercase tracking-[0.1em]">{title}</p>
              </div>
              <span className="rounded-full bg-card px-2 py-0.5 text-[11px] font-semibold tabular-nums">
                {items.length}
              </span>
            </div>
            {items.length ? (
              <div className="divide-y divide-border">
                {items.map((loan) => (
                  <QueueRow key={loan.id} loan={loan} />
                ))}
              </div>
            ) : (
              <p className="px-4 py-3 text-xs text-muted-foreground">{empty}</p>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}