import React from 'react';
import { LogOut } from 'lucide-react';

/** Sign-out button with the inactivity countdown beside it. */
export default function SignOutControl({ secondsLeft, onSignOut, compact = false }) {
  const label = `0:${String(Math.max(0, secondsLeft)).padStart(2, '0')}`;
  const urgent = secondsLeft <= 10;

  return (
    <div className="flex items-center gap-1.5">
      <span
        title="Automatic sign-out when idle"
        className={`rounded-full border px-2 py-0.5 text-[10px] font-medium tabular-nums ${
          urgent
            ? 'border-rose-300 bg-rose-50 text-rose-700'
            : 'border-border bg-muted text-muted-foreground'
        }`}
      >
        {label}
      </span>
      <button
        onClick={onSignOut}
        aria-label="Log out"
        className={
          compact
            ? 'flex h-8 w-8 items-center justify-center rounded-full border border-border text-muted-foreground transition active:scale-95'
            : 'flex items-center gap-1.5 rounded-xl border border-border px-3 py-2 text-xs font-medium text-muted-foreground transition hover:bg-muted hover:text-foreground'
        }
      >
        <LogOut className={compact ? 'h-4 w-4' : 'h-3.5 w-3.5'} strokeWidth={1.75} />
        {!compact && 'Log out'}
      </button>
    </div>
  );
}