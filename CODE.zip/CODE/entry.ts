import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

/**
 * Emails the account officer who handles the applicant's center that a client
 * has filed an application. The recipient is resolved on the server from the
 * loan's center so a caller can never choose who receives branch mail.
 */
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { loan_id } = await req.json().catch(() => ({}));
    if (!loan_id || typeof loan_id !== 'string') {
      return Response.json({ error: 'loan_id is required' }, { status: 400 });
    }

    const loan = await base44.asServiceRole.entities.Loan.get(loan_id).catch((e) =>
      e.status === 404 ? null : Promise.reject(e)
    );
    if (!loan) return Response.json({ error: 'Loan not found' }, { status: 404 });

    const staff = await base44.asServiceRole.entities.User.list();
    const centersOf = (record) =>
      (Array.isArray(record.assigned_groups) ? record.assigned_groups : []).concat(
        record.assigned_group ? [record.assigned_group] : []
      );
    const officers = staff.filter(
      (record) => record.staff_role === 'account_officer' && record.account_status !== 'disabled'
    );
    const officer =
      officers.find((record) => centersOf(record).includes(loan.center_group)) ||
      officers.find((record) => record.full_name === loan.officer_name) ||
      officers[0] ||
      null;

    if (!officer?.email) {
      return Response.json({ sent: false, reason: 'No account officer with an email on file' });
    }

    if (!loan.officer_name) {
      await base44.asServiceRole.entities.Loan.update(loan.id, { officer_name: officer.full_name || '' });
    }

    const amount = Number(loan.principal || 0).toLocaleString('en-PH', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    const body = `
      <p>Hello ${officer.full_name || officer.email},</p>
      <p><strong>${loan.borrower_name}</strong> filed a ${
        loan.application_type === 'renewal' ? 'loan renewal' : 'new loan application'
      } in the client window.</p>
      <ul>
        <li>Reference: ${loan.loan_no}</li>
        <li>Amount applied for: &#8369;${amount}</li>
        <li>Date needed: ${loan.date_needed || 'not stated'}</li>
        <li>Center / group: ${loan.center_group || 'Walk-in'}</li>
      </ul>
      <p>Open it in your account officer desk to run the credit investigation, set the interest and
      deductions, and generate the Loan Disclosure Agreement for the client's signature.</p>
    `;

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: officer.email,
      subject: `Loan application ${loan.loan_no} — ${loan.borrower_name}`,
      body,
      category: 'transactional',
    });

    return Response.json({ sent: true, to: officer.email, officer: officer.full_name || officer.email });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}