import React from 'react';
import { Frame, Lane, Task, Gateway, BpmnStart, BpmnEnd, Flow, C } from '@/components/docs/diagram';

export default function ToBeDiagram() {
  return (
    <Frame
      width={1720}
      height={900}
      caption="To-Be · the same micro-loan with the tracking system. Shaded tasks are performed automatically by the system; white tasks are still human work."
    >
      <Lane x1={20} y1={40} x2={1700} y2={240} label="Borrower" alt />
      <Lane x1={20} y1={240} x2={1700} y2={440} label="Loan officer" />
      <Lane x1={20} y1={440} x2={1700} y2={640} label="System (LoanTrack)" alt />
      <Lane x1={20} y1={640} x2={1700} y2={840} label="Branch manager" />

      <BpmnStart x={100} y={140} label="Needs a loan" />
      <Task x={250} y={140} w={160} label="Submit loan application in the mobile app" />
      <Task x={250} y={540} w={220} label="Validate fields, save loan record as Submitted, compute amortization" tone="system" />
      <Task x={470} y={340} w={180} label="Screen documents, record credit investigation result" />
      <Gateway x={640} y={340} label="Documents and CI complete?" />
      <Task x={640} y={540} w={190} label="Notify borrower of the missing requirements" tone="system" />
      <Task x={820} y={140} w={180} label="Upload the missing requirements" />
      <Task x={830} y={340} w={190} label="Submit recommendation — status Under Review" />
      <Task x={830} y={740} w={200} label="Review application and full status history" />
      <Gateway x={1030} y={740} label="Approve?" />
      <Task x={1030} y={540} w={190} label="Record rejection and notify borrower" tone="system" />
      <BpmnEnd x={1190} y={540} label="Rejected" tone="bad" />
      <Task x={1210} y={740} w={170} label="Release funds (cash or e-wallet)" />
      <Task x={1300} y={540} w={200} label="Set Released: balance, due dates, schedule active, notify borrower" tone="system" />
      <Task x={1450} y={140} w={180} label="Pay the installment on the due date (branch or field)" />
      <Task x={1450} y={340} w={180} label="Verify payment: cash count or e-wallet reference" />
      <Task x={1450} y={540} w={180} label="Post payment, update balance, issue e-receipt, flag past due" tone="system" />
      <Gateway x={1590} y={540} label="Fully paid?" />
      <BpmnEnd x={1560} y={740} label="Loan closed, statement issued" />

      <Flow points={[[116, 140], [170, 140]]} />
      <Flow points={[[250, 168], [250, 510]]} label="Online form" at={[300, 300]} />
      <Flow points={[[360, 540], [470, 540], [470, 370]]} />
      <Flow points={[[560, 340], [606, 340]]} />
      <Flow points={[[640, 366], [640, 510]]} label="No" at={[658, 440]} />
      <Flow points={[[735, 540], [820, 540], [820, 167]]} label="Request sent" at={[790, 500]} />
      <Flow points={[[730, 140], [640, 140], [640, 314]]} label="Resubmitted" at={[690, 132]} />
      <Flow points={[[674, 340], [735, 340]]} label="Yes" at={[705, 332]} />
      <Flow points={[[830, 368], [830, 710]]} label="Recommendation" at={[890, 560]} />
      <Flow points={[[930, 740], [996, 740]]} />
      <Flow points={[[1030, 714], [1030, 600], [960, 600], [960, 570]]} label="No" at={[1000, 610]} />
      <Flow points={[[1125, 540], [1174, 540]]} />
      <Flow points={[[1064, 740], [1125, 740]]} label="Yes" at={[1094, 732]} />
      <Flow points={[[1210, 710], [1210, 600], [1300, 600], [1300, 570]]} label="Funds out" at={[1250, 612]} />
      <Flow
        points={[[1300, 510], [1300, 470], [1680, 470], [1680, 140], [1540, 140]]}
        label="Due dates and balance active on the borrower's status page"
        at={[1520, 462]}
      />
      <Flow points={[[1450, 168], [1450, 314]]} />
      <Flow points={[[1450, 366], [1450, 510]]} />
      <Flow points={[[1540, 540], [1556, 540]]} />
      <Flow points={[[1590, 512], [1590, 90], [1450, 90], [1450, 124]]} label="Next due date" at={[1590, 400]} />
      <Flow points={[[1590, 568], [1590, 740], [1576, 740]]} label="Yes" at={[1612, 690]} />

      <text x={20} y={872} fontSize="9.5" fill={C.muted}>
        Legend: shaded = automated system task · white = user task · diamonds = decisions. The status page replaces all in-person follow-ups.
      </text>
    </Frame>
  );
}