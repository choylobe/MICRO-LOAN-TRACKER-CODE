import React, { useEffect, useMemo, useState } from 'react';
import { format } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { isManager } from '@/lib/loan';
import { ROLE_META } from '@/lib/roles';
import { Input } from '@/components/ui/input';
import { Search, ScrollText } from 'lucide-react';

const ROLE_LABEL = {
  manager: 'Manager',
  account_officer: 'Account officer',
  client: 'Client',
  system: 'System',
};

export default function AuditTrail() {
  const { user } = useAuth();
  const [logs, setLogs] = useState(null);
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      const page = await base44.entities.AuditLog.filter(
        {},
        { sort: '-occurred_at', limit: 200 }
      );
      setLogs(page.items);
    })();
  }, []);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return logs || [];
    return (logs || []).filter((log) =>
      `${log.actor_name} ${log.action} ${log.reference || ''} ${log.details || ''}`
        .toLowerCase()
        .includes(term)
    );
  }, [logs, search]);

  if (!isManager(user)) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-6 text-sm text-muted-foreground">
        The audit trail is available to {ROLE_META.manager.label.toLowerCase()} accounts only.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="flex items-center gap-2 font-heading text-[26px] font-semibold leading-tight">
          <ScrollText className="h-5 w-5 text-primary" /> Audit trail
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Who did what, and when — across applications, disclosures, collections and accounts.
        </p>
      </div>

      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search person, action or reference"
          className="h-11 rounded-xl pl-9"
        />
      </div>

      {!logs && (
        <div className="space-y-2">
          {[0, 1, 2].map((key) => (
            <div key={key} className="h-16 animate-pulse rounded-xl bg-muted" />
          ))}
        </div>
      )}

      {logs && (
        <div className="overflow-hidden rounded-2xl border border-border bg-card">
          {filtered.map((log) => (
            <div key={log.id} className="border-b border-border px-4 py-3 last:border-0">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{log.action}</p>
                  <p className="truncate text-[11px] text-muted-foreground">
                    {log.actor_name} · {ROLE_LABEL[log.actor_role] || 'System'}
                    {log.reference ? ` · ${log.reference}` : ''}
                  </p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-[11px] tabular-nums text-muted-foreground">
                    {log.occurred_at
                      ? format(new Date(log.occurred_at), 'd MMM yyyy, h:mm a')
                      : '—'}
                  </p>
                  {log.amount !== undefined && log.amount !== null && (
                    <p className="text-xs font-medium tabular-nums">
                      ₱{Number(log.amount).toLocaleString('en-PH', { minimumFractionDigits: 2 })}
                    </p>
                  )}
                </div>
              </div>
              {log.details && (
                <p className="mt-1 text-[11px] text-muted-foreground">{log.details}</p>
              )}
            </div>
          ))}
          {!filtered.length && (
            <p className="px-4 py-8 text-center text-sm text-muted-foreground">
              No transaction matches this search yet.
            </p>
          )}
        </div>
      )}

      <p className="text-[11px] text-muted-foreground">
        Showing the latest 200 transactions. This log is visible to the branch manager only.
      </p>
    </div>
  );
}