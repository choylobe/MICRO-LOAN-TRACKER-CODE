import React from 'react';
import { Frame, ErdEntity, Rel, C } from '@/components/docs/diagram';

export default function ErdDiagram() {
  return (
    <Frame
      width={1120}
      height={660}
      caption="ERD · BORROWER 1:M LOAN, LOAN 1:M LOAN_STATUS_HISTORY, LOAN 1:M PAYMENT, USER 1:M LOAN (officer) and USER 1:M PAYMENT (collector). PK = primary key, FK = foreign key."
    >
      <ErdEntity
        x={40}
        y={40}
        w={230}
        title="BORROWER"
        rows={[
          { name: 'borrower_id', key: 'PK' },
          { name: 'borrower_no' },
          { name: 'full_name' },
          { name: 'contact_number' },
          { name: 'address' },
          { name: 'center_group' },
          { name: 'monthly_income' },
          { name: 'co_maker_name' },
        ]}
      />

      <ErdEntity
        x={420}
        y={40}
        w={240}
        title="LOAN"
        rows={[
          { name: 'loan_id', key: 'PK' },
          { name: 'borrower_id', key: 'FK' },
          { name: 'officer_id', key: 'FK' },
          { name: 'loan_product' },
          { name: 'principal' },
          { name: 'interest_rate' },
          { name: 'term_months' },
          { name: 'status' },
          { name: 'total_payable' },
          { name: 'outstanding_balance' },
        ]}
      />

      <ErdEntity
        x={800}
        y={40}
        w={270}
        title="LOAN_STATUS_HISTORY"
        rows={[
          { name: 'history_id', key: 'PK' },
          { name: 'loan_id', key: 'FK' },
          { name: 'from_status' },
          { name: 'to_status' },
          { name: 'action' },
          { name: 'actor_name' },
          { name: 'changed_at' },
        ]}
      />

      <ErdEntity
        x={420}
        y={400}
        w={240}
        title="PAYMENT"
        rows={[
          { name: 'payment_id', key: 'PK' },
          { name: 'loan_id', key: 'FK' },
          { name: 'collected_by', key: 'FK' },
          { name: 'amount' },
          { name: 'payment_date' },
          { name: 'method' },
          { name: 'receipt_no' },
          { name: 'balance_after' },
        ]}
      />

      <ErdEntity
        x={800}
        y={400}
        w={270}
        title="USER (staff)"
        rows={[
          { name: 'user_id', key: 'PK' },
          { name: 'full_name' },
          { name: 'role' },
          { name: 'branch' },
        ]}
      />

      {/* relationships */}
      <Rel points={[[270, 120], [420, 120]]} left="1" right="M" />
      <text x={345} y={112} fontSize="9" fill={C.muted} textAnchor="middle">
        files
      </text>

      <Rel points={[[640, 100], [800, 100]]} left="1" right="M" />
      <text x={720} y={92} fontSize="9" fill={C.muted} textAnchor="middle">
        logs
      </text>

      <Rel points={[[540, 248], [540, 400]]} left="1" right="M" />
      <text x={600} y={330} fontSize="9" fill={C.muted} textAnchor="middle">
        is settled by
      </text>

      <Rel points={[[800, 480], [660, 480]]} left="1" right="M" />
      <text x={730} y={472} fontSize="9" fill={C.muted} textAnchor="middle">
        collects
      </text>

      <Rel points={[[800, 440], [740, 440], [740, 300], [610, 300], [610, 248]]} left="1" right="M" />
      <text x={700} y={292} fontSize="9" fill={C.muted} textAnchor="middle">
        handles / approves
      </text>
    </Frame>
  );
}