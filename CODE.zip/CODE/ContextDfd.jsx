import React from 'react';
import { Frame, DfdEntity, DfdProcess, DataStore, Flow, C } from '@/components/docs/diagram';

export default function ContextDfd() {
  return (
    <Frame
      width={1000}
      height={560}
      caption="Context diagram · the whole application is a single process (0). Every arrow is a named flow of information leaving or entering the system."
    >
      <rect x={380} y={200} width={240} height={140} rx={18} fill={C.greenSoft} stroke={C.green} strokeWidth="1.4" />
      <text x={500} y={255} fontSize="10" fill={C.muted} textAnchor="middle" fontWeight="700">
        0
      </text>
      <text x={500} y={278} fontSize="11.5" fill={C.ink} textAnchor="middle" fontWeight="600">
        CARD LoanTrack
      </text>
      <text x={500} y={296} fontSize="11.5" fill={C.ink} textAnchor="middle" fontWeight="600">
        Micro-Loan Tracking System
      </text>

      <DfdEntity x={130} y={110} label="Borrower" sub="external entity" />
      <DfdEntity x={130} y={450} label="Loan Officer" sub="external entity" />
      <DfdEntity x={870} y={110} label="Branch Manager" sub="external entity" />
      <DfdEntity x={870} y={450} label="Cashier / Treasury" sub="external entity" />

      <Flow points={[[200, 96], [392, 228]]} label="loan application, requirements, payments" at={[292, 148]} />
      <Flow points={[[392, 258], [200, 124]]} label="status, amortization schedule, e-receipt" at={[292, 216]} />
      <Flow points={[[200, 428], [392, 300]]} label="credit investigation findings, collections" at={[292, 372]} />
      <Flow points={[[392, 336], [200, 470]]} label="application queue, collection list" at={[292, 420]} />
      <Flow points={[[800, 96], [608, 228]]} label="approval decision, release instruction" at={[708, 148]} />
      <Flow points={[[608, 258], [800, 124]]} label="pending queue, arrears report" at={[708, 216]} />
      <Flow points={[[800, 428], [608, 300]]} label="disbursement confirmation" at={[708, 372]} />
      <Flow points={[[608, 336], [800, 470]]} label="release voucher, collection posting" at={[708, 420]} />

      <text x={20} y={540} fontSize="9" fill={C.muted}>
        Inputs are validated at entry; all stored data is returned to users as a status view, schedule or report.
      </text>
    </Frame>
  );
}