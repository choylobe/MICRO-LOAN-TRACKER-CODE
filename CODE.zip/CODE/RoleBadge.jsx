import React from 'react';
import { ClipboardCheck, ShieldCheck, UserRound } from 'lucide-react';
import { ROLE_META, userRole } from '@/lib/roles';

const ICONS = {
  manager: ShieldCheck,
  account_officer: ClipboardCheck,
  client: UserRound,
};

export default function RoleBadge({ user, size = 'default', className = '' }) {
  const role = userRole(user);
  const meta = ROLE_META[role];
  const Icon = ICONS[role];
  const compact = size === 'sm';

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border font-medium ${meta.badge} ${
        compact ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-[11px]'
      } ${className}`}
    >
      <Icon className={compact ? 'h-3 w-3' : 'h-3.5 w-3.5'} strokeWidth={2} />
      {meta.label}
    </span>
  );
}