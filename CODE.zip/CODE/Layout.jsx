import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Files, Activity, GitBranch, Plus, LogOut, Users, Wallet, ScrollText, ClipboardList } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import RoleBadge from '@/components/RoleBadge';
import SignOutControl from '@/components/SignOutControl';
import BackupMenu from '@/components/tools/BackupMenu';
import useIdleLogout from '@/hooks/useIdleLogout';
import { isClient } from '@/lib/roles';
import { isManager } from '@/lib/loan';

const STAFF_NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/loans', label: 'Loans', icon: Files },
  { to: '/collections', label: 'Collections', icon: ClipboardList },
  { to: '/monitoring', label: 'Clients', icon: Activity },
  { to: '/team', label: 'Team', icon: Users, managerOnly: true },
  { to: '/audit', label: 'Audit trail', icon: ScrollText, managerOnly: true },
  { to: '/blueprints', label: 'Blueprints', icon: GitBranch },
];

const CLIENT_NAV = [
  { to: '/', label: 'My loan', icon: Wallet, end: true },
  { to: '/apply', label: 'Apply', icon: Plus },
];

function Brand() {
  return (
    <div className="flex items-center gap-2.5">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
        <span className="font-heading text-sm font-semibold">CL</span>
      </div>
      <div className="leading-tight">
        <p className="font-heading text-[15px] font-semibold tracking-tight">CARD LoanTrack</p>
        <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
          Micro-loan desk
        </p>
      </div>
    </div>
  );
}

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const manager = isManager(user);
  const client = isClient(user);
  const canFile = !client && !manager;
  const secondsLeft = useIdleLogout(() => logout(), 30);
  const items = client
    ? CLIENT_NAV
    : STAFF_NAV.filter((item) => !item.managerOnly || user?.role === 'admin');
  const half = Math.ceil(items.length / 2);

  return (
    <div className="min-h-screen bg-background text-foreground print:min-h-0 print:bg-white">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 hidden w-64 flex-col border-r border-border bg-sidebar px-5 py-6 md:flex print:hidden">
        <Brand />
        <nav className="mt-9 flex flex-1 flex-col gap-1">
          {items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors ${
                  isActive
                    ? 'bg-primary text-primary-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent'
                }`
              }
            >
              <item.icon className="h-[18px] w-[18px]" strokeWidth={1.75} />
              {item.label}
            </NavLink>
          ))}
        </nav>
        {canFile && (
          <button
            onClick={() => navigate('/loans/new')}
            className="mb-4 flex items-center justify-center gap-2 rounded-xl bg-accent px-3 py-2.5 text-sm font-medium text-accent-foreground transition hover:opacity-90"
          >
            <Plus className="h-4 w-4" /> New application
          </button>
        )}
        <div className="rounded-xl border border-sidebar-border bg-card/60 p-3">
          <p className="truncate text-sm font-medium">{user?.full_name || 'Branch staff'}</p>
          <div className="mt-1.5">
            <RoleBadge user={user} size="sm" />
          </div>
          <button
            onClick={() => logout()}
            className="mt-2 flex items-center gap-1.5 text-[11px] text-muted-foreground transition hover:text-foreground"
          >
            <LogOut className="h-3 w-3" /> Sign out
          </button>
        </div>
      </aside>

      <div className="md:pl-64 print:pl-0">
        {/* Mobile top bar */}
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border/70 bg-background/85 px-4 py-3 backdrop-blur md:hidden print:hidden">
          <Brand />
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-[11px] font-semibold text-primary">
              {(user?.full_name || 'CS')
                .split(' ')
                .map((part) => part[0])
                .slice(0, 2)
                .join('')}
            </div>
            <SignOutControl secondsLeft={secondsLeft} onSignOut={() => logout()} compact />
          </div>
        </header>

        {/* Desktop top-right actions */}
        <header className="sticky top-0 z-20 hidden items-center justify-end border-b border-border/70 bg-background/85 px-8 py-3 backdrop-blur md:flex print:hidden">
          <SignOutControl secondsLeft={secondsLeft} onSignOut={() => logout()} />
        </header>

        <main className="mx-auto w-full max-w-6xl px-4 pb-28 pt-5 md:px-8 md:pb-12 md:pt-8 print:max-w-none print:px-0 print:pb-0 print:pt-0">
          <Outlet />
        </main>
      </div>

      {/* Mobile bottom nav */}
      <nav className="safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/95 backdrop-blur md:hidden print:hidden">
        <div
          className="mx-auto grid max-w-md items-end px-2 pb-1.5 pt-2"
          style={{
            gridTemplateColumns: `repeat(${client ? 1 : items.length + (canFile ? 1 : 0)}, minmax(0, 1fr))`,
          }}
        >
          {items.slice(0, half).map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `flex flex-col items-center gap-0.5 rounded-lg py-1 text-[10px] ${
                  isActive ? 'text-primary' : 'text-muted-foreground'
                }`
              }
            >
              <item.icon className="h-5 w-5" strokeWidth={1.75} />
              {item.label}
            </NavLink>
          ))}
          {canFile && (
            <div className="flex justify-center">
              <button
                onClick={() => navigate('/loans/new')}
                aria-label="New loan application"
                className="-mt-6 flex h-13 w-13 items-center justify-center rounded-2xl bg-accent p-3.5 text-accent-foreground shadow-lg shadow-accent/25 transition active:scale-95"
              >
                <Plus className="h-5 w-5" />
              </button>
            </div>
          )}
          {items.slice(half).map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex flex-col items-center gap-0.5 rounded-lg py-1 text-[10px] ${
                  isActive ? 'text-primary' : 'text-muted-foreground'
                }`
              }
            >
              <item.icon className="h-5 w-5" strokeWidth={1.75} />
              {item.label}
            </NavLink>
          ))}
        </div>
      </nav>

      {manager && <BackupMenu />}
    </div>
  );
}