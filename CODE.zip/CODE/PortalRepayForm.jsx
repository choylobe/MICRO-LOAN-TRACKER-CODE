import React, { useState } from 'react';
import { Loader2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { peso } from '@/lib/loan';

export default function PortalRepayForm({ loan, onRepay }) {
  const [amount, setAmount] = useState(Number(loan.installment_amount || 0).toFixed(2));
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().slice(0, 10));
  const [method, setMethod] = useState('cash');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const submit = async (event) => {
    event.preventDefault();
    const value = Number(amount);
    if (!(value > 0)) {
      setError('Enter the amount you paid.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      await onRepay({ loanId: loan.id, amount: value, payment_date: paymentDate, method });
    } catch (err) {
      setError(err.message || 'Could not record the repayment.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="mt-4 rounded-xl border border-border bg-muted/40 p-3">
      <p className="text-[11px] uppercase tracking-[0.12em] text-muted-foreground">Record a repayment</p>
      <p className="mt-1 text-xs text-muted-foreground">
        Remaining balance {peso(loan.outstanding_balance)}. Your status updates once recorded.
      </p>

      <div className="mt-3 grid gap-2 sm:grid-cols-3">
        <div className="space-y-1">
          <Label htmlFor="portal-amount" className="text-[11px]">Amount paid</Label>
          <Input
            id="portal-amount"
            type="number"
            inputMode="decimal"
            step="0.01"
            min="0"
            value={amount}
            onChange={(event) => setAmount(event.target.value)}
          />
        </div>
        <div className="space-y-1">
          <Label htmlFor="portal-date" className="text-[11px]">Payment date</Label>
          <Input
            id="portal-date"
            type="date"
            value={paymentDate}
            onChange={(event) => setPaymentDate(event.target.value)}
          />
        </div>
        <div className="space-y-1">
          <Label className="text-[11px]">Method</Label>
          <Select value={method} onValueChange={setMethod}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="cash">Cash</SelectItem>
              <SelectItem value="gcash">GCash</SelectItem>
              <SelectItem value="bank transfer">Bank transfer</SelectItem>
              <SelectItem value="check">Check</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {error && <p className="mt-2 text-xs text-rose-700">{error}</p>}

      <Button type="submit" size="sm" className="mt-3 w-full sm:w-auto" disabled={saving}>
        {saving && <Loader2 className="h-4 w-4 animate-spin" />}
        {saving ? 'Saving…' : 'Submit repayment'}
      </Button>
    </form>
  );
}