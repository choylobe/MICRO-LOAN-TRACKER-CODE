import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { buildSchedule, collectionPosition, peso } from '@/lib/loan';
import StatusBadge from '@/components/loans/StatusBadge';
import AmortizationTable from '@/components/loans/AmortizationTable';
import RoleBadge from '@/components/RoleBadge';
import DisclosureCard from '@/components/client/DisclosureCard';
import { Plus, Wallet } from 'lucide-react';

const STATUS_TEXT = {
  submitted: 'Application received — waiting for screening.',
  under_review: 'Under credit investigation.',
  approved: 'Approved — waiting for release of funds.',
  rejected: 'Not approved. Please talk to your branch officer.',
  released: 'Loan released — repayments in progress.',
  closed: 'Fully paid and closed.',
};

function LoanSummary({ loan }) {
  const position = collectionPosition(loan);
  const total = Number(loan.total_payable || 0) || 1;
  const paidPct = Math.min(100, Math.round((Number(loan.amount_paid || 0) / total) * 100));

  return (
    <section className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
            {loan.loan_no}
            {loan.loan_cycle ? ` · Cycle ${loan.loan_cycle}` : ''}
          </p>
          <p className="mt-1 font-heading text-lg font-semibold">{peso(loan.principal)}</p>
        </div>
        <StatusBadge status={loan.status} />
      </div>
      <p className="mt-1.5 text-xs text-muted-foreground">{STATUS_TEXT[loan.status]}</p>

      <div className="mt-3 grid grid-cols-2 gap-2">
        <div className="rounded-xl bg-muted/50 px-3 py-2.5">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Total payable</p>
          <p className="mt-0.5 text-sm font-medium tabular-nums">{peso(loan.total_payable)}</p>
        </div>
        <div className="rounded-xl bg-muted/50 px-3 py-2.5">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Balance</p>
          <p className="mt-0.5 text-sm font-medium tabular-nums text-primary">
            {peso(loan.outstanding_balance)}
          </p>
        </div>
        <div className="rounded-xl bg-muted/50 px-3 py-2.5">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Amount paid</p>
          <p className="mt-0.5 text-sm font-medium tabular-nums text-emerald-700">{peso(loan.amount_paid)}</p>
        </div>
        <div className="rounded-xl bg-muted/50 px-3 py-2.5">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
            {loan.payment_frequency === 'monthly' ? 'Monthly due' : 'Weekly due'}
          </p>
          <p className="mt-0.5 text-sm font-medium tabular-nums">{peso(loan.installment_amount)}</p>
        </div>
      </div>

      {(loan.status === 'released' || loan.status === 'closed') && (
        <div className="mt-3">
          <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
            <div className="h-full rounded-full bg-primary" style={{ width: `${paidPct}%` }} />
          </div>
          <p className="mt-1.5 text-[11px] text-muted-foreground">
            {paidPct}% paid
            {position.next_due_date && loan.status === 'released'
              ? ` · next due ${format(position.next_due_date, 'd MMM yyyy')}`
              : ''}
            {position.isOverdue ? ` · ${peso(position.arrears)} in arrears` : ''}
          </p>
        </div>
      )}

      {loan.status === 'released' && (
        <div className="mt-4">
          <AmortizationTable schedule={buildSchedule(loan)} loan={loan} />
        </div>
      )}
    </section>
  );
}

export default function ClientHome() {
  const { user } = useAuth();
  const [borrower, setBorrower] = useState(null);
  const [loans, setLoans] = useState(null);

  const load = useCallback(async () => {
    if (!user?.borrower_id) {
      setLoans([]);
      return;
    }
    const record = await base44.entities.Borrower.get(user.borrower_id).catch(() => null);
    setBorrower(record);
    if (!record) {
      setLoans([]);
      return;
    }
    const page = await base44.entities.Loan.filter(
      { borrower_id: record.id },
      { sort: '-created_date', limit: 20 }
    );
    setLoans(page.items);
  }, [user?.borrower_id]);

  useEffect(() => {
    load();
  }, [load]);

  if (!loans) {
    return (
      <div className="space-y-4">
        <div className="h-28 animate-pulse rounded-2xl bg-muted" />
        <div className="h-40 animate-pulse rounded-2xl bg-muted" />
      </div>
    );
  }

  const outstanding = loans
    .filter((loan) => loan.status === 'released')
    .reduce((sum, loan) => sum + Number(loan.outstanding_balance || 0), 0);

  return (
    <div className="space-y-5">
      <div>
        <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
          {format(new Date(), 'EEEE, d MMMM')}
        </p>
        <h1 className="mt-1 font-heading text-[26px] font-semibold leading-tight">
          Hello, {(user?.full_name || 'Client').split(' ')[0]}
        </h1>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <RoleBadge user={user} size="sm" />
          <span className="text-xs text-muted-foreground">
            {borrower?.borrower_no || 'Client view'} · read only
          </span>
        </div>
      </div>

      <Link
        to="/apply"
        className="flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-medium text-primary-foreground transition hover:opacity-90"
      >
        <Plus className="h-4 w-4" /> Apply for a new loan
      </Link>

      {!user?.borrower_id && (
        <div className="rounded-2xl border border-dashed border-border p-6 text-sm text-muted-foreground">
          Your login is not linked to a client record yet. Please ask your branch officer to link it
          so your loan details show here.
        </div>
      )}

      {user?.borrower_id && !loans.length && (
        <div className="rounded-2xl border border-dashed border-border p-6 text-sm text-muted-foreground">
          No loan on file yet. Use “Apply for a new loan” to file your first application.
        </div>
      )}

      {loans.length > 0 && (
        <>
          <section className="flex items-center gap-3 rounded-2xl bg-primary px-4 py-4 text-primary-foreground">
            <Wallet className="h-5 w-5 shrink-0 opacity-80" />
            <div>
              <p className="text-[11px] uppercase tracking-[0.14em] text-primary-foreground/70">
                Total balance
              </p>
              <p className="font-heading text-2xl font-semibold leading-tight tabular-nums">
                {peso(outstanding)}
              </p>
            </div>
          </section>

          {loans.map((loan) => (
            <div key={loan.id} className="space-y-4">
              {loan.disclosure_at && (
                <DisclosureCard loan={loan} user={user} onDone={load} />
              )}
              <LoanSummary loan={loan} />
            </div>
          ))}
        </>
      )}

      <p className="rounded-2xl bg-muted/60 px-3 py-2.5 text-[11px] text-muted-foreground">
        Need to report a repayment? Open your branch status link, or call your account officer.
        Collections are posted only after the branch confirms receipt.
      </p>
    </div>
  );
}