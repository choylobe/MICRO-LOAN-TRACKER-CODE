import { base44 } from '@/api/base44Client';

/** Entities included in a system backup, in restore order. */
const COLLECTIONS = ['Borrower', 'Loan', 'Payment', 'LoanStatusHistory'];

const stripSystemFields = ({ id, created_date, updated_date, created_by_id, ...rest }) => rest;

export async function buildBackup() {
  const data = {};
  for (const name of COLLECTIONS) {
    const page = await base44.entities[name].filter({}, { sort: 'created_date', limit: 500 });
    data[name] = page.items.map(stripSystemFields);
  }
  return { app: 'CARD LoanTrack', exported_at: new Date().toISOString(), data };
}

/** Browser saves the file in the device's Downloads folder. */
export function downloadBackup(backup) {
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `card-loantrack-backup-${backup.exported_at.slice(0, 10)}.json`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

export async function restoreBackup(backup) {
  const counts = {};
  for (const name of COLLECTIONS) {
    const rows = backup?.data?.[name];
    if (!Array.isArray(rows) || !rows.length) continue;
    await base44.entities[name].bulkCreate(rows);
    counts[name] = rows.length;
  }
  return counts;
}