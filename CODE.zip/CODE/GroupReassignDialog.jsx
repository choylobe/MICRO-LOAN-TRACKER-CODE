import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { userRole } from '@/lib/roles';

const OPEN_STATUSES = ['submitted', 'under_review', 'approved', 'released'];

/**
 * Manager hands a client group from an absent account officer to another officer.
 * The group assignment moves and its open loans follow to the new officer.
 */
export default function GroupReassignDialog({ open, onOpenChange, rows, groups, onDone }) {
  const officers = (rows || []).filter((record) => userRole(record) === 'account_officer');
  const [group, setGroup] = useState('');
  const [targetId, setTargetId] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (open) {
      setGroup('');
      setTargetId('');
      setError('');
      setSaving(false);
    }
  }, [open]);

  const centersOf = (officer) =>
    (Array.isArray(officer.assigned_groups) ? officer.assigned_groups : []).concat(
      officer.assigned_group ? [officer.assigned_group] : []
    );

  const holders = officers.filter((officer) => centersOf(officer).includes(group));
  const target = officers.find((officer) => officer.id === targetId);
  const candidates = officers.filter((officer) => !centersOf(officer).includes(group));

  const submit = async () => {
    if (!group || !target) {
      setError('Choose a client group and the officer taking it over.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      await Promise.all(
        holders
          .filter((officer) => officer.id !== target.id)
          .map((officer) => {
            const next = centersOf(officer).filter((name) => name !== group);
            return base44.entities.User.update(officer.id, {
              assigned_groups: next,
              assigned_group: next[0] || '',
            });
          })
      );
      const targetCenters = [...new Set([...centersOf(target), group])];
      await base44.entities.User.update(target.id, {
        assigned_groups: targetCenters,
        assigned_group: targetCenters[0] || group,
      });
      await base44.entities.Loan.updateMany(
        { center_group: group, status: { $in: OPEN_STATUSES } },
        { $set: { officer_name: target.full_name } }
      );
      await onDone();
      onOpenChange(false);
    } catch (err) {
      setError(err?.message || 'The group could not be reassigned.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md rounded-2xl">
        <DialogHeader>
          <DialogTitle className="font-heading">Reassign a client group</DialogTitle>
          <DialogDescription>
            Hand a group to another account officer while the usual officer is away. Open loans of the
            group move with it.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label>Client group</Label>
            <Select value={group} onValueChange={setGroup}>
              <SelectTrigger className="mt-1.5">
                <SelectValue placeholder="Choose a group" />
              </SelectTrigger>
              <SelectContent>
                {groups.map((name) => (
                  <SelectItem key={name} value={name}>
                    {name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {group && (
              <p className="mt-1.5 text-[11px] text-muted-foreground">
                Currently handled by{' '}
                {holders.length
                  ? holders.map((officer) => officer.full_name || officer.email).join(', ')
                  : 'nobody'}
              </p>
            )}
          </div>

          <div>
            <Label>Taking over</Label>
            <Select value={targetId} onValueChange={setTargetId}>
              <SelectTrigger className="mt-1.5">
                <SelectValue placeholder="Choose an account officer" />
              </SelectTrigger>
              <SelectContent>
                {candidates.map((officer) => (
                  <SelectItem key={officer.id} value={officer.id}>
                    {officer.full_name || officer.email}
                    {centersOf(officer).length ? ` · ${centersOf(officer).length} center(s)` : ''}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {target && centersOf(target).length > 0 && (
              <p className="mt-1.5 text-[11px] text-amber-700">
                {target.full_name || target.email} already handles {centersOf(target).join(', ')} —
                this center is added to their assignment.
              </p>
            )}
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={saving || !group || !target}>
            {saving ? 'Reassigning…' : 'Reassign group'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}