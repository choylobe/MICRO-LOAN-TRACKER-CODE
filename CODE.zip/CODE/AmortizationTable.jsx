import React, { useState } from 'react';
import { format } from 'date-fns';
import { peso, computeTerms } from '@/lib/loan';

const rowState = (paid, row, previousCumulative, today) => {
  if (paid >= row.cumulative - 0.5) return { label: 'Paid', className: 'text-emerald-700' };
  if (paid > previousCumulative + 0.5) return { label: 'Partial', className: 'text-amber-700' };
  if (row.due_date < today) return { label: 'Overdue', className: 'text-rose-700' };
  return { label: 'Upcoming', className: 'text-muted-foreground' };
};

export default function AmortizationTable({ schedule, loan }) {
  const [expanded, setExpanded] = useState(false);
  const terms = computeTerms(loan || {});
  const paid = Number(loan?.amount_paid || 0);
  const today = new Date();
  const rows = expanded ? schedule : schedule.slice(0, 6);

  if (!schedule?.length) {
    return (
      <p className="rounded-xl border border-dashed border-border p-4 text-sm text-muted-foreground">
        The repayment schedule is generated when the loan is released.
      </p>
    );
  }

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-end justify-between gap-2">
        <div className="flex gap-4 text-xs text-muted-foreground">
          <span>
            Installment <strong className="font-medium text-foreground">{peso(terms.installment)}</strong>
          </span>
          <span>
            {terms.periods} {loan.payment_frequency === 'monthly' ? 'monthly' : 'weekly'} periods
          </span>
        </div>
        <span className="text-xs text-muted-foreground">Total payable {peso(terms.total)}</span>
      </div>

      <div className="overflow-hidden rounded-xl border border-border">
        <table className="w-full text-left text-sm">
          <thead className="bg-muted/60 text-[10px] uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-3 py-2 font-medium">#</th>
              <th className="px-3 py-2 font-medium">Due date</th>
              <th className="px-3 py-2 text-right font-medium">Amount</th>
              <th className="px-3 py-2 text-right font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, index) => {
              const previousCumulative = index === 0 ? 0 : schedule[index - 1].cumulative;
              const state = rowState(paid, row, previousCumulative, today);
              return (
                <tr key={row.no} className="border-t border-border/70">
                  <td className="px-3 py-2 tabular-nums text-muted-foreground">{row.no}</td>
                  <td className="px-3 py-2">{format(row.due_date, 'd MMM yyyy')}</td>
                  <td className="px-3 py-2 text-right tabular-nums">{peso(row.amount)}</td>
                  <td className={`px-3 py-2 text-right text-xs font-medium ${state.className}`}>
                    {state.label}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {schedule.length > 6 && (
        <button
          onClick={() => setExpanded((value) => !value)}
          className="mt-2 text-xs font-medium text-primary underline-offset-4 hover:underline"
        >
          {expanded ? 'Show first 6 periods' : `Show all ${schedule.length} periods`}
        </button>
      )}
    </div>
  );
}