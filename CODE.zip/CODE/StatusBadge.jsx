import React from 'react';
import { STATUS_META } from '@/lib/loan';

export default function StatusBadge({ status, size = 'md' }) {
  const meta = STATUS_META[status] || {
    label: status || 'Unknown',
    badge: 'bg-stone-100 text-stone-700 border-stone-300',
    dot: 'bg-stone-400',
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border font-medium ${meta.badge} ${
        size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs'
      }`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
      {meta.label}
    </span>
  );
}