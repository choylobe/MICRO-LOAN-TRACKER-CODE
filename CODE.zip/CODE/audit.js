import { base44 } from '@/api/base44Client';
import { userRole } from '@/lib/roles';

/**
 * Every transaction worth reviewing lands in AuditLog.
 * Logging never blocks the business action it records.
 */
export async function logAudit({
  user,
  actor_name,
  actor_role,
  action,
  entity_type,
  entity_id,
  reference,
  details,
  amount,
} = {}) {
  const numeric = amount === undefined || amount === null ? null : Number(amount);
  try {
    await base44.entities.AuditLog.create({
      actor_name: actor_name || user?.full_name || user?.email || 'System',
      actor_email: user?.email || '',
      actor_role: actor_role || (user ? userRole(user) : 'system'),
      action: action || 'Transaction',
      entity_type: entity_type || 'Loan',
      entity_id: entity_id || '',
      reference: reference || '',
      details: details || '',
      ...(numeric !== null && !Number.isNaN(numeric) ? { amount: numeric } : {}),
      occurred_at: new Date().toISOString(),
    });
  } catch (err) {
    // An audit write must never roll back the transaction it documents.
  }
}