import React from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, ChevronRight, RotateCcw } from 'lucide-react';
import StagePill from '@/components/clients/StagePill';
import { peso, pesoShort } from '@/lib/loan';
import { format } from 'date-fns';

export default function ClientRow({ profile }) {
  const navigate = useNavigate();
  const { borrower, stage, cycles, outstanding, repaid, arrears, progress, nextDue, reloanFrom } = profile;

  const startReloan = (event) => {
    event.preventDefault();
    event.stopPropagation();
    navigate(`/loans/new?borrower=${borrower.id}&from=${reloanFrom.id}`);
  };

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => navigate(`/borrowers/${borrower.id}`)}
      onKeyDown={(event) => event.key === 'Enter' && navigate(`/borrowers/${borrower.id}`)}
      className="cursor-pointer rounded-2xl border border-border bg-card p-4 transition hover:border-primary/30 hover:shadow-sm"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
            {borrower.full_name
              ?.split(' ')
              .map((part) => part[0])
              .slice(0, 2)
              .join('')}
          </div>
          <div className="min-w-0">
            <p className="truncate font-heading text-[16px] font-semibold leading-tight">
              {borrower.full_name}
            </p>
            <p className="mt-0.5 truncate text-[11px] uppercase tracking-[0.1em] text-muted-foreground">
              {borrower.borrower_no} · {borrower.center_group || borrower.branch || 'Walk-in'}
            </p>
          </div>
        </div>
        <StagePill stage={stage} size="sm" />
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2 text-sm">
        <div>
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Cycles</p>
          <p className="font-medium tabular-nums">{cycles || '—'}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Outstanding</p>
          <p className="font-medium tabular-nums">{pesoShort(outstanding)}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Repaid</p>
          <p className="font-medium tabular-nums text-emerald-700">{pesoShort(repaid)}</p>
        </div>
      </div>

      {stage === 'repayment' || stage === 'arrears' ? (
        <div className="mt-3">
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <div className="h-full rounded-full bg-primary" style={{ width: `${progress}%` }} />
          </div>
          <p className="mt-1.5 text-[11px] text-muted-foreground">
            {progress}% of current loan collected
            {stage === 'arrears'
              ? ` · ${peso(arrears)} in arrears`
              : nextDue
              ? ` · next due ${format(nextDue, 'd MMM')}`
              : ''}
          </p>
        </div>
      ) : null}

      {stage === 'application' && (
        <p className="mt-3 text-[11px] text-muted-foreground">
          {profile.latest?.status === 'under_review' ? 'Under credit review' : 'Waiting for document screening'}
          {profile.latest ? ` · ${peso(profile.latest.principal)} requested` : ''}
        </p>
      )}

      {stage === 'approval' && (
        <p className="mt-3 flex items-center gap-1.5 text-[11px] text-sky-800">
          <AlertTriangle className="h-3.5 w-3.5" /> Approved — awaiting fund release
        </p>
      )}

      {stage === 'reloan' && reloanFrom && (
        <div className="mt-3 flex items-center justify-between gap-2 rounded-xl bg-emerald-50/70 px-3 py-2">
          <p className="text-[11px] text-emerald-800">
            Previous loan fully paid — eligible to re-apply
          </p>
          <button
            onClick={startReloan}
            className="flex shrink-0 items-center gap-1 rounded-lg bg-primary px-2.5 py-1.5 text-[11px] font-medium text-primary-foreground"
          >
            <RotateCcw className="h-3 w-3" /> Re-apply
          </button>
        </div>
      )}

      <div className="mt-2 flex items-center justify-end text-[11px] font-medium text-primary">
        Open client record <ChevronRight className="h-3.5 w-3.5" />
      </div>
    </div>
  );
}