import React from 'react';
import { Frame, Lane, Task, Gateway, BpmnStart, BpmnEnd, Flow } from '@/components/docs/diagram';

export default function AsIsDiagram() {
  return (
    <Frame
      width={1320}
      height={840}
      caption="As-Is · paper-based non-collateral micro-loan processing at a branch. Manual handoffs in bold, rework loop drawn between the officer's checklist and the borrower."
    >
      <Lane x1={20} y1={40} x2={1300} y2={300} label="Borrower" alt />
      <Lane x1={20} y1={300} x2={1300} y2={620} label="Loan officer" />
      <Lane x1={20} y1={620} x2={1300} y2={800} label="Branch manager" alt />

      {/* Borrower row 1 */}
      <BpmnStart x={150} y={120} label="Walk-in" />
      <Task x={300} y={120} w={150} label="Fill out paper loan application form" />
      <Task x={500} y={120} w={170} label="Submit folder of requirements at the counter" />
      <Task x={720} y={120} w={180} label="Wait for result — no status visibility" />
      <Task x={1120} y={120} w={170} label="Sign release papers and receive cash" />
      <BpmnEnd x={1255} y={120} label="Loan released" />
      <Task x={1000} y={240} w={170} label="Pay weekly installment at the branch" />

      {/* Officer */}
      <Task x={500} y={380} w={170} label="Receive folder, check against paper checklist" />
      <Gateway x={660} y={380} label="Complete?" />
      <Task x={400} y={520} w={170} label="Tell borrower to return with complete documents" />
      <Task x={870} y={380} w={180} label="Manual credit investigation: house visit, co-maker check" />
      <Task x={1080} y={380} w={180} label="Compute amortization in Excel, log in spreadsheet" />
      <Task x={700} y={520} w={180} label="Collect payment, stamp passbook, update tally sheet" />
      <Gateway x={900} y={520} label="Fully paid?" />
      <BpmnEnd x={1010} y={520} label="Loan closed" tone="ok" />
      <Task x={1180} y={520} w={150} label="Notify treasury, prepare cash and voucher" />

      {/* Manager */}
      <Task x={980} y={700} w={170} label="Review loan folder" />
      <Gateway x={1160} y={700} label="Approve?" />
      <BpmnEnd x={1270} y={700} label="Rejected — verbal only" tone="bad" />

      {/* Sequence flows */}
      <Flow points={[[166, 120], [225, 120]]} />
      <Flow points={[[375, 120], [415, 120]]} />
      <Flow points={[[585, 120], [630, 120]]} />
      <Flow points={[[500, 148], [500, 352]]} label="Handover" at={[540, 250]} />
      <Flow points={[[810, 120], [1035, 120]]} label="Told to return for release" at={[920, 112]} />
      <Flow points={[[585, 380], [626, 380]]} />
      <Flow points={[[660, 406], [660, 493]]} label="No" at={[678, 445]} />
      <Flow
        points={[[315, 520], [250, 520], [250, 380], [413, 380]]}
        label="Borrower returns later"
        at={[250, 460]}
      />
      <Flow points={[[694, 380], [780, 380]]} label="Yes" at={[737, 372]} />
      <Flow points={[[960, 380], [990, 380]]} />
      <Flow
        points={[[1080, 408], [1080, 650], [980, 650], [980, 672]]}
        label="Endorse to manager"
        at={[1080, 640]}
      />
      <Flow points={[[1065, 700], [1126, 700]]} />
      <Flow points={[[1160, 672], [1160, 600], [1180, 600], [1180, 548]]} label="Yes" at={[1160, 626]} />
      <Flow
        points={[[1180, 492], [1180, 190], [1120, 190], [1120, 148]]}
        label="Cash prepared"
        at={[1180, 300]}
      />
      <Flow points={[[1194, 700], [1254, 700]]} label="No" at={[1224, 692]} />
      <Flow
        points={[[1120, 148], [1120, 210], [1240, 210], [1240, 240], [1085, 240]]}
        label="Release"
        at={[1240, 228]}
      />
      <Flow
        points={[[1000, 267], [1000, 440], [700, 440], [700, 493]]}
        label="Weekly payment"
        at={[860, 432]}
      />
      <Flow points={[[790, 520], [866, 520]]} />
      <Flow points={[[934, 520], [994, 520]]} label="Yes" at={[964, 512]} />
      <Flow
        points={[[900, 548], [900, 590], [700, 590], [700, 547]]}
        label="Next due date"
        at={[800, 602]}
      />
    </Frame>
  );
}