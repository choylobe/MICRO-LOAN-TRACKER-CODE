import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CalendarClock } from 'lucide-react';
import { collectionPosition, peso } from '@/lib/loan';
import { format } from 'date-fns';

export default function RepaymentPanel({ loans }) {
  const rows = loans
    .map((loan) => ({ loan, position: collectionPosition(loan) }))
    .sort((a, b) => {
      if (a.position.isOverdue !== b.position.isOverdue) return a.position.isOverdue ? -1 : 1;
      const left = a.position.next_due_date ? new Date(a.position.next_due_date).getTime() : Infinity;
      const right = b.position.next_due_date ? new Date(b.position.next_due_date).getTime() : Infinity;
      return left - right;
    })
    .slice(0, 6);

  const arrears = loans.reduce((sum, loan) => sum + collectionPosition(loan).arrears, 0);

  return (
    <section>
      <div className="mb-3 flex items-end justify-between gap-3">
        <div>
          <h2 className="font-heading text-lg font-semibold">Repayment schedule</h2>
          <p className="text-[11px] text-muted-foreground">
            {loans.length} active loan{loans.length === 1 ? '' : 's'} · arrears {peso(arrears)}
          </p>
        </div>
        <Link to="/monitoring" className="flex shrink-0 items-center gap-1 text-xs font-medium text-primary">
          Monitoring <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        {rows.length ? (
          <div className="divide-y divide-border">
            {rows.map(({ loan, position }) => (
              <Link
                key={loan.id}
                to={`/loans/${loan.id}`}
                className="flex items-center justify-between gap-3 px-4 py-3 transition hover:bg-muted/50"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{loan.borrower_name}</p>
                  <p className="truncate text-[11px] text-muted-foreground">
                    {loan.loan_no} · {peso(loan.installment_amount || 0)} /
                    {loan.payment_frequency === 'monthly' ? 'month' : 'week'}
                    {' · '}
                    {position.installments_paid} paid
                  </p>
                </div>
                <div className="shrink-0 text-right">
                  {position.isOverdue ? (
                    <p className="text-xs font-semibold tabular-nums text-rose-700">
                      {peso(position.arrears)} due
                    </p>
                  ) : (
                    <p className="text-xs font-medium tabular-nums text-muted-foreground">
                      {peso(position.paid)} paid
                    </p>
                  )}
                  <p className="mt-0.5 flex items-center justify-end gap-1 text-[11px] text-muted-foreground">
                    <CalendarClock className="h-3 w-3" strokeWidth={1.75} />
                    {position.next_due_date
                      ? `Next ${format(new Date(position.next_due_date), 'd MMM')}`
                      : 'All periods due'}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <p className="px-4 py-6 text-sm text-muted-foreground">
            No released loans yet. Repayment schedules appear once a loan is released.
          </p>
        )}
      </div>
    </section>
  );
}