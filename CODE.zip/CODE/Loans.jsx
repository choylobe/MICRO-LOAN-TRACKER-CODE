import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Plus } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import LoanCard from '@/components/loans/LoanCard';
import { Input } from '@/components/ui/input';
import { STATUS_META, isManager, officerCenters } from '@/lib/loan';
import { userRole } from '@/lib/roles';

const FILTERS = [
  { key: 'all', label: 'All' },
  { key: 'submitted', label: 'Submitted' },
  { key: 'under_review', label: 'Review' },
  { key: 'approved', label: 'Approved' },
  { key: 'released', label: 'Released' },
  { key: 'closed', label: 'Closed' },
  { key: 'rejected', label: 'Rejected' },
];

export default function Loans() {
  const { user } = useAuth();
  const [status, setStatus] = useState('all');
  const [search, setSearch] = useState('');
  const [loans, setLoans] = useState(null);

  useEffect(() => {
    let active = true;
    const timer = setTimeout(async () => {
      const query = {};
      if (status !== 'all') query.status = status;
      if (userRole(user) === 'account_officer') {
        const centers = officerCenters(user);
        if (centers.length) query.center_group = { $in: centers };
      }
      if (search.trim()) {
        query.$or = [
          { borrower_name: { $regex: search.trim(), $options: 'i' } },
          { loan_no: { $regex: search.trim(), $options: 'i' } },
        ];
      }
      const page = await base44.entities.Loan.filter(query, { sort: '-created_date', limit: 60 });
      if (active) setLoans(page.items);
    }, 220);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [status, search, user]);

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="font-heading text-[26px] font-semibold leading-tight">Loan register</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {loans ? `${loans.length} record${loans.length === 1 ? '' : 's'}` : 'Loading records…'}
            {status !== 'all' ? ` · ${STATUS_META[status].label}` : ''}
          </p>
        </div>
        {!isManager(user) && (
          <Link
            to="/loans/new"
            className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground md:hidden"
            aria-label="New loan application"
          >
            <Plus className="h-4 w-4" />
          </Link>
        )}
      </div>

      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search borrower or loan number"
          className="h-11 rounded-xl pl-9"
        />
      </div>

      <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1 md:mx-0 md:px-0">
        {FILTERS.map((filter) => (
          <button
            key={filter.key}
            onClick={() => setStatus(filter.key)}
            className={`shrink-0 rounded-full border px-3.5 py-1.5 text-xs font-medium transition ${
              status === filter.key
                ? 'border-primary bg-primary text-primary-foreground'
                : 'border-border bg-card text-muted-foreground hover:text-foreground'
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>

      {!loans && (
        <div className="space-y-3">
          {[0, 1, 2].map((key) => (
            <div key={key} className="h-32 animate-pulse rounded-2xl bg-muted" />
          ))}
        </div>
      )}

      {loans && (
        <div className="grid gap-3 md:grid-cols-2">
          {loans.map((loan) => (
            <LoanCard key={loan.id} loan={loan} />
          ))}
        </div>
      )}

      {loans && !loans.length && (
        <div className="rounded-2xl border border-dashed border-border p-8 text-center">
          <p className="font-heading text-base font-medium">No records match this view</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Adjust the filter or file a new loan application.
          </p>
        </div>
      )}
    </div>
  );
}