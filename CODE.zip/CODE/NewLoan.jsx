import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  LOAN_PRODUCTS,
  computeTerms,
  fullName,
  isManager,
  nextAccountNo,
  nextBorrowerNo,
  nextGroupCode,
  nextLoanNo,
  peso,
} from '@/lib/loan';

const DEFAULTS = {
  full_name: '',
  contact_number: '',
  address: '',
  branch: 'San Isidro Branch',
  center_group: '',
  occupation: '',
  monthly_income: '',
  co_maker_name: '',
  co_maker_contact: '',
  loan_product: 'Micro Loan — Weekly',
  principal: '',
  interest_rate: '2.5',
  term_months: '3',
  payment_frequency: 'weekly',
  purpose: '',
  risk_rating: 'medium',
};

export default function NewLoan() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [params] = useSearchParams();
  const presetBorrower = params.get('borrower');
  const fromLoanId = params.get('from');

  const [borrowers, setBorrowers] = useState([]);
  const [mode, setMode] = useState(presetBorrower ? 'existing' : 'new');
  const [borrowerId, setBorrowerId] = useState(presetBorrower || '');
  const [form, setForm] = useState(DEFAULTS);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    base44.entities.Borrower.list({ sort: 'full_name', limit: 100 }).then((page) => setBorrowers(page.items));
  }, []);

  // Re-application: reuse the previous loan's terms as a starting point.
  useEffect(() => {
    if (!fromLoanId) return;
    base44.entities.Loan.get(fromLoanId)
      .then((previous) =>
        setForm((prev) => ({
          ...prev,
          loan_product: previous.loan_product || prev.loan_product,
          principal: String(previous.principal ?? ''),
          interest_rate: String(previous.interest_rate ?? prev.interest_rate),
          term_months: String(previous.term_months ?? prev.term_months),
          payment_frequency: previous.payment_frequency || prev.payment_frequency,
          purpose: previous.purpose || '',
          center_group: previous.center_group || prev.center_group,
        }))
      )
      .catch(() => {});
  }, [fromLoanId]);

  const set = (field) => (event) => setForm((prev) => ({ ...prev, [field]: event.target.value }));

  const terms = useMemo(
    () =>
      computeTerms({
        principal: Number(form.principal),
        interest_rate: Number(form.interest_rate),
        term_months: Number(form.term_months),
        payment_frequency: form.payment_frequency,
      }),
    [form.principal, form.interest_rate, form.term_months, form.payment_frequency]
  );

  const submit = async (event) => {
    event.preventDefault();
    setError('');

    if (mode === 'existing' && !borrowerId) return setError('Select the borrower for this application.');
    if (mode === 'new' && (!form.full_name.trim() || !form.contact_number.trim()))
      return setError('Borrower name and contact number are required.');
    if (!Number(form.principal) || Number(form.principal) < 1000)
      return setError('Principal must be at least ₱1,000.');
    if (!Number(form.term_months)) return setError('Enter the loan term in months.');

    setSaving(true);
    try {
      let borrower =
        mode === 'existing' ? borrowers.find((item) => item.id === borrowerId) : null;

      if (mode === 'new') {
        borrower = await base44.entities.Borrower.create({
          borrower_no: await nextBorrowerNo(),
          account_no: await nextAccountNo(),
          group_code: await nextGroupCode(form.center_group),
          full_name: form.full_name.trim(),
          contact_number: form.contact_number.trim(),
          address: form.address,
          branch: form.branch,
          center_group: form.center_group,
          occupation: form.occupation,
          monthly_income: Number(form.monthly_income) || 0,
          co_maker_name: form.co_maker_name,
          co_maker_contact: form.co_maker_contact,
          status: 'active',
        });
      }

      const loanNo = await nextLoanNo();
      const previousLoans = await base44.entities.Loan.count({ borrower_id: borrower.id });
      const loan = await base44.entities.Loan.create({
        loan_no: loanNo,
        borrower_id: borrower.id,
        borrower_name: borrower.full_name,
        center_group: form.center_group || borrower.center_group || '',
        loan_product: form.loan_product,
        principal: Number(form.principal),
        interest_rate: Number(form.interest_rate),
        term_months: Number(form.term_months),
        payment_frequency: form.payment_frequency,
        purpose: form.purpose,
        status: 'submitted',
        risk_rating: form.risk_rating,
        officer_name: fullName(user),
        loan_cycle: previousLoans + 1,
        reloan_of: fromLoanId || '',
        submitted_at: new Date().toISOString(),
        total_interest: terms.interest,
        total_payable: terms.total,
        installment_amount: terms.installment,
        outstanding_balance: 0,
        amount_paid: 0,
      });

      await base44.entities.LoanStatusHistory.create({
        loan_id: loan.id,
        loan_no: loan.loan_no,
        from_status: '',
        to_status: 'submitted',
        action: 'Application filed',
        remarks: `${form.loan_product} · ${peso(terms.total)} total payable over ${terms.periods} periods`,
        actor_name: fullName(user),
        changed_at: new Date().toISOString(),
      });

      navigate(`/loans/${loan.id}`);
    } catch (err) {
      setError(err?.message || 'The application could not be saved.');
      setSaving(false);
    }
  };

  if (isManager(user)) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-6">
        <p className="font-heading text-lg font-medium">Applications are filed by account officers</p>
        <p className="mt-1.5 text-sm text-muted-foreground">
          The branch manager approves, releases and supervises. Ask an account officer to file this
          application.
        </p>
        <Link to="/loans" className="mt-3 inline-block text-sm font-medium text-primary">
          Back to loan register
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-5">
      <div>
        <Link
          to="/loans"
          className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground"
        >
          <ChevronLeft className="h-3.5 w-3.5" /> Loan register
        </Link>
        <h1 className="mt-2 font-heading text-[26px] font-semibold leading-tight">
          New loan application
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Non-collateral micro-loan · captured at the branch, tracked from submission to closure.
        </p>
      </div>

      {fromLoanId && (
        <p className="rounded-xl bg-primary/5 px-3 py-2 text-[11px] leading-relaxed text-primary">
          Re-application — the client's previous loan terms are pre-filled. Adjust anything that changed
          before filing.
        </p>
      )}

      <section className="rounded-2xl border border-border bg-card p-4">
        <div className="mb-4 flex rounded-xl bg-muted p-1 text-sm">
          {[
            { key: 'new', label: 'New borrower' },
            { key: 'existing', label: 'Existing borrower' },
          ].map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => setMode(tab.key)}
              className={`flex-1 rounded-lg py-2 font-medium transition ${
                mode === tab.key ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {mode === 'existing' ? (
          <div>
            <Label>Borrower</Label>
            <Select value={borrowerId} onValueChange={setBorrowerId}>
              <SelectTrigger className="mt-1.5">
                <SelectValue placeholder="Select a saved borrower" />
              </SelectTrigger>
              <SelectContent>
                {borrowers.map((borrower) => (
                  <SelectItem key={borrower.id} value={borrower.id}>
                    {borrower.full_name} · {borrower.borrower_no}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="mt-2 text-[11px] text-muted-foreground">
              Loan details below still apply to this new application.
            </p>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <Label htmlFor="full_name">Full name *</Label>
              <Input id="full_name" value={form.full_name} onChange={set('full_name')} className="mt-1.5" />
            </div>
            <div>
              <Label htmlFor="contact_number">Contact number *</Label>
              <Input
                id="contact_number"
                value={form.contact_number}
                onChange={set('contact_number')}
                placeholder="09xx xxx xxxx"
                className="mt-1.5"
              />
            </div>
            <div>
              <Label htmlFor="occupation">Livelihood / occupation</Label>
              <Input id="occupation" value={form.occupation} onChange={set('occupation')} className="mt-1.5" />
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="address">Address</Label>
              <Input id="address" value={form.address} onChange={set('address')} className="mt-1.5" />
            </div>
            <div>
              <Label htmlFor="center_group">Center / group</Label>
              <Input
                id="center_group"
                value={form.center_group}
                onChange={set('center_group')}
                placeholder="Center 04 — San Isidro"
                className="mt-1.5"
              />
              <p className="mt-1 text-[10px] leading-snug text-muted-foreground">
                Group code (CG + 6 digits) and client account number (CL + 8 digits) are generated
                when you save.
              </p>
            </div>
            <div>
              <Label htmlFor="monthly_income">Monthly income (₱)</Label>
              <Input
                id="monthly_income"
                type="number"
                inputMode="decimal"
                value={form.monthly_income}
                onChange={set('monthly_income')}
                className="mt-1.5"
              />
            </div>
            <div>
              <Label htmlFor="co_maker_name">Co-maker</Label>
              <Input
                id="co_maker_name"
                value={form.co_maker_name}
                onChange={set('co_maker_name')}
                className="mt-1.5"
              />
            </div>
            <div>
              <Label htmlFor="co_maker_contact">Co-maker contact</Label>
              <Input
                id="co_maker_contact"
                value={form.co_maker_contact}
                onChange={set('co_maker_contact')}
                className="mt-1.5"
              />
            </div>
          </div>
        )}
      </section>

      <section className="rounded-2xl border border-border bg-card p-4">
        <h2 className="font-heading text-base font-semibold">Loan terms</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <Label>Loan product</Label>
            <Select
              value={form.loan_product}
              onValueChange={(value) => setForm((prev) => ({ ...prev, loan_product: value }))}
            >
              <SelectTrigger className="mt-1.5">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {LOAN_PRODUCTS.map((product) => (
                  <SelectItem key={product} value={product}>
                    {product}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="principal">Principal (₱) *</Label>
            <Input
              id="principal"
              type="number"
              inputMode="decimal"
              value={form.principal}
              onChange={set('principal')}
              placeholder="15000"
              className="mt-1.5"
            />
          </div>
          <div>
            <Label htmlFor="interest_rate">Interest (% per month)</Label>
            <Input
              id="interest_rate"
              type="number"
              step="0.1"
              inputMode="decimal"
              value={form.interest_rate}
              onChange={set('interest_rate')}
              className="mt-1.5"
            />
          </div>
          <div>
            <Label htmlFor="term_months">Term (months)</Label>
            <Input
              id="term_months"
              type="number"
              inputMode="numeric"
              value={form.term_months}
              onChange={set('term_months')}
              className="mt-1.5"
            />
          </div>
          <div>
            <Label>Payment frequency</Label>
            <Select
              value={form.payment_frequency}
              onValueChange={(value) => setForm((prev) => ({ ...prev, payment_frequency: value }))}
            >
              <SelectTrigger className="mt-1.5">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Risk rating</Label>
            <Select
              value={form.risk_rating}
              onValueChange={(value) => setForm((prev) => ({ ...prev, risk_rating: value }))}
            >
              <SelectTrigger className="mt-1.5">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="sm:col-span-2">
            <Label htmlFor="purpose">Purpose of loan</Label>
            <Textarea
              id="purpose"
              value={form.purpose}
              onChange={set('purpose')}
              rows={2}
              placeholder="Working capital for sari-sari store"
              className="mt-1.5"
            />
          </div>
        </div>

        <div className="mt-4 rounded-xl bg-muted/70 p-3">
          <div className="grid grid-cols-3 gap-2 text-center">
            <div>
              <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Installment</p>
              <p className="font-heading text-base font-semibold tabular-nums">{peso(terms.installment)}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Interest</p>
              <p className="font-heading text-base font-semibold tabular-nums">{peso(terms.interest)}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Total payable</p>
              <p className="font-heading text-base font-semibold tabular-nums">{peso(terms.total)}</p>
            </div>
          </div>
          <p className="mt-2 text-center text-[11px] text-muted-foreground">
            {terms.periods} {form.payment_frequency} periods · flat add-on interest
          </p>
        </div>
      </section>

      {error && <p className="text-sm text-destructive">{error}</p>}

      <div className="flex gap-3">
        <Button type="button" variant="outline" className="flex-1" onClick={() => navigate('/loans')}>
          Cancel
        </Button>
        <Button type="submit" className="flex-1" disabled={saving}>
          {saving ? 'Filing…' : 'File application'}
        </Button>
      </div>
    </form>
  );
}