import React, { useRef, useState } from 'react';
import { Download, Loader2, MoreVertical, Upload, X } from 'lucide-react';
import { buildBackup, downloadBackup, restoreBackup } from '@/lib/backup';

export default function BackupMenu() {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState('');
  const [message, setMessage] = useState('');
  const fileRef = useRef(null);

  const exportAll = async () => {
    setBusy('export');
    setMessage('');
    try {
      const backup = await buildBackup();
      downloadBackup(backup);
      setMessage('Backup saved to this device’s Downloads folder.');
    } catch (err) {
      setMessage('The backup could not be created.');
    } finally {
      setBusy('');
    }
  };

  const importFile = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setBusy('import');
    setMessage('');
    try {
      const backup = JSON.parse(await file.text());
      const counts = await restoreBackup(backup);
      const total = Object.values(counts).reduce((sum, n) => sum + n, 0);
      setMessage(total ? `Restored ${total} records from the backup.` : 'That file holds no records.');
    } catch (err) {
      setMessage('That file is not a readable backup.');
    } finally {
      setBusy('');
    }
  };

  return (
    <div className="fixed bottom-24 right-4 z-40 md:bottom-6 md:right-6 print:hidden">
      {open && (
        <div className="absolute bottom-14 right-0 w-64 rounded-2xl border border-border bg-card p-3 shadow-xl">
          <p className="text-[11px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
            Branch tools
          </p>

          <button
            onClick={exportAll}
            disabled={busy === 'export'}
            className="mt-2 flex w-full items-start gap-2 rounded-xl border border-border px-3 py-2.5 text-left transition hover:bg-muted/60 disabled:opacity-60"
          >
            {busy === 'export' ? (
              <Loader2 className="mt-0.5 h-4 w-4 animate-spin text-primary" />
            ) : (
              <Download className="mt-0.5 h-4 w-4 text-primary" strokeWidth={1.75} />
            )}
            <span className="min-w-0">
              <span className="block text-sm font-medium">Export backup</span>
              <span className="block text-[11px] leading-snug text-muted-foreground">
                JSON file saved to your Downloads folder
              </span>
            </span>
          </button>

          <button
            onClick={() => fileRef.current?.click()}
            disabled={busy === 'import'}
            className="mt-2 flex w-full items-start gap-2 rounded-xl border border-border px-3 py-2.5 text-left transition hover:bg-muted/60 disabled:opacity-60"
          >
            {busy === 'import' ? (
              <Loader2 className="mt-0.5 h-4 w-4 animate-spin text-primary" />
            ) : (
              <Upload className="mt-0.5 h-4 w-4 text-primary" strokeWidth={1.75} />
            )}
            <span className="min-w-0">
              <span className="block text-sm font-medium">Import backup</span>
              <span className="block text-[11px] leading-snug text-muted-foreground">
                Restore from a backup file on this device
              </span>
            </span>
          </button>

          <input ref={fileRef} type="file" accept="application/json" onChange={importFile} className="hidden" />

          {message && <p className="mt-2 text-[11px] leading-snug text-muted-foreground">{message}</p>}
        </div>
      )}

      <button
        onClick={() => setOpen((value) => !value)}
        aria-label="More functions"
        className="ml-auto flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/25 transition active:scale-95"
      >
        {open ? <X className="h-5 w-5" /> : <MoreVertical className="h-5 w-5" />}
      </button>
    </div>
  );
}