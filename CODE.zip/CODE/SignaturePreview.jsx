import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Loader2, PenLine } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

/** Opens the stored PNG signature of a client or co-borrower. */
export default function SignaturePreview({ signatureUri, label = 'View signature' }) {
  const [open, setOpen] = useState(false);
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const show = async () => {
    setOpen(true);
    if (url || !signatureUri) return;
    setLoading(true);
    try {
      const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({
        file_uri: signatureUri,
      });
      setUrl(signed_url);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={show}
        className="inline-flex items-center gap-1 text-[11px] font-medium text-primary hover:underline"
      >
        <PenLine className="h-3 w-3" /> {label}
      </button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Signature (PNG)</DialogTitle>
          </DialogHeader>
          <div className="flex min-h-32 items-center justify-center rounded-xl border border-dashed border-border bg-card p-3">
            {loading && <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />}
            {!loading && url && (
              <img src={url} alt="Captured signature" className="max-h-56 w-full object-contain" />
            )}
            {!loading && !url && (
              <p className="text-xs text-muted-foreground">No signature image is stored.</p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}