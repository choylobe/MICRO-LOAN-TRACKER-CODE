import { base44 } from '@/api/base44Client';
import { logAudit } from '@/lib/audit';

/**
 * Patterns that should never happen in a normal branch day are stopped before they
 * touch the ledger, and recorded so the manager can review them.
 */
const REPLAY_WINDOW_MS = 10 * 60 * 1000;

export async function recordSecurityEvent({ user, action, reference, details, actor }) {
  await logAudit({
    user,
    actor_name: actor,
    action: action || 'Suspicious activity blocked',
    entity_type: 'Security',
    entity_id: reference || '',
    reference,
    details,
  });
}

/** A second identical application inside a few minutes is a double submit or a scripted replay. */
export async function blockedDuplicateApplication({ user, borrowerId, principal }) {
  const page = await base44.entities.Loan.filter(
    { borrower_id: borrowerId, principal: Number(principal) },
    { sort: '-created_date', limit: 10 }
  );
  const since = Date.now() - REPLAY_WINDOW_MS;
  const recent = page.items.find(
    (loan) => new Date(loan.submitted_at || loan.created_date).getTime() >= since
  );
  if (!recent) return null;
  await recordSecurityEvent({
    user,
    reference: recent.loan_no,
    details: `A duplicate application of ₱${Number(principal).toLocaleString('en-PH')} was submitted inside 10 minutes — blocked to protect the ledger.`,
  });
  return recent;
}

/** The screen sign-in form is hammered far faster than a person can type. */
export function looksAutomated(events = []) {
  if (events.length < 6) return false;
  const span = events[events.length - 1] - events[0];
  return span < 2500;
}

export async function securityEvents(limit = 50) {
  const page = await base44.entities.AuditLog.filter(
    { entity_type: 'Security' },
    { sort: '-occurred_at', limit }
  );
  return page.items;
}