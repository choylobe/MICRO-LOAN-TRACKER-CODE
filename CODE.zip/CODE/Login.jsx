import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LogIn, Mail, Lock, Loader2, ArrowLeft, Eye, EyeOff } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
import GoogleIcon from "@/components/GoogleIcon";
import { safeReturnTo } from "@/lib/authReturnTo";
import { loginWithMfa, continueMfa } from "@/lib/authMfa";
import { ROLE_META, userRole } from "@/lib/roles";
import RolePicker from "@/components/login/RolePicker";
import { rememberPendingRole } from "@/lib/pendingRole";

export default function Login() {
  const navigate = useNavigate();
  const returnTo = safeReturnTo();

  const [showPassword, setShowPassword] = useState(false);
  const [step, setStep] = useState("role");
  const [role, setRole] = useState("client");
  const [mode, setMode] = useState("existing");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const continueFromRole = () => {
    if (mode === "new") {
      rememberPendingRole(role);
      navigate(
        "/register" + (returnTo !== "/" ? "?returnTo=" + encodeURIComponent(returnTo) : "")
      );
      return;
    }
    setError("");
    setStep("credentials");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const result = await loginWithMfa(email, password);
      if (result?.mfa_required) {
        await continueMfa(result, returnTo);
        return;
      }

      const me = await base44.auth.me();
      if (me?.account_status === "disabled") {
        await base44.auth.logout();
        setError("This account has been disabled by the branch manager.");
        return;
      }

      const savedRole = userRole(me);
      if (savedRole !== role) {
        await base44.auth.logout();
        setError(
          `This email is registered as ${ROLE_META[savedRole].label}. Choose that role above to sign in.`
        );
        return;
      }

      window.location.href = returnTo;
    } catch (err) {
      setError(err.message || "Invalid email or password");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = () => {
    base44.auth.loginWithProvider("google", returnTo);
  };

  if (step === "role") {
    return (
      <AuthLayout
        icon={LogIn}
        title="Welcome back"
        subtitle="Choose how you are signing in"
        footer={
          <>
            Need an account?{" "}
            <Link
              to={"/register" + (returnTo !== "/" ? "?returnTo=" + encodeURIComponent(returnTo) : "")}
              className="text-primary font-medium hover:underline"
            >
              Create one
            </Link>
          </>
        }
      >
        {error && (
          <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
            {error}
          </div>
        )}
        <RolePicker
          role={role}
          onRole={setRole}
          mode={mode}
          onMode={setMode}
          onContinue={continueFromRole}
        />
      </AuthLayout>
    );
  }

  const meta = ROLE_META[role];

  return (
    <AuthLayout
      icon={LogIn}
      title={meta.label}
      subtitle="Enter your email and password"
      footer={
        <>
          Wrong role or need a new account?{" "}
          <button
            onClick={() => {
              setStep("role");
              setError("");
            }}
            className="text-primary font-medium hover:underline"
          >
            Start again
          </button>
        </>
      }
    >
      <button
        onClick={() => {
          setStep("role");
          setError("");
        }}
        className="mb-4 inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Change role
      </button>

      <Button
        variant="outline"
        className="w-full h-12 text-sm font-medium mb-6"
        onClick={handleGoogle}
      >
        <GoogleIcon className="w-5 h-5 mr-2" />
        Continue with Google
      </Button>

      <div className="relative mb-6">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-card px-3 text-muted-foreground">or</span>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="email"
              type="email"
              autoComplete="email"
              autoFocus
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-10 h-12"
              required
            />
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="password">Password</Label>
            <Link to="/forgot-password" className="text-xs text-primary hover:underline">
              Forgot password?
            </Link>
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="password"
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="pl-10 pr-11 h-12"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword((visible) => !visible)}
              aria-label={showPassword ? "Hide password" : "Show password"}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground transition hover:text-foreground"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>
        <Button type="submit" className="w-full h-12 font-medium" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Logging in...
            </>
          ) : (
            `Log in as ${meta.short}`
          )}
        </Button>
        <p className="text-center text-[11px] leading-relaxed text-muted-foreground">
          Your saved role must match the one you chose here, otherwise sign-in is blocked.
        </p>
      </form>
    </AuthLayout>
  );
}