import React from 'react';
import { format } from 'date-fns';
import StatusBadge from '@/components/loans/StatusBadge';

export default function StatusTimeline({ history }) {
  if (!history?.length) {
    return (
      <p className="rounded-xl border border-dashed border-border p-4 text-sm text-muted-foreground">
        No status changes recorded yet.
      </p>
    );
  }

  return (
    <ol className="relative space-y-4 border-l border-border pl-5">
      {history.map((entry, index) => (
        <li key={entry.id} className="relative">
          <span
            className={`absolute -left-[25px] top-1.5 h-2.5 w-2.5 rounded-full ring-4 ring-background ${
              index === 0 ? 'bg-primary' : 'bg-border'
            }`}
          />
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm font-medium">{entry.action}</p>
            <StatusBadge status={entry.to_status} size="sm" />
          </div>
          <p className="mt-0.5 text-[11px] text-muted-foreground">
            {format(new Date(entry.changed_at), 'd MMM yyyy · h:mm a')}
            {entry.actor_name ? ` · ${entry.actor_name}` : ''}
          </p>
          {entry.remarks && (
            <p className="mt-1 rounded-lg bg-muted/70 px-2.5 py-1.5 text-xs text-foreground/80">
              {entry.remarks}
            </p>
          )}
        </li>
      ))}
    </ol>
  );
}