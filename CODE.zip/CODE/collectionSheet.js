import { startOfWeek, endOfWeek } from 'date-fns';
import { buildSchedule } from '@/lib/loan';

/** Monday–Sunday window of the week the reference date falls in. */
export function weekWindow(reference = new Date()) {
  return {
    start: startOfWeek(reference, { weekStartsOn: 1 }),
    end: endOfWeek(reference, { weekStartsOn: 1 }),
  };
}

/** What a borrower owes this week: the week's installment plus any unpaid past dues. */
export function loanDues(loan, { start, end }) {
  const schedule = buildSchedule(loan);
  if (!schedule.length) return { rows: [], thisWeek: 0, pastDue: 0, total: 0 };

  const paid = Number(loan?.amount_paid || 0);
  const past = schedule.filter((row) => row.due_date < start);
  const rows = schedule.filter((row) => row.due_date >= start && row.due_date <= end);

  const pastCumulative = past.length ? past[past.length - 1].cumulative : 0;
  const pastDue = Math.max(0, pastCumulative - paid);
  const scheduled = rows.reduce((sum, row) => sum + row.amount, 0);
  const creditFromWeek = Math.max(0, paid - pastCumulative);
  const thisWeek = Math.max(0, scheduled - creditFromWeek);

  return { rows, thisWeek, pastDue, total: pastDue + thisWeek };
}