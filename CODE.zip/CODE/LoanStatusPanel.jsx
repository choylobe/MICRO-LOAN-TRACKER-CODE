import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import StatusBadge from '@/components/loans/StatusBadge';
import { pesoShort } from '@/lib/loan';

const ORDER = ['submitted', 'under_review', 'approved', 'released', 'closed', 'rejected'];

export default function LoanStatusPanel({ loans }) {
  const rows = ORDER.map((status) => {
    const items = loans.filter((loan) => loan.status === status);
    return {
      status,
      count: items.length,
      amount: items.reduce((sum, loan) => sum + Number(loan.principal || 0), 0),
    };
  });

  return (
    <section>
      <div className="mb-3 flex items-end justify-between gap-3">
        <h2 className="font-heading text-lg font-semibold">Loan status</h2>
        <Link to="/loans" className="flex items-center gap-1 text-xs font-medium text-primary">
          All loans <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {rows.map(({ status, count, amount }) => (
          <div key={status} className="rounded-2xl border border-border bg-card p-3">
            <StatusBadge status={status} size="sm" />
            <p className="mt-2 font-heading text-xl font-semibold leading-none tabular-nums">{count}</p>
            <p className="mt-1 text-[11px] text-muted-foreground">{pesoShort(amount)} principal</p>
          </div>
        ))}
      </div>
    </section>
  );
}