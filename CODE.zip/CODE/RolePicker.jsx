import React from 'react';
import { Button } from '@/components/ui/button';
import { ROLE_META } from '@/lib/roles';

const ROLE_ORDER = ['client', 'account_officer', 'manager'];

const MODES = [
  { value: 'existing', label: 'Existing account' },
  { value: 'new', label: 'New account' },
];

function Radio({ checked }) {
  return (
    <span
      className={`flex h-4 w-4 shrink-0 items-center justify-center rounded-full border ${
        checked ? 'border-primary' : 'border-muted-foreground/40'
      }`}
    >
      {checked && <span className="h-2 w-2 rounded-full bg-primary" />}
    </span>
  );
}

export default function RolePicker({ role, onRole, mode, onMode, onContinue }) {
  return (
    <div className="space-y-5">
      <div role="radiogroup" aria-label="Role">
        <p className="mb-2 text-[11px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
          Sign in as
        </p>
        <div className="space-y-2">
          {ROLE_ORDER.map((value) => {
            const meta = ROLE_META[value];
            const checked = role === value;
            return (
              <button
                key={value}
                type="button"
                role="radio"
                aria-checked={checked}
                onClick={() => onRole(value)}
                className={`flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition ${
                  checked ? 'border-primary bg-primary/5' : 'border-border hover:bg-muted/60'
                }`}
              >
                <Radio checked={checked} />
                <span className="min-w-0">
                  <span className="block text-sm font-medium">{meta.label}</span>
                  <span className="block text-[11px] leading-snug text-muted-foreground">
                    {meta.summary}
                  </span>
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div role="radiogroup" aria-label="Account status">
        <p className="mb-2 text-[11px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
          Account
        </p>
        <div className="grid grid-cols-2 gap-2">
          {MODES.map((item) => {
            const checked = mode === item.value;
            return (
              <button
                key={item.value}
                type="button"
                role="radio"
                aria-checked={checked}
                onClick={() => onMode(item.value)}
                className={`flex items-center gap-2 rounded-xl border px-3 py-2.5 text-xs font-medium transition ${
                  checked ? 'border-primary bg-primary/5' : 'border-border hover:bg-muted/60'
                }`}
              >
                <Radio checked={checked} />
                {item.label}
              </button>
            );
          })}
        </div>
      </div>

      <Button type="button" className="h-12 w-full font-medium" onClick={onContinue}>
        {mode === 'new' ? 'Create my account' : 'Continue'}
      </Button>
    </div>
  );
}