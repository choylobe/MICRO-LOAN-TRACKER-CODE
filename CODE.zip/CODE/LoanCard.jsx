import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, AlertTriangle } from 'lucide-react';
import StatusBadge from '@/components/loans/StatusBadge';
import { peso, pesoShort, collectionPosition } from '@/lib/loan';
import { format } from 'date-fns';

export default function LoanCard({ loan }) {
  const position = loan.status === 'released' ? collectionPosition(loan) : null;
  const showBalance = loan.status === 'released' || loan.status === 'closed';
  const headline = showBalance
    ? Number(loan.outstanding_balance || 0)
    : Number(loan.total_payable || 0);

  return (
    <Link
      to={`/loans/${loan.id}`}
      className="group block rounded-2xl border border-border bg-card p-4 transition hover:border-primary/30 hover:shadow-sm"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate font-heading text-[17px] font-semibold leading-tight">
            {loan.borrower_name}
          </p>
          <p className="mt-0.5 text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
            {loan.loan_no} · {loan.center_group || 'Walk-in'}
          </p>
        </div>
        <StatusBadge status={loan.status} size="sm" />
      </div>

      <div className="mt-3.5 grid grid-cols-3 gap-2 text-sm">
        <div>
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Principal</p>
          <p className="font-medium tabular-nums">{pesoShort(loan.principal)}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
            {showBalance ? 'Balance' : 'Payable'}
          </p>
          <p className="font-medium tabular-nums">{pesoShort(headline)}</p>
        </div>
        <div className="text-right">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
            {loan.payment_frequency === 'monthly' ? 'Monthly' : 'Weekly'}
          </p>
          <p className="font-medium tabular-nums">{peso(loan.installment_amount)}</p>
        </div>
      </div>

      {position?.isOverdue && (
        <p className="mt-3 flex items-center gap-1.5 rounded-lg bg-rose-50 px-2.5 py-1.5 text-[11px] font-medium text-rose-700">
          <AlertTriangle className="h-3.5 w-3.5" />
          {peso(position.arrears)} in arrears
        </p>
      )}

      {loan.status === 'released' && position?.next_due_date && !position.isOverdue && (
        <p className="mt-3 text-[11px] text-muted-foreground">
          Next due {format(position.next_due_date, 'd MMM yyyy')}
        </p>
      )}

      <div className="mt-2 flex items-center justify-end text-[11px] font-medium text-primary opacity-0 transition group-hover:opacity-100">
        Open record <ChevronRight className="h-3.5 w-3.5" />
      </div>
    </Link>
  );
}