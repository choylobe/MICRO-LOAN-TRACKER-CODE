import { addMonths, addWeeks } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { userRole } from '@/lib/roles';
import { logAudit } from '@/lib/audit';

export const LOAN_PRODUCTS = [
  'Micro Loan — Weekly',
  'Micro Loan — Monthly',
  'Salary Loan',
  'Emergency Loan',
  'Agricultural Loan',
];

export const STATUS_META = {
  submitted: {
    label: 'Submitted',
    helper: 'Waiting for document screening',
    badge: 'bg-amber-50 text-amber-800 border-amber-200',
    dot: 'bg-amber-500',
  },
  under_review: {
    label: 'Under Review',
    helper: 'Credit investigation and recommendation',
    badge: 'bg-sky-50 text-sky-800 border-sky-200',
    dot: 'bg-sky-500',
  },
  approved: {
    label: 'Approved',
    helper: 'Cleared for release by the branch manager',
    badge: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    dot: 'bg-emerald-500',
  },
  rejected: {
    label: 'Rejected',
    helper: 'Not approved — borrower informed in app',
    badge: 'bg-rose-50 text-rose-700 border-rose-200',
    dot: 'bg-rose-500',
  },
  released: {
    label: 'Released',
    helper: 'Funds out — collections in progress',
    badge: 'bg-teal-50 text-teal-800 border-teal-200',
    dot: 'bg-teal-500',
  },
  closed: {
    label: 'Closed',
    helper: 'Fully paid',
    badge: 'bg-stone-100 text-stone-700 border-stone-300',
    dot: 'bg-stone-400',
  },
};

export const peso = (value) =>
  '₱' +
  Number(value || 0).toLocaleString('en-PH', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

export const pesoShort = (value) => {
  const n = Number(value || 0);
  if (n >= 1000000) return '₱' + (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return '₱' + (n / 1000).toFixed(1) + 'k';
  return '₱' + n.toFixed(0);
};

export const fullName = (user) => user?.full_name || user?.email || 'Branch staff';

export const isManager = (user) => userRole(user) === 'manager';

/** Branch collection cycle: 6 months = 23 weekly periods, 1 year = 50 weekly periods. */
const WEEKLY_PERIODS = { 6: 23, 12: 50 };

export const weeklyPeriods = (termMonths) =>
  WEEKLY_PERIODS[Number(termMonths)] ?? Math.round((Number(termMonths) || 0) * 4);

/** Flat add-on interest, the usual non-collateral micro-loan computation. */
export function computeTerms({ principal, interest_rate, term_months, payment_frequency }) {
  const p = Number(principal) || 0;
  const rate = Number(interest_rate) || 0;
  const term = Number(term_months) || 0;
  const periods = payment_frequency === 'monthly' ? term : weeklyPeriods(term);
  const interest = p * (rate / 100) * term;
  const total = p + interest;
  return {
    periods,
    interest,
    total,
    installment: periods > 0 ? total / periods : 0,
  };
}

/** Due dates generated from the release date, one period apart. */
export function buildSchedule(loan) {
  if (!loan) return [];
  const terms = computeTerms(loan);
  const start = loan.released_at ? new Date(loan.released_at) : null;
  if (!start || !terms.periods) return [];
  const weekly = loan.payment_frequency !== 'monthly';
  return Array.from({ length: Math.round(terms.periods) }, (_, i) => {
    const no = i + 1;
    return {
      no,
      due_date: weekly ? addWeeks(start, no) : addMonths(start, no),
      amount: terms.installment,
      cumulative: terms.installment * no,
    };
  });
}

/** Arrears position for an active loan, based on the stored amount paid. */
export function collectionPosition(loan) {
  const schedule = buildSchedule(loan);
  const today = new Date();
  const dueRows = schedule.filter((row) => row.due_date <= today);
  const dueToDate = dueRows.length ? dueRows[dueRows.length - 1].cumulative : 0;
  const paid = Number(loan?.amount_paid || 0);
  const arrears = Math.max(0, dueToDate - paid);
  const nextRow = schedule.find((row) => row.due_date > today) || null;
  return {
    schedule,
    dueToDate,
    paid,
    arrears,
    isOverdue: arrears > 1,
    next_due_date: nextRow?.due_date || null,
    installments_paid: schedule.filter((row) => paid >= row.cumulative - 0.5).length,
  };
}

async function nextSequence(entity, prefix, pad = 4) {
  const total = await base44.entities[entity].count({});
  return `${prefix}-${String(total + 1).padStart(pad, '0')}`;
}

export async function nextLoanNo() {
  const total = await base44.entities.Loan.count({});
  return `ML-${new Date().getFullYear()}-${String(total + 1).padStart(4, '0')}`;
}

export async function nextBorrowerNo() {
  return nextSequence('Borrower', 'BR');
}

/** Client account number: CL + 8 digits. */
export async function nextAccountNo() {
  const total = await base44.entities.Borrower.count({});
  return `CL${String(total + 1).padStart(8, '0')}`;
}

/** Client group code: CG + 6 digits, reused for borrowers of the same center. */
export async function nextGroupCode(centerGroup) {
  const name = (centerGroup || '').trim();
  if (name) {
    const matches = await base44.entities.Borrower.filter({ center_group: name }, { limit: 1 });
    const existing = matches.items[0]?.group_code;
    if (existing) return existing;
  }
  const codes = await base44.entities.Borrower.list({ distinct: 'group_code' });
  const used = (codes.items || []).filter(Boolean).length;
  return `CG${String(used + 1).padStart(6, '0')}`;
}

export async function addHistory(loan, toStatus, action, { remarks = '', actor = '' } = {}) {
  return base44.entities.LoanStatusHistory.create({
    loan_id: loan.id,
    loan_no: loan.loan_no,
    from_status: loan.status,
    to_status: toStatus,
    action,
    remarks,
    actor_name: actor,
    changed_at: new Date().toISOString(),
  });
}

/** Single entry point for every status change so history is always written. */
export async function setLoanStatus(loan, toStatus, { action, remarks, actor, actorUser, patch = {} } = {}) {
  const updated = await base44.entities.Loan.update(loan.id, { ...patch, status: toStatus });
  await addHistory(loan, toStatus, action || STATUS_META[toStatus]?.label, { remarks, actor });
  await logAudit({
    user: actorUser,
    actor_name: actor,
    action: action || STATUS_META[toStatus]?.label || `Status changed to ${toStatus}`,
    entity_type: 'Loan',
    entity_id: loan.id,
    reference: loan.loan_no,
    details: `${loan.status} → ${toStatus}${remarks ? ` · ${remarks}` : ''}`,
    amount: patch.net_proceeds ?? patch.outstanding_balance,
  });
  return updated;
}

export async function postPayment(loan, payload) {
  const amount = Number(payload.amount) || 0;
  const paid = Number(loan.amount_paid || 0) + amount;
  const balance = Math.max(0, Number(loan.outstanding_balance || 0) - amount);
  const receipt_no = `RC-${String(Date.now()).slice(-6)}`;

  await base44.entities.Payment.create({
    loan_id: loan.id,
    loan_no: loan.loan_no,
    borrower_id: loan.borrower_id,
    borrower_name: loan.borrower_name,
    receipt_no,
    amount,
    payment_date: payload.payment_date,
    collected_by: payload.collected_by,
    method: payload.method || 'cash',
    remarks: payload.remarks || '',
    balance_after: balance,
  });

  const fullyPaid = balance <= 0.5;
  const patch = {
    amount_paid: paid,
    outstanding_balance: balance,
    last_payment_date: payload.payment_date,
  };
  if (fullyPaid) {
    patch.status = 'closed';
    patch.closed_at = new Date().toISOString();
  }

  const updated = await base44.entities.Loan.update(loan.id, patch);
  await addHistory(
    loan,
    fullyPaid ? 'closed' : loan.status,
    fullyPaid ? 'Final payment — loan closed' : 'Payment recorded',
    { remarks: `${peso(amount)} via ${payload.method || 'cash'} · receipt ${receipt_no}`, actor: payload.collected_by }
  );
  await logAudit({
    actor_name: payload.collected_by || 'Account officer',
    actor_role: 'account_officer',
    action: fullyPaid ? 'Final payment — loan closed' : 'Payment recorded',
    entity_type: 'Payment',
    entity_id: loan.id,
    reference: receipt_no,
    details: `${loan.loan_no} · ${payload.method || 'cash'} · balance ${peso(balance)}`,
    amount,
  });
  return updated;
}

/** Mandatory loan insurance: 0.69% of the principal (₱10,000 → ₱69.00). */
export const INSURANCE_RATE = 0.0069;

export const INSURANCE_LABEL = 'Loan insurance (0.69% of principal)';

/** Disbursement voucher number: CV- plus a 6-digit series. */
export async function nextCvNo() {
  const issued = await base44.entities.Loan.count({ cv_no: { $exists: true } });
  return `CV-${String(issued + 1).padStart(6, '0')}`;
}

export const DEFAULT_INTEREST_RATE = 2.5;

/** Renewal is offered once the running balance is down to 30% of the principal. */
export const RENEWAL_THRESHOLD = 0.3;

/** Centers an account officer is allowed to see. */
export function officerCenters(user) {
  const many = Array.isArray(user?.assigned_groups) ? user.assigned_groups : [];
  const one = user?.assigned_group ? [user.assigned_group] : [];
  return [...new Set([...many, ...one].filter(Boolean))];
}

/** True when the signed-in officer has a center scoping, and the record falls inside it. */
export function visibleToOfficer(user, center) {
  if (userRole(user) !== 'account_officer') return true;
  const centers = officerCenters(user);
  if (!centers.length) return true;
  return centers.includes(center);
}

/** Clients link: an officer only sees clients assigned to them or to one of their centers. */
export function borrowerVisibleToOfficer(user, borrower) {
  if (userRole(user) !== 'account_officer') return true;
  const email = String(user?.email || '').toLowerCase();
  if (email && String(borrower?.assigned_officer_email || '').toLowerCase() === email) return true;
  const centers = officerCenters(user);
  if (!centers.length) return true;
  return centers.includes(borrower?.center_group);
}

/** Interest, insurance, deductions and net proceeds for the disclosure. */
export function computeDisclosure({
  principal,
  interest_rate,
  term_months,
  payment_frequency,
  deductions,
  loan_balance_carry,
}) {
  const p = Number(principal) || 0;
  const terms = computeTerms({ principal: p, interest_rate, term_months, payment_frequency });
  const insurance = Math.round(p * INSURANCE_RATE * 100) / 100;
  const balance = Number(loan_balance_carry) || 0;
  const other = Number(deductions) || 0;
  const net = Math.max(0, p - balance - insurance - other);
  return {
    principal: p,
    interest: terms.interest,
    effective: p + terms.interest,
    installment: terms.installment,
    periods: terms.periods,
    insurance,
    balance,
    deductions: other,
    net,
  };
}

/** Figures already saved on the loan, falling back to the computed ones. */
export function disclosureFigures(loan) {
  const computed = computeDisclosure(loan || {});
  return {
    ...computed,
    interest: Number(loan?.total_interest ?? computed.interest),
    effective: Number(loan?.total_payable ?? computed.effective),
    insurance: Number(loan?.insurance_fee ?? computed.insurance),
    balance: Number(loan?.loan_balance_carry || 0),
    deductions: Number(loan?.deductions || 0),
    net: Number(loan?.net_proceeds ?? computed.net),
  };
}

/** Latest released loan and whether a renewal may be filed against it. */
export function renewalStatus(loans) {
  const current =
    (loans || [])
      .filter((loan) => loan.status === 'released')
      .sort(
        (a, b) =>
          new Date(b.released_at || b.created_date) - new Date(a.released_at || a.created_date)
      )[0] || null;

  if (!current) {
    return { current: null, eligible: false, reason: 'No released loan on file yet.' };
  }

  const balance = Number(current.outstanding_balance || 0);
  const cap = Number(current.principal || 0) * RENEWAL_THRESHOLD;
  const eligible = balance <= cap + 0.01;
  return {
    current,
    balance,
    cap,
    eligible,
    reason: eligible
      ? ''
      : `This loan is not yet renewable — the remaining balance of ${peso(balance)} is still above ${peso(cap)}, which is 30% of the ${peso(current.principal)} principal.`,
  };
}