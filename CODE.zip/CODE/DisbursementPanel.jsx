import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, HandCoins } from 'lucide-react';
import { format } from 'date-fns';
import { peso } from '@/lib/loan';

const netOf = (loan) =>
  Number(loan.net_proceeds ?? loan.principal ?? 0);

/** Approved loans with their net proceeds — the basis for disbursement. */
export default function DisbursementPanel({ loans }) {
  const approved = (loans || []).filter((loan) => loan.status === 'approved');
  const total = approved.reduce((sum, loan) => sum + netOf(loan), 0);

  return (
    <section>
      <div className="mb-3 flex items-end justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 font-heading text-lg font-semibold">
            <HandCoins className="h-4 w-4 text-primary" /> Net proceeds for disbursement
          </h2>
          <p className="text-[11px] text-muted-foreground">
            {approved.length} approved loan{approved.length === 1 ? '' : 's'} · {peso(total)} to release
          </p>
        </div>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        {approved.map((loan) => (
          <Link
            key={loan.id}
            to={`/loans/${loan.id}`}
            className="flex items-center justify-between gap-3 border-b border-border px-4 py-3 last:border-0 transition hover:bg-muted/50"
          >
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">{loan.borrower_name}</p>
              <p className="truncate text-[11px] text-muted-foreground">
                {loan.loan_no} · principal {peso(loan.principal)}
                {loan.decided_at ? ` · approved ${format(new Date(loan.decided_at), 'd MMM')}` : ''}
                {loan.date_needed ? ` · needed ${format(new Date(loan.date_needed), 'd MMM')}` : ''}
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-2 text-right">
              <div>
                <p className="text-sm font-semibold tabular-nums text-primary">{peso(netOf(loan))}</p>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">net proceeds</p>
              </div>
              <ArrowRight className="h-4 w-4 text-muted-foreground" />
            </div>
          </Link>
        ))}
        {!approved.length && (
          <p className="px-4 py-4 text-xs text-muted-foreground">
            No approved loan is waiting for release.
          </p>
        )}
      </div>
    </section>
  );
}