import React from 'react';
import { Check } from 'lucide-react';

const STEPS = [
  { key: 'submitted', label: 'Application' },
  { key: 'under_review', label: 'Review' },
  { key: 'approved', label: 'Approval' },
  { key: 'released', label: 'Release' },
  { key: 'closed', label: 'Fully paid' },
];

export default function LifecycleTracker({ loan }) {
  const statusIndex = loan ? STEPS.findIndex((step) => step.key === loan.status) : -1;
  const rejected = loan?.status === 'rejected';
  const current = rejected ? 1 : statusIndex;

  return (
    <div>
      <div className="flex items-start">
        {STEPS.map((step, index) => {
          const done = current > index;
          const active = current === index;
          return (
            <React.Fragment key={step.key}>
              {index > 0 && (
                <span
                  className={`mt-[11px] h-px flex-1 ${done || active ? 'bg-primary' : 'bg-border'}`}
                />
              )}
              <div className="flex w-14 shrink-0 flex-col items-center gap-1.5 md:w-20">
                <span
                  className={`flex h-6 w-6 items-center justify-center rounded-full border text-[10px] font-semibold ${
                    done
                      ? 'border-primary bg-primary text-primary-foreground'
                      : active
                      ? rejected
                        ? 'border-rose-300 bg-rose-50 text-rose-700'
                        : 'border-primary bg-card text-primary'
                      : 'border-border bg-card text-muted-foreground'
                  }`}
                >
                  {done ? <Check className="h-3 w-3" /> : index + 1}
                </span>
                <span
                  className={`text-center text-[9px] leading-tight ${
                    active ? 'font-semibold text-foreground' : 'text-muted-foreground'
                  }`}
                >
                  {step.label}
                </span>
              </div>
            </React.Fragment>
          );
        })}
      </div>
      {rejected && (
        <p className="mt-3 rounded-lg bg-rose-50 px-3 py-2 text-[11px] text-rose-700">
          This application stopped at the review stage — rejected. The client can be reassessed for a
          new application.
        </p>
      )}
    </div>
  );
}