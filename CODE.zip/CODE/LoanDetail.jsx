import React, { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { addMonths, addWeeks, format } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import StatusBadge from '@/components/loans/StatusBadge';
import StatusTimeline from '@/components/loans/StatusTimeline';
import AmortizationTable from '@/components/loans/AmortizationTable';
import RecordPaymentDialog from '@/components/loans/RecordPaymentDialog';
import WorkflowDialog from '@/components/loans/WorkflowDialog';
import DisclosurePanel from '@/components/loans/DisclosurePanel';
import SignaturePreview from '@/components/signatures/SignaturePreview';
import { markSignaturesDisbursed, signaturesForLoan } from '@/lib/signatures';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  STATUS_META,
  collectionPosition,
  computeTerms,
  disclosureFigures,
  fullName,
  isManager,
  nextCvNo,
  peso,
  setLoanStatus,
} from '@/lib/loan';
import { userRole } from '@/lib/roles';
import { AlertTriangle, ChevronLeft, Phone, Store } from 'lucide-react';

function Field({ label, value, accent }) {
  return (
    <div className="rounded-xl bg-muted/50 px-3 py-2.5">
      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className={`mt-0.5 text-sm font-medium tabular-nums ${accent || ''}`}>{value}</p>
    </div>
  );
}

export default function LoanDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const manager = isManager(user);
  const officer = userRole(user) === 'account_officer';

  const [loan, setLoan] = useState(null);
  const [borrower, setBorrower] = useState(null);
  const [history, setHistory] = useState([]);
  const [payments, setPayments] = useState([]);
  const [signatures, setSignatures] = useState([]);
  const [missing, setMissing] = useState(false);
  const [dialog, setDialog] = useState(null);
  const [recommendValue, setRecommendValue] = useState('approve');
  const [risk, setRisk] = useState('medium');
  const [ciNotes, setCiNotes] = useState('');

  const load = useCallback(async () => {
    try {
      const record = await base44.entities.Loan.get(id);
      setLoan(record);
      setRisk(record.risk_rating || 'medium');
      setCiNotes(record.ci_notes || '');
      const [historyPage, paymentPage, borrowerRecord] = await Promise.all([
        base44.entities.LoanStatusHistory.filter({ loan_id: id }, { sort: '-changed_at', limit: 50 }),
        base44.entities.Payment.filter({ loan_id: id }, { sort: '-payment_date', limit: 50 }),
        record.borrower_id
          ? base44.entities.Borrower.get(record.borrower_id).catch(() => null)
          : Promise.resolve(null),
      ]);
      setHistory(historyPage.items);
      setPayments(paymentPage.items);
      setBorrower(borrowerRecord);
      setSignatures(await signaturesForLoan(id));
    } catch (err) {
      setMissing(true);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  const actor = fullName(user);

  if (missing) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-8 text-center">
        <p className="font-heading text-lg font-medium">Loan record not found</p>
        <Link to="/loans" className="mt-2 inline-block text-sm text-primary">
          Back to the loan register
        </Link>
      </div>
    );
  }

  if (!loan) {
    return (
      <div className="space-y-4">
        <div className="h-28 animate-pulse rounded-2xl bg-muted" />
        <div className="h-40 animate-pulse rounded-2xl bg-muted" />
      </div>
    );
  }

  const terms = computeTerms(loan);
  const position = collectionPosition(loan);
  const statusMeta = STATUS_META[loan.status] || {};
  const canReview = ['submitted'].includes(loan.status);
  const canDecide = ['submitted', 'under_review'].includes(loan.status) && manager;
  const canRecommend = officer && loan.status === 'under_review';
  const clientAccepted = loan.client_decision === 'accepted' || !loan.disclosure_at;
  const canRelease = loan.status === 'approved' && (manager || officer);
  const disclosure = disclosureFigures(loan);

  const change = (toStatus, options) =>
    setLoanStatus(loan, toStatus, { ...options, actor, actorUser: user }).then(load);

  const actions = {
    review: () =>
      change('under_review', {
        action: 'Document screening & CI completed',
        remarks: `Risk rated ${risk}. ${ciNotes}`.trim(),
        patch: { risk_rating: risk, ci_notes: ciNotes },
      }),
    recommend: (value, remarks) =>
      change(loan.status, {
        action: value === 'approve' ? 'Recommended for approval' : 'Recommended for rejection',
        remarks,
        patch: {
          recommendation: value,
          recommendation_notes: remarks,
          recommended_by: actor,
          recommended_at: new Date().toISOString(),
        },
      }),
    approve: (remarks) =>
      change('approved', {
        action: 'Loan validated and approved',
        remarks,
        patch: {
          decided_at: new Date().toISOString(),
          decided_by: actor,
          decision_remarks: remarks,
        },
      }),
    reject: (remarks) =>
      change('rejected', {
        action: 'Application rejected',
        remarks,
        patch: {
          decided_at: new Date().toISOString(),
          decided_by: actor,
          decision_remarks: remarks,
        },
      }),
    release: async (remarks) => {
      const releasedAt = new Date();
      const due = loan.payment_frequency === 'monthly' ? addMonths(releasedAt, 1) : addWeeks(releasedAt, 1);
      const cvNo = loan.cv_no || (await nextCvNo());
      const updated = await change('released', {
        action: 'Funds disbursed to borrower',
        remarks,
        patch: {
          cv_no: cvNo,
          released_at: releasedAt.toISOString(),
          released_by: actor,
          first_due_date: format(due, 'yyyy-MM-dd'),
          outstanding_balance: Number(loan.total_payable || terms.total),
          amount_paid: Number(loan.amount_paid || 0),
        },
      });
      await markSignaturesDisbursed(loan.id, cvNo, actor);
      return updated;
    },
  };

  const collectedPct =
    loan.status === 'released' || loan.status === 'closed'
      ? Math.min(100, Math.round((Number(loan.amount_paid || 0) / (Number(loan.total_payable) || 1)) * 100))
      : 0;

  return (
    <div className="space-y-5">
      <div>
        <Link
          to="/loans"
          className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground"
        >
          <ChevronLeft className="h-3.5 w-3.5" /> Loan register
        </Link>
        <div className="mt-2 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="truncate font-heading text-[26px] font-semibold leading-tight">
              {loan.borrower_name}
            </h1>
            <p className="mt-1 text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
              {loan.loan_no} · {loan.loan_product}
              {loan.loan_cycle ? ` · Cycle ${loan.loan_cycle}` : ''}
            </p>
          </div>
          <StatusBadge status={loan.status} />
        </div>
        <p className="mt-1.5 text-xs text-muted-foreground">{statusMeta.helper}</p>
      </div>

      {position.isOverdue && loan.status === 'released' && (
        <div className="flex items-start gap-2 rounded-2xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-800">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          <p>
            <strong className="font-semibold">{peso(position.arrears)}</strong> in arrears ·{' '}
            {position.installments_paid} of {position.schedule.length} installments settled.
          </p>
        </div>
      )}

      {loan.recommendation && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-3.5 text-amber-900">
          <p className="text-[10px] uppercase tracking-wide text-amber-800/80">
            Account officer recommendation
          </p>
          <p className="mt-1 text-sm font-semibold">
            {loan.recommendation === 'approve' ? 'For approval' : 'For rejection'}
            {loan.recommended_by ? ` · ${loan.recommended_by}` : ''}
          </p>
          {loan.recommendation_notes && (
            <p className="mt-1 text-xs text-amber-900/80">{loan.recommendation_notes}</p>
          )}
          <p className="mt-1 text-[11px] text-amber-900/70">Final decision rests with the branch manager.</p>
        </div>
      )}

      <section className="rounded-2xl border border-border bg-card p-4">
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          <Field label="Principal" value={peso(loan.principal)} />
          <Field label="Interest" value={peso(loan.total_interest)} />
          <Field label="Total payable" value={peso(loan.total_payable)} />
          <Field
            label={loan.payment_frequency === 'monthly' ? 'Monthly amortization' : 'Weekly amortization'}
            value={peso(loan.installment_amount)}
          />
          <Field
            label="Outstanding balance"
            value={peso(loan.outstanding_balance)}
            accent={loan.status === 'released' ? 'text-primary' : ''}
          />
          <Field label="Amount paid" value={peso(loan.amount_paid)} accent="text-emerald-700" />
        </div>

        {(loan.status === 'released' || loan.status === 'closed') && (
          <div className="mt-4">
            <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
              <div className="h-full rounded-full bg-primary" style={{ width: `${collectedPct}%` }} />
            </div>
            <p className="mt-1.5 text-[11px] text-muted-foreground">
              {collectedPct}% collected
              {position.next_due_date && loan.status === 'released'
                ? ` · next due ${format(position.next_due_date, 'd MMM yyyy')}`
                : ''}
              {loan.released_at ? ` · released ${format(new Date(loan.released_at), 'd MMM yyyy')}` : ''}
            </p>
          </div>
        )}
      </section>

      {officer && loan.status === 'under_review' && loan.client_decision !== 'accepted' && (
        <DisclosurePanel loan={loan} user={user} onSaved={load} />
      )}

      {loan.disclosure_at && (
        <section className="rounded-2xl border border-border bg-card p-4">
          <h2 className="font-heading text-base font-semibold">Loan Disclosure Agreement</h2>
          <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
            <Field label="Principal" value={peso(disclosure.principal)} />
            <Field label="Interest" value={peso(disclosure.interest)} />
            <Field label="Effective interest" value={peso(disclosure.effective)} />
            <Field label="Loan insurance" value={peso(disclosure.insurance)} />
            <Field label="Loan balance" value={peso(disclosure.balance)} />
            <Field label="Deductions" value={peso(disclosure.deductions)} />
          </div>
          <div className="mt-2 rounded-xl bg-primary/10 px-3 py-2.5">
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
              Net loan proceeds
            </p>
            <p className="font-heading text-xl font-semibold tabular-nums">{peso(disclosure.net)}</p>
          </div>
          <p className="mt-2 text-[11px] text-muted-foreground">
            {loan.client_decision === 'accepted'
              ? `Signed and accepted by ${loan.client_signature_name} on ${format(
                  new Date(loan.client_decided_at),
                  'd MMM yyyy, h:mm a'
                )} — forwarded to the branch manager for validation.`
              : loan.client_decision === 'declined'
                ? 'Declined by the client — the terms need to be revisited.'
                : 'Sent to the client window for signature and verification of the net proceeds.'}
          </p>
        </section>
      )}

      {signatures.length > 0 && (
        <section className="rounded-2xl border border-border bg-card p-4">
          <h2 className="font-heading text-base font-semibold">Signatures on file</h2>
          <div className="mt-3 divide-y divide-border">
            {signatures.map((signature) => (
              <div key={signature.id} className="flex items-start justify-between gap-3 py-2.5">
                <div className="min-w-0">
                  <p className="text-sm font-medium">
                    {signature.signer_role === 'co_borrower' ? 'Co-borrower' : 'Client'} ·{' '}
                    {signature.signer_name}
                  </p>
                  <p className="text-[11px] text-muted-foreground">
                    {signature.decision === 'signed' ? 'Signed' : 'Declined'} ·{' '}
                    {signature.signed_at
                      ? format(new Date(signature.signed_at), 'd MMM yyyy, h:mm a')
                      : '—'}
                    {signature.contact_number ? ` · ${signature.contact_number}` : ''}
                  </p>
                  {signature.signature_uri && (
                    <SignaturePreview signatureUri={signature.signature_uri} label="View PNG" />
                  )}
                </div>
                <span
                  className={`shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-medium capitalize ${
                    signature.manager_status === 'disbursed'
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                      : signature.manager_status === 'validated'
                        ? 'border-sky-200 bg-sky-50 text-sky-800'
                        : 'border-amber-200 bg-amber-50 text-amber-800'
                  }`}
                >
                  {signature.manager_status}
                </span>
              </div>
            ))}
          </div>
          {loan.cv_no && (
            <p className="mt-2 rounded-xl bg-muted/50 px-3 py-2 text-[11px] text-foreground/80">
              Disbursement voucher <span className="font-semibold">{loan.cv_no}</span>
              {loan.released_at ? ` · released ${format(new Date(loan.released_at), 'd MMM yyyy')}` : ''}
            </p>
          )}
        </section>
      )}

      {(canReview || canDecide || loan.status === 'approved' || loan.status === 'released') && (
        <section className="space-y-2">
          {canReview && (
            <Button className="w-full" onClick={() => setDialog('review')}>
              Screen documents & submit for review
            </Button>
          )}
          {canRecommend && (
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setRecommendValue('approve');
                  setDialog('recommend');
                }}
              >
                Recommend approval
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setRecommendValue('reject');
                  setDialog('recommend');
                }}
              >
                Recommend rejection
              </Button>
            </div>
          )}
          {canDecide && (
            <div className="grid grid-cols-2 gap-2">
              <Button onClick={() => setDialog('approve')} disabled={!clientAccepted}>
                Approve loan
              </Button>
              <Button variant="outline" onClick={() => setDialog('reject')}>
                Reject
              </Button>
            </div>
          )}
          {canDecide && !clientAccepted && (
            <p className="rounded-xl bg-amber-50 px-3 py-2 text-[11px] text-amber-800">
              Waiting for the client to sign the Loan Disclosure Agreement. Validation opens once the
              client accepts the net proceeds.
            </p>
          )}
          {canRelease && (
            <Button className="w-full" onClick={() => setDialog('release')}>
              Disburse funds · net {peso(disclosure.net)}
            </Button>
          )}
          {loan.status === 'released' && (
            <Button className="w-full" onClick={() => setDialog('payment')}>
              Record collection
            </Button>
          )}
          {['submitted', 'under_review'].includes(loan.status) && !manager && (
            <p className="rounded-xl bg-muted/70 px-3 py-2 text-[11px] text-muted-foreground">
              Record the CI findings and terms, then generate the disclosure for the client's
              signature. The branch manager validates and the assigned officer disburses.
            </p>
          )}
        </section>
      )}

      <section className="rounded-2xl border border-border bg-card p-4">
        <h2 className="font-heading text-base font-semibold">Borrower</h2>
        <div className="mt-3 space-y-2 text-sm">
          <p className="flex items-center justify-between gap-3">
            <span className="text-muted-foreground">Center / group</span>
            <span className="flex items-center gap-1.5 font-medium">
              <Store className="h-3.5 w-3.5 text-muted-foreground" />
              {loan.center_group || 'Walk-in'}
            </span>
          </p>
          <p className="flex items-center justify-between gap-3">
            <span className="text-muted-foreground">Contact</span>
            <span className="flex items-center gap-1.5 font-medium">
              <Phone className="h-3.5 w-3.5 text-muted-foreground" />
              {borrower?.contact_number || '—'}
            </span>
          </p>
          <p className="flex items-center justify-between gap-3">
            <span className="text-muted-foreground">Co-maker</span>
            <span className="font-medium">{borrower?.co_maker_name || '—'}</span>
          </p>
          <p className="flex items-center justify-between gap-3">
            <span className="text-muted-foreground">Risk rating</span>
            <span className="font-medium capitalize">{loan.risk_rating || '—'}</span>
          </p>
          <p className="flex items-center justify-between gap-3">
            <span className="text-muted-foreground">Handled by</span>
            <span className="font-medium">{loan.officer_name || '—'}</span>
          </p>
        </div>
        {loan.purpose && (
          <p className="mt-3 rounded-xl bg-muted/50 px-3 py-2 text-xs text-foreground/80">
            <span className="text-muted-foreground">Purpose: </span>
            {loan.purpose}
          </p>
        )}
        {loan.ci_notes && (
          <p className="mt-2 rounded-xl bg-muted/50 px-3 py-2 text-xs text-foreground/80">
            <span className="text-muted-foreground">CI findings: </span>
            {loan.ci_notes}
          </p>
        )}
        {borrower && (
          <Link
            to={`/borrowers/${borrower.id}`}
            className="mt-3 inline-block text-xs font-medium text-primary"
          >
            View borrower profile →
          </Link>
        )}
      </section>

      <section className="rounded-2xl border border-border bg-card p-4">
        <h2 className="mb-3 font-heading text-base font-semibold">Repayment schedule</h2>
        <AmortizationTable schedule={position.schedule} loan={loan} />
      </section>

      <section className="rounded-2xl border border-border bg-card p-4">
        <h2 className="mb-3 font-heading text-base font-semibold">Collections</h2>
        <div className="divide-y divide-border">
          {payments.map((payment) => (
            <div key={payment.id} className="flex items-center justify-between py-2.5">
              <div>
                <p className="text-sm font-medium tabular-nums">{peso(payment.amount)}</p>
                <p className="text-[11px] text-muted-foreground">
                  {format(new Date(payment.payment_date), 'd MMM yyyy')} · {payment.method} ·{' '}
                  {payment.receipt_no}
                </p>
              </div>
              <p className="text-[11px] text-muted-foreground">bal {peso(payment.balance_after)}</p>
            </div>
          ))}
          {!payments.length && (
            <p className="py-3 text-sm text-muted-foreground">No collections posted yet.</p>
          )}
        </div>
      </section>

      <section className="rounded-2xl border border-border bg-card p-4">
        <h2 className="mb-3 font-heading text-base font-semibold">Status history</h2>
        <StatusTimeline history={history} />
      </section>

      <WorkflowDialog
        open={dialog === 'review'}
        onOpenChange={(value) => setDialog(value ? 'review' : null)}
        title="Document screening & credit investigation"
        description="Record the field findings. The loan moves to Under Review for the branch manager."
        confirmLabel="Submit for review"
        remarksLabel="Credit investigation notes"
        remarksPlaceholder="House visit done; co-maker verified; weekly income ₱4,500"
        onSubmit={actions.review}
      >
        <div>
          <Label>Risk rating</Label>
          <Select value={risk} onValueChange={setRisk}>
            <SelectTrigger className="mt-1.5">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="ci">CI summary</Label>
          <Input
            id="ci"
            value={ciNotes}
            onChange={(event) => setCiNotes(event.target.value)}
            placeholder="Business stable for 3 years"
            className="mt-1.5"
          />
        </div>
      </WorkflowDialog>

      <WorkflowDialog
        open={dialog === 'recommend'}
        onOpenChange={(value) => setDialog(value ? 'recommend' : null)}
        title={recommendValue === 'approve' ? 'Recommend approval' : 'Recommend rejection'}
        description="Your recommendation goes to the branch manager, who makes the final decision."
        confirmLabel="Send recommendation"
        remarksLabel="Recommendation notes"
        remarksPlaceholder="Stable sari-sari store income; co-maker verified"
        onSubmit={(remarks) => actions.recommend(recommendValue, remarks)}
      />

      <WorkflowDialog
        open={dialog === 'approve'}
        onOpenChange={(value) => setDialog(value ? 'approve' : null)}
        title="Approve loan"
        description={`Approve ${peso(loan.principal)} for ${loan.borrower_name}? The borrower is notified and the release step becomes available.`}
        confirmLabel="Approve"
        remarksLabel="Approval remarks"
        onSubmit={actions.approve}
      />

      <WorkflowDialog
        open={dialog === 'reject'}
        onOpenChange={(value) => setDialog(value ? 'reject' : null)}
        title="Reject application"
        description="The borrower sees the reason in the app, so the decision must be recorded."
        confirmLabel="Reject application"
        danger
        required
        remarksLabel="Reason for rejection *"
        remarksPlaceholder="Insufficient repayment capacity based on CI"
        onSubmit={actions.reject}
      />

      <WorkflowDialog
        open={dialog === 'release'}
        onOpenChange={(value) => setDialog(value ? 'release' : null)}
        title="Release loan proceeds"
        description="Releasing activates the balance and starts the repayment schedule from the release date."
        confirmLabel="Release funds"
        remarksLabel="Release details"
        remarksPlaceholder="Cash released at branch, voucher CV-1042"
        onSubmit={actions.release}
      />

      <RecordPaymentDialog
        loan={loan}
        open={dialog === 'payment'}
        onOpenChange={(value) => setDialog(value ? 'payment' : null)}
        onSaved={load}
      />
    </div>
  );
}