import { useEffect, useRef, useState } from 'react';

const ACTIVITY_EVENTS = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'wheel'];

/** Counts down from `seconds` and calls onIdle when nothing happens; any activity restarts it. */
export default function useIdleLogout(onIdle, seconds = 30) {
  const [remaining, setRemaining] = useState(seconds);
  const deadlineRef = useRef(Date.now() + seconds * 1000);
  const idleRef = useRef(onIdle);
  idleRef.current = onIdle;

  useEffect(() => {
    deadlineRef.current = Date.now() + seconds * 1000;
    setRemaining(seconds);

    const restart = () => {
      deadlineRef.current = Date.now() + seconds * 1000;
      setRemaining(seconds);
    };

    ACTIVITY_EVENTS.forEach((event) => window.addEventListener(event, restart, { passive: true }));

    const ticker = setInterval(() => {
      const left = Math.max(0, Math.ceil((deadlineRef.current - Date.now()) / 1000));
      setRemaining(left);
      if (left === 0) {
        clearInterval(ticker);
        idleRef.current?.();
      }
    }, 500);

    return () => {
      ACTIVITY_EVENTS.forEach((event) => window.removeEventListener(event, restart));
      clearInterval(ticker);
    };
  }, [seconds]);

  return remaining;
}