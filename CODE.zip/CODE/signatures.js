import { base44 } from '@/api/base44Client';
import { addHistory, peso } from '@/lib/loan';
import { logAudit } from '@/lib/audit';

/** Every signature captured on screen is stored here as a private PNG. */
export const SIGNED = 'signed';
export const DECLINED = 'declined';

export async function signaturesForLoan(loanId) {
  const page = await base44.entities.Signature.filter(
    { loan_id: loanId },
    { sort: 'signed_at', limit: 10 }
  );
  return page.items;
}

export async function pendingSignatures(limit = 100) {
  const page = await base44.entities.Signature.filter(
    { decision: SIGNED, manager_status: 'pending' },
    { sort: '-signed_at', limit }
  );
  return page.items;
}

/** Uploads the captured PNG and files the signature record. */
export async function captureSignature({
  loan,
  role,
  signerName,
  contactNumber = '',
  blob,
  decision = SIGNED,
  figures,
  officerName = '',
}) {
  let signature_uri = '';
  if (decision === SIGNED && blob) {
    const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file: blob });
    signature_uri = file_uri;
  }
  return base44.entities.Signature.create({
    loan_id: loan.id,
    loan_no: loan.loan_no,
    borrower_id: loan.borrower_id,
    borrower_name: loan.borrower_name,
    center_group: loan.center_group || '',
    officer_name: officerName || loan.officer_name || '',
    signer_role: role,
    signer_name: signerName.trim(),
    contact_number: contactNumber,
    signature_uri,
    decision,
    signed_at: new Date().toISOString(),
    principal: Number(loan.principal) || 0,
    net_proceeds: Number(figures?.net) || 0,
    insurance_fee: Number(figures?.insurance) || 0,
    manager_status: 'pending',
  });
}

/** Client accepts the disclosure: PNG saved, loan forwarded to the manager. */
export async function acceptByClient({ loan, user, signerName, blob, figures }) {
  const record = await captureSignature({
    loan,
    role: 'client',
    signerName,
    blob,
    figures,
    officerName: loan.officer_name,
  });
  await base44.entities.Loan.update(loan.id, {
    client_decision: 'accepted',
    client_decided_at: record.signed_at,
    client_signature_name: signerName.trim(),
    client_signature_uri: record.signature_uri,
    forwarded_at: record.signed_at,
    declined_by_client: false,
  });
  await addHistory(loan, loan.status, 'Disclosure signed and accepted by client', {
    remarks: `Net proceeds ${peso(figures.net)} · signed by ${signerName.trim()}`,
    actor: signerName.trim(),
  });
  await logAudit({
    user,
    actor_name: signerName.trim(),
    actor_role: 'client',
    action: 'Client signature captured (PNG)',
    entity_type: 'Signature',
    entity_id: record.id,
    reference: loan.loan_no,
    details: `Net proceeds ${peso(figures.net)} · forwarded to the branch manager`,
  });
  return record;
}

/** Co-borrower signs after the client — the second signature on the same disclosure. */
export async function acceptByCoBorrower({ loan, user, signerName, contactNumber, blob, figures }) {
  const record = await captureSignature({
    loan,
    role: 'co_borrower',
    signerName,
    contactNumber,
    blob,
    figures,
    officerName: loan.officer_name,
  });
  await addHistory(loan, loan.status, 'Co-borrower signature captured', {
    remarks: `${signerName.trim()} signed as co-borrower`,
    actor: signerName.trim(),
  });
  await logAudit({
    user,
    actor_name: signerName.trim(),
    actor_role: 'client',
    action: 'Co-borrower signature captured (PNG)',
    entity_type: 'Signature',
    entity_id: record.id,
    reference: loan.loan_no,
    details: `Co-borrower of ${loan.borrower_name}`,
  });
  return record;
}

/** Client says no: the application is rejected and tagged as declined by client. */
export async function declineByClient({ loan, user, signerName }) {
  const record = await captureSignature({
    loan,
    role: 'client',
    signerName: signerName || loan.borrower_name,
    decision: DECLINED,
  });
  await base44.entities.Loan.update(loan.id, {
    status: 'rejected',
    client_decision: 'declined',
    client_decided_at: record.signed_at,
    declined_by_client: true,
    decided_at: record.signed_at,
    decided_by: signerName || loan.borrower_name,
    decision_remarks: 'Declined by client',
  });
  await addHistory(loan, 'rejected', 'Declined by client', {
    remarks: 'The client declined the Loan Disclosure Agreement',
    actor: signerName || loan.borrower_name,
  });
  await logAudit({
    user,
    actor_name: signerName || loan.borrower_name,
    actor_role: 'client',
    action: 'Application declined by client',
    entity_type: 'Loan',
    entity_id: loan.id,
    reference: loan.loan_no,
    details: 'Loan Disclosure Agreement declined — tagged Declined by client',
  });
  return record;
}

export async function markSignaturesDisbursed(loanId, cvNo, actor) {
  await base44.entities.Signature.updateMany(
    { loan_id: loanId },
    { $set: { manager_status: 'disbursed', cv_no: cvNo, reviewed_by: actor, reviewed_at: new Date().toISOString() } }
  );
}