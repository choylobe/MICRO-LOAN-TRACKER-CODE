import React from 'react';
import { format } from 'date-fns';
import { CheckCircle2, Receipt } from 'lucide-react';
import StatusBadge from '@/components/loans/StatusBadge';
import AmortizationTable from '@/components/loans/AmortizationTable';
import PortalRepayForm from '@/components/portal/PortalRepayForm';
import { buildSchedule, peso } from '@/lib/loan';

const dateLabel = (value) => (value ? format(new Date(value), 'd MMM yyyy') : '—');

const CLIENT_STATUS_TEXT = {
  submitted: 'Application received — waiting for document screening.',
  under_review: 'Your application is under credit investigation.',
  approved: 'Approved — waiting for release of funds.',
  rejected: 'Not approved. Please talk to your branch officer.',
  released: 'Loan released — repayments are in progress.',
  closed: 'Fully paid and closed.',
};

export default function PortalLoan({ loan, payments = [], onRepay }) {
  const schedule = buildSchedule(loan);
  const balance = Number(loan.outstanding_balance || 0);
  const open = loan.status === 'released';

  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-heading text-base font-semibold">{loan.loan_no}</p>
          <p className="mt-0.5 text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
            {loan.loan_product || 'Micro loan'} · Cycle {loan.loan_cycle || 1}
          </p>
        </div>
        <StatusBadge status={loan.status} size="sm" />
      </div>

      <p className="mt-2 text-xs text-muted-foreground">
        {CLIENT_STATUS_TEXT[loan.status] || 'Status on file'}
        {loan.status === 'released' && loan.released_at ? ` · released ${dateLabel(loan.released_at)}` : ''}
      </p>

      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <div className="rounded-xl bg-muted/50 px-3 py-2">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Principal</p>
          <p className="mt-0.5 text-sm font-medium tabular-nums">{peso(loan.principal)}</p>
        </div>
        <div className="rounded-xl bg-muted/50 px-3 py-2">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Total payable</p>
          <p className="mt-0.5 text-sm font-medium tabular-nums">{peso(loan.total_payable)}</p>
        </div>
        <div className="rounded-xl bg-muted/50 px-3 py-2">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Installment</p>
          <p className="mt-0.5 text-sm font-medium tabular-nums">{peso(loan.installment_amount)}</p>
        </div>
        <div className="rounded-xl bg-muted/50 px-3 py-2">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
            {open ? 'Balance' : 'Amount paid'}
          </p>
          <p className="mt-0.5 text-sm font-medium tabular-nums">
            {peso(open ? balance : loan.amount_paid)}
          </p>
        </div>
      </div>

      {loan.status === 'closed' && (
        <p className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-emerald-50 px-2.5 py-1.5 text-xs font-medium text-emerald-800">
          <CheckCircle2 className="h-3.5 w-3.5" /> Fully paid
          {loan.closed_at ? ` on ${dateLabel(loan.closed_at)}` : ''}
        </p>
      )}

      <div className="mt-4">
        <h3 className="mb-2 text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
          Repayment schedule
        </h3>
        <AmortizationTable schedule={schedule} loan={loan} />
      </div>

      {payments.length > 0 && (
        <div className="mt-4">
          <h3 className="mb-2 text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
            Payments received
          </h3>
          <ul className="divide-y divide-border/70 overflow-hidden rounded-xl border border-border">
            {payments.map((payment) => (
              <li key={payment.id} className="flex items-center justify-between gap-3 px-3 py-2">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{dateLabel(payment.payment_date)}</p>
                  <p className="text-[11px] text-muted-foreground">
                    <Receipt className="mr-1 inline h-3 w-3" />
                    {payment.receipt_no || 'Receipt'} · {payment.method}
                  </p>
                </div>
                <p className="shrink-0 text-sm font-medium tabular-nums text-emerald-700">
                  {peso(payment.amount)}
                </p>
              </li>
            ))}
          </ul>
        </div>
      )}

      {open && balance > 0.5 && <PortalRepayForm loan={loan} onRepay={onRepay} />}
    </div>
  );
}