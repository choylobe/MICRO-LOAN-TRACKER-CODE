import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import {
  addHistory,
  computeDisclosure,
  DEFAULT_INTEREST_RATE,
  INSURANCE_LABEL,
  INSURANCE_RATE,
  peso,
} from '@/lib/loan';
import { logAudit } from '@/lib/audit';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { FileSignature } from 'lucide-react';

function Row({ label, value, strong, negative }) {
  return (
    <div className="flex items-center justify-between gap-3 py-1.5">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={`tabular-nums ${strong ? 'text-sm font-semibold' : 'text-sm'}`}>
        {negative ? '− ' : ''}
        {value}
      </span>
    </div>
  );
}

/** Account officer CI worksheet: adjustable principal, deductions and net proceeds, then the disclosure to the client. */
export default function DisclosurePanel({ loan, user, onSaved }) {
  const [principal, setPrincipal] = useState(loan.principal ?? 0);
  const [rate, setRate] = useState(loan.interest_rate ?? DEFAULT_INTEREST_RATE);
  const [deductions, setDeductions] = useState(loan.deductions ?? 0);
  const [balance, setBalance] = useState(
    loan.loan_balance_carry ?? loan.outstanding_balance ?? 0
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const figures = computeDisclosure({
    principal,
    interest_rate: rate,
    term_months: loan.term_months,
    payment_frequency: loan.payment_frequency,
    deductions,
    loan_balance_carry: balance,
  });

  const adjusted = Math.round(Number(principal) || 0) !== Math.round(Number(loan.principal) || 0);

  const generate = async () => {
    setError('');
    if (!Number(principal) || Number(principal) < 1000) {
      setError('The principal must be at least ₱1,000.');
      return;
    }
    if (!Number(rate)) {
      setError('Enter the interest rate for this loan.');
      return;
    }
    setSaving(true);
    try {
      await base44.entities.Loan.update(loan.id, {
        principal: Number(principal),
        applied_principal: adjusted ? Number(loan.applied_principal || loan.principal) : loan.applied_principal,
        principal_adjusted_by: adjusted
          ? user?.full_name || user?.email || 'Account officer'
          : loan.principal_adjusted_by,
        interest_rate: Number(rate),
        total_interest: figures.interest,
        total_payable: figures.effective,
        installment_amount: figures.installment,
        deductions: Number(deductions) || 0,
        loan_balance_carry: Number(balance) || 0,
        insurance_rate: INSURANCE_RATE,
        insurance_fee: figures.insurance,
        net_proceeds: figures.net,
        disclosure_at: new Date().toISOString(),
        disclosure_by: user?.full_name || user?.email || 'Account officer',
      });
      await addHistory(loan, loan.status, 'Loan Disclosure Agreement generated', {
        remarks: `Principal ${peso(figures.principal)} · net proceeds ${peso(figures.net)} · insurance ${peso(figures.insurance)}`,
        actor: user?.full_name || 'Account officer',
      });
      await logAudit({
        user,
        action: adjusted ? 'Principal adjusted and disclosure generated' : 'Loan Disclosure Agreement generated',
        entity_type: 'Loan',
        entity_id: loan.id,
        reference: loan.loan_no,
        details: `Principal ${peso(figures.principal)}${adjusted ? ` (applied for ${peso(loan.principal)})` : ''} · interest ${peso(figures.interest)} · insurance ${peso(figures.insurance)} · net ${peso(figures.net)}`,
        amount: figures.net,
      });
      await onSaved?.();
    } catch (err) {
      setError('The disclosure could not be saved. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-center gap-2">
        <FileSignature className="h-4 w-4 text-primary" />
        <h2 className="font-heading text-base font-semibold">CI terms &amp; disclosure</h2>
      </div>
      <p className="mt-1 text-xs text-muted-foreground">
        Adjust the approved principal if needed, set the interest and deductions. The client reviews
        the net proceeds, signs, and only then does the application reach the branch manager.
      </p>

      <div className="mt-3 grid grid-cols-2 gap-2">
        <div className="col-span-2">
          <Label htmlFor="principal">Principal for this loan (₱)</Label>
          <Input
            id="principal"
            type="number"
            inputMode="decimal"
            value={principal}
            onChange={(event) => setPrincipal(event.target.value)}
            className="mt-1.5"
          />
          <p className="mt-1 text-[10px] leading-snug text-muted-foreground">
            {adjusted
              ? `Adjusted from the ${peso(loan.principal)} applied for. Net proceeds below are recomputed.`
              : 'Adjust before generating the net proceeds.'}
          </p>
        </div>
        <div>
          <Label htmlFor="rate">Interest rate (% monthly)</Label>
          <Input
            id="rate"
            type="number"
            step="0.1"
            value={rate}
            onChange={(event) => setRate(event.target.value)}
            className="mt-1.5"
          />
        </div>
        <div>
          <Label htmlFor="deductions">Loan deductions</Label>
          <Input
            id="deductions"
            type="number"
            step="0.01"
            value={deductions}
            onChange={(event) => setDeductions(event.target.value)}
            className="mt-1.5"
          />
        </div>
        <div className="col-span-2">
          <Label htmlFor="balance">Loan balance carried from previous loan</Label>
          <Input
            id="balance"
            type="number"
            step="0.01"
            value={balance}
            onChange={(event) => setBalance(event.target.value)}
            className="mt-1.5"
          />
        </div>
      </div>

      <div className="mt-3 divide-y divide-border rounded-xl bg-muted/40 px-3">
        <Row label="Principal" value={peso(figures.principal)} />
        <Row label="Interest" value={peso(figures.interest)} />
        <Row label="Effective interest (principal + interest)" value={peso(figures.effective)} />
        <Row label={INSURANCE_LABEL} value={peso(figures.insurance)} negative />
        <Row label="Loan balance" value={peso(figures.balance)} negative />
        <Row label="Loan deductions" value={peso(figures.deductions)} negative />
        <Row label="Net loan proceeds" value={peso(figures.net)} strong />
      </div>

      {error && <p className="mt-2 text-xs text-destructive">{error}</p>}

      <Button className="mt-3 w-full" onClick={generate} disabled={saving}>
        {saving
          ? 'Generating…'
          : loan.disclosure_at
            ? 'Update disclosure for client signature'
            : 'Generate Loan Disclosure Agreement'}
      </Button>
      {loan.disclosure_at && !loan.client_decision && (
        <p className="mt-2 text-[11px] text-amber-700">
          Sent to the client window — waiting for signature and verification.
        </p>
      )}
    </section>
  );
}