import React, { useEffect, useMemo, useState } from 'react';
import { format } from 'date-fns';
import { ClipboardList, Loader2, Printer } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { fullName, isManager, officerCenters, peso } from '@/lib/loan';
import { loanDues, weekWindow } from '@/lib/collectionSheet';

export default function CollectionSheet() {
  const { user } = useAuth();
  const [loans, setLoans] = useState([]);
  const [borrowers, setBorrowers] = useState({});
  const [loading, setLoading] = useState(true);
  const [center, setCenter] = useState('all');

  const week = useMemo(() => weekWindow(new Date()), []);
  const manager = isManager(user);
  const centers = officerCenters(user);

  useEffect(() => {
    let active = true;
    (async () => {
      const query = { status: 'released' };
      if (!manager && centers.length) query.center_group = { $in: centers };

      const page = await base44.entities.Loan.filter(query, {
        sort: 'borrower_name',
        limit: 300,
      });
      const items = page.items || [];
      const ids = [...new Set(items.map((loan) => loan.borrower_id).filter(Boolean))];

      let book = {};
      if (ids.length) {
        const recordPage = await base44.entities.Borrower.filter(
          { id: { $in: ids } },
          { limit: 300 }
        );
        book = Object.fromEntries((recordPage.items || []).map((record) => [record.id, record]));
      }

      if (!active) return;
      setBorrowers(book);
      setLoans(items);
      setLoading(false);
    })();
    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const cutoff = week.end;

  const rows = useMemo(
    () =>
      loans
        .map((loan) => {
          const dues = loanDues(loan, week);
          return { loan, dues, borrower: borrowers[loan.borrower_id] || {} };
        })
        .filter((row) => row.dues.total > 1)
        .filter((row) => center === 'all' || row.loan.center_group === center)
        .sort(
          (a, b) =>
            String(a.loan.center_group || '').localeCompare(String(b.loan.center_group || '')) ||
            String(a.loan.borrower_name || '').localeCompare(String(b.loan.borrower_name || ''))
        ),
    [loans, borrowers, week, center]
  );

  const centerOptions = useMemo(
    () => [...new Set(loans.map((loan) => loan.center_group).filter(Boolean))].sort(),
    [loans]
  );

  const totals = rows.reduce(
    (acc, row) => ({
      thisWeek: acc.thisWeek + row.dues.thisWeek,
      pastDue: acc.pastDue + row.dues.pastDue,
      total: acc.total + row.dues.total,
    }),
    { thisWeek: 0, pastDue: 0, total: 0 }
  );

  if (loading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center text-muted-foreground">
        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Preparing the collection sheet
      </div>
    );
  }

  return (
    <div className="space-y-5 print:space-y-3">
      <div className="flex flex-wrap items-start justify-between gap-3 print:hidden">
        <div>
          <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
            Field collections
          </p>
          <h1 className="mt-1 flex items-center gap-2 font-heading text-2xl font-semibold tracking-tight">
            <ClipboardList className="h-5 w-5 text-primary" /> Weekly collection sheet
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {format(week.start, 'd MMM')} – {format(week.end, 'd MMM yyyy')} ·{' '}
            {manager ? 'all centers' : centers.length ? centers.join(', ') : 'all centers'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {centerOptions.length > 1 && (
            <Select value={center} onValueChange={setCenter}>
              <SelectTrigger className="w-52">
                <SelectValue placeholder="All centers" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All centers</SelectItem>
                {centerOptions.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          <Button onClick={() => window.print()}>
            <Printer className="h-4 w-4" /> Print sheet
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 print:hidden">
        <span className="rounded-full border border-border bg-card px-3 py-1 text-xs">
          <strong className="font-semibold">{rows.length}</strong> borrowers due
        </span>
        <span className="rounded-full border border-border bg-card px-3 py-1 text-xs">
          This week <strong className="font-semibold">{peso(totals.thisWeek)}</strong>
        </span>
        <span className="rounded-full border border-border bg-card px-3 py-1 text-xs">
          Past due <strong className="font-semibold text-rose-600">{peso(totals.pastDue)}</strong>
        </span>
        <span className="rounded-full border border-primary/25 bg-primary/5 px-3 py-1 text-xs">
          To collect <strong className="font-semibold">{peso(totals.total)}</strong>
        </span>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-border bg-card p-4 print:rounded-none print:border-0 print:p-0">
        <div className="mb-3 hidden items-baseline justify-between border-b border-border pb-2 print:flex">
          <div>
            <p className="font-heading text-base font-semibold">CARD Inc — Weekly collection sheet</p>
            <p className="text-[11px] text-muted-foreground">
              {format(week.start, 'd MMM')} – {format(week.end, 'd MMM yyyy')} ·{' '}
              {center === 'all' ? 'All centers' : center}
            </p>
          </div>
          <p className="text-[11px] text-muted-foreground">
            Officer: {fullName(user)} · Printed {format(new Date(), 'd MMM yyyy HH:mm')}
          </p>
        </div>

        <table className="w-full min-w-[720px] border-collapse text-left text-xs">
          <thead>
            <tr className="border-b border-border text-[10px] uppercase tracking-[0.1em] text-muted-foreground">
              <th className="w-8 py-2 pr-2 font-medium">#</th>
              <th className="py-2 pr-2 font-medium">Borrower</th>
              <th className="py-2 pr-2 font-medium">Contact</th>
              <th className="py-2 pr-2 font-medium">Loan / center</th>
              <th className="py-2 pr-2 text-right font-medium">This week</th>
              <th className="py-2 pr-2 text-right font-medium">Past due</th>
              <th className="py-2 pr-2 text-right font-medium">To collect</th>
              <th className="w-32 py-2 font-medium">Collected / signature</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, index) => (
              <tr key={row.loan.id} className="border-b border-border/70 align-top">
                <td className="py-2 pr-2 text-muted-foreground">{index + 1}</td>
                <td className="py-2 pr-2">
                  <p className="font-medium">{row.loan.borrower_name}</p>
                  <p className="text-[11px] text-muted-foreground">
                    {row.borrower.account_no || '—'}
                  </p>
                </td>
                <td className="py-2 pr-2">
                  <p>{row.borrower.contact_number || '—'}</p>
                  <p className="text-[11px] text-muted-foreground">
                    {row.borrower.co_maker_name ? `Co-maker: ${row.borrower.co_maker_name}` : ''}
                  </p>
                </td>
                <td className="py-2 pr-2">
                  <p>{row.loan.loan_no}</p>
                  <p className="text-[11px] text-muted-foreground">{row.loan.center_group || '—'}</p>
                </td>
                <td className="py-2 pr-2 text-right">{peso(row.dues.thisWeek)}</td>
                <td className="py-2 pr-2 text-right text-rose-600">
                  {row.dues.pastDue > 0 ? peso(row.dues.pastDue) : '—'}
                </td>
                <td className="py-2 pr-2 text-right font-semibold">{peso(row.dues.total)}</td>
                <td className="py-2">
                  <div className="h-6 border-b border-dashed border-border" />
                </td>
              </tr>
            ))}
            {!rows.length && (
              <tr>
                <td colSpan={8} className="py-8 text-center text-muted-foreground">
                  No payments are due in your centers for this week.
                </td>
              </tr>
            )}
          </tbody>
          {rows.length > 0 && (
            <tfoot>
              <tr className="border-t-2 border-border font-semibold">
                <td className="py-2" colSpan={4}>
                  Total — {rows.length} borrowers
                </td>
                <td className="py-2 pr-2 text-right">{peso(totals.thisWeek)}</td>
                <td className="py-2 pr-2 text-right">{peso(totals.pastDue)}</td>
                <td className="py-2 pr-2 text-right">{peso(totals.total)}</td>
                <td className="py-2" />
              </tr>
            </tfoot>
          )}
        </table>
      </div>

      <div className="flex flex-wrap items-end justify-between gap-6 text-[11px] text-muted-foreground print:pt-8">
        <p className="max-w-md">
          Amounts cover the week ending {format(cutoff, 'd MMM yyyy')} plus any unpaid past dues.
          Mark each collection with the amount received and have the borrower sign.
        </p>
        <div className="flex gap-10">
          <div>
            <div className="h-8 w-40 border-b border-border" />
            <p className="mt-1">Collected by</p>
          </div>
          <div>
            <div className="h-8 w-40 border-b border-border" />
            <p className="mt-1">Branch manager</p>
          </div>
        </div>
      </div>
    </div>
  );
}