import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { isClient } from '@/lib/roles';

/** Branch staff screens — client logins are sent to their own loan view. */
export default function StaffOnly() {
  const { user } = useAuth();
  if (isClient(user)) return <Navigate to="/" replace />;
  return <Outlet />;
}