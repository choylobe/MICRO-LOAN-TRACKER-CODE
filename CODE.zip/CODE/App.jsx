import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import Layout from '@/components/Layout';
import StaffOnly from '@/components/StaffOnly';
import ManagerOnly from '@/components/ManagerOnly';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import Dashboard from '@/pages/Dashboard';
import Loans from '@/pages/Loans';
import CollectionSheet from '@/pages/CollectionSheet';
import NewLoan from '@/pages/NewLoan';
import LoanDetail from '@/pages/LoanDetail';
import Borrowers from '@/pages/Borrowers';
import ClientMonitoring from '@/pages/ClientMonitoring';
import BorrowerDetail from '@/pages/BorrowerDetail';
import Blueprints from '@/pages/Blueprints';
import Team from '@/pages/Team';
import ClientPortal from '@/pages/ClientPortal';
import ClientApply from '@/pages/ClientApply';
import AuditTrail from '@/pages/AuditTrail';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Public client status links stay reachable without signing in
  const isPublicStatusLink = window.location.pathname.startsWith('/status');

  // Handle authentication errors
  if (authError && !isPublicStatusLink) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/status" element={<ClientPortal />} />
      <Route path="/status/:borrowerNo" element={<ClientPortal />} />

      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/apply" element={<ClientApply />} />
          <Route element={<StaffOnly />}>
            <Route path="/loans" element={<Loans />} />
            <Route path="/loans/new" element={<NewLoan />} />
            <Route path="/loans/:id" element={<LoanDetail />} />
            <Route path="/collections" element={<CollectionSheet />} />
            <Route path="/monitoring" element={<ClientMonitoring />} />
            <Route path="/borrowers" element={<Borrowers />} />
            <Route path="/borrowers/:id" element={<BorrowerDetail />} />
            <Route path="/blueprints" element={<Blueprints />} />
            <Route element={<ManagerOnly />}>
              <Route path="/team" element={<Team />} />
              <Route path="/audit" element={<AuditTrail />} />
            </Route>
          </Route>
        </Route>
      </Route>

      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App