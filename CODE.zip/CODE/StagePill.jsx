import React from 'react';
import { STAGE_META } from '@/lib/monitoring';

export default function StagePill({ stage, size = 'md' }) {
  const meta = STAGE_META[stage] || STAGE_META.prospect;
  return (
    <span
      className={`inline-flex shrink-0 items-center gap-1.5 rounded-full border font-medium ${meta.badge} ${
        size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-[11px]'
      }`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
      {meta.label}
    </span>
  );
}