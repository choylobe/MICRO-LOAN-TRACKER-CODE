import React from 'react';

export const C = {
  ink: '#132b26',
  muted: '#6b7c76',
  line: '#c9c1b1',
  card: '#ffffff',
  soft: '#f6f2e9',
  green: '#17604c',
  greenSoft: '#e7f1ec',
  gold: '#d99b32',
  rose: '#b8455a',
  sky: '#e6eef6',
};

export function wrap(text, maxChars) {
  const words = String(text).split(' ');
  const lines = [];
  let current = '';
  words.forEach((word) => {
    if (!current) {
      current = word;
    } else if ((current + ' ' + word).length <= maxChars) {
      current += ' ' + word;
    } else {
      lines.push(current);
      current = word;
    }
  });
  if (current) lines.push(current);
  return lines;
}

export function Frame({ width, height, caption, children }) {
  return (
    <figure className="space-y-2">
      <div className="overflow-x-auto rounded-2xl border border-border bg-card p-2">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          width={width}
          height={height}
          className="h-auto w-full min-w-[700px]"
          style={{ fontFamily: 'Inter, sans-serif' }}
        >
          <defs>
            <marker
              id="arw"
              viewBox="0 0 10 10"
              refX="9"
              refY="5"
              markerWidth="7"
              markerHeight="7"
              orient="auto-start-reverse"
            >
              <path d="M0,0 L10,5 L0,10 z" fill={C.ink} />
            </marker>
          </defs>
          {children}
        </svg>
      </div>
      {caption && <figcaption className="text-xs leading-relaxed text-muted-foreground">{caption}</figcaption>}
    </figure>
  );
}

export function Lane({ x1, x2, y1, y2, label, alt }) {
  return (
    <g>
      <rect
        x={x1}
        y={y1}
        width={x2 - x1}
        height={y2 - y1}
        fill={alt ? '#faf7f0' : '#fdfbf7'}
        stroke={C.line}
        strokeWidth="1"
      />
      <text x={x1 + 12} y={y1 + 16} fontSize="9" letterSpacing="1.5" fontWeight="600" fill={C.muted}>
        {label.toUpperCase()}
      </text>
    </g>
  );
}

export function Task({ x, y, w = 160, h = 56, label, tone = 'user' }) {
  const lines = wrap(label, Math.floor(w / 5.6));
  const lineHeight = 11.5;
  const startY = y - ((lines.length - 1) * lineHeight) / 2 + 3.5;
  const fill = tone === 'system' ? C.greenSoft : C.card;
  return (
    <g>
      <rect
        x={x - w / 2}
        y={y - h / 2}
        width={w}
        height={h}
        rx="8"
        fill={fill}
        stroke={tone === 'system' ? C.green : C.line}
        strokeWidth="1.1"
      />
      <text x={x} y={startY} fontSize="10" fill={C.ink} textAnchor="middle">
        {lines.map((line, index) => (
          <tspan key={index} x={x} dy={index === 0 ? 0 : lineHeight}>
            {line}
          </tspan>
        ))}
      </text>
    </g>
  );
}

export function Gateway({ x, y, label, w = 32, h = 26 }) {
  return (
    <g>
      <path
        d={`M${x},${y - h} L${x + w},${y} L${x},${y + h} L${x - w},${y} Z`}
        fill={C.card}
        stroke={C.ink}
        strokeWidth="1.1"
      />
      {label && (
        <text x={x} y={y + h + 12} fontSize="9" fill={C.muted} textAnchor="middle">
          {label}
        </text>
      )}
    </g>
  );
}

export function BpmnStart({ x, y, label }) {
  return (
    <g>
      <circle cx={x} cy={y} r="15" fill={C.card} stroke={C.ink} strokeWidth="1.5" />
      {label && (
        <text x={x} y={y + 27} fontSize="9" fill={C.muted} textAnchor="middle">
          {label}
        </text>
      )}
    </g>
  );
}

export function BpmnEnd({ x, y, label, tone = 'ok' }) {
  return (
    <g>
      <circle
        cx={x}
        cy={y}
        r="15"
        fill={C.card}
        stroke={tone === 'bad' ? C.rose : C.ink}
        strokeWidth="3"
      />
      {label && (
        <text
          x={x}
          y={y + 27}
          fontSize="9"
          fill={tone === 'bad' ? C.rose : C.muted}
          textAnchor="middle"
        >
          {label}
        </text>
      )}
    </g>
  );
}

export function Flow({ points, label, at, dashed }) {
  const d = 'M' + points.map((point) => point.join(' ')).join(' L ');
  const mid = points.length > 1 ? points[Math.floor(points.length / 2)] : points[0];
  const position = at || [mid[0] + 4, mid[1] - 5];
  return (
    <g>
      <path
        d={d}
        fill="none"
        stroke={dashed ? C.muted : C.ink}
        strokeWidth="1.1"
        strokeDasharray={dashed ? '4 3' : undefined}
        markerEnd="url(#arw)"
      />
      {label && (
        <text
          x={position[0]}
          y={position[1]}
          fontSize="8.8"
          fill={C.muted}
          textAnchor="middle"
          paintOrder="stroke"
          stroke="#fdfbf7"
          strokeWidth="3"
        >
          {label}
        </text>
      )}
    </g>
  );
}

export function DfdEntity({ x, y, w = 120, h = 50, label, sub }) {
  const lines = wrap(label, 16);
  return (
    <g>
      <rect x={x - w / 2} y={y - h / 2} width={w} height={h} rx="4" fill={C.soft} stroke={C.ink} strokeWidth="1.1" />
      <text x={x} y={y - ((lines.length - 1) * 10) / 2 + 3} fontSize="10" fill={C.ink} textAnchor="middle" fontWeight="500">
        {lines.map((line, index) => (
          <tspan key={index} x={x} dy={index === 0 ? 0 : 10}>
            {line}
          </tspan>
        ))}
      </text>
      {sub && (
        <text x={x} y={y + h / 2 + 12} fontSize="8" fill={C.muted} textAnchor="middle">
          {sub}
        </text>
      )}
    </g>
  );
}

export function DfdProcess({ x, y, r = 50, label }) {
  const lines = wrap(label, 17);
  return (
    <g>
      <circle cx={x} cy={y} r={r} fill={C.card} stroke={C.green} strokeWidth="1.4" />
      <text x={x} y={y - ((lines.length - 1) * 10) / 2 + 3} fontSize="9.5" fill={C.ink} textAnchor="middle">
        {lines.map((line, index) => (
          <tspan key={index} x={x} dy={index === 0 ? 0 : 10}>
            {line}
          </tspan>
        ))}
      </text>
    </g>
  );
}

export function DataStore({ x, y, w = 180, h = 34, id, label }) {
  return (
    <g>
      <rect x={x - w / 2} y={y - h / 2} width={w} height={h} fill={C.card} stroke={C.ink} strokeWidth="1.1" />
      <line x1={x - w / 2 + 34} y1={y - h / 2} x2={x - w / 2 + 34} y2={y + h / 2} stroke={C.ink} strokeWidth="1.1" />
      <text x={x - w / 2 + 17} y={y + 3.5} fontSize="9.5" fill={C.ink} textAnchor="middle" fontWeight="600">
        {id}
      </text>
      <text x={x - w / 2 + 45} y={y + 3.5} fontSize="9.5" fill={C.ink}>
        {label}
      </text>
    </g>
  );
}

export function ErdEntity({ x, y, w = 220, title, rows }) {
  const rowHeight = 19;
  const header = 26;
  return (
    <g>
      <rect
        x={x}
        y={y}
        width={w}
        height={header + rows.length * rowHeight + 6}
        rx="6"
        fill={C.card}
        stroke={C.ink}
        strokeWidth="1.1"
      />
      <path
        d={`M${x},${y + header} H${x + w}`}
        stroke={C.ink}
        strokeWidth="1.1"
      />
      <text x={x + 10} y={y + 17} fontSize="9.5" fontWeight="700" letterSpacing="0.8" fill={C.green}>
        {title}
      </text>
      {rows.map((row, index) => (
        <g key={row.name}>
          <text
            x={x + 10}
            y={y + header + 15 + index * rowHeight}
            fontSize="9.5"
            fill={C.ink}
            fontWeight={row.key ? '600' : '400'}
            textDecoration={row.key === 'PK' ? 'underline' : undefined}
          >
            {row.name}
          </text>
          {row.key && (
            <text
              x={x + w - 10}
              y={y + header + 15 + index * rowHeight}
              fontSize="8.5"
              fill={row.key === 'PK' ? C.green : C.muted}
              textAnchor="end"
              fontWeight="600"
            >
              {row.key}
            </text>
          )}
        </g>
      ))}
    </g>
  );
}

export function Rel({ points, left, right }) {
  const d = 'M' + points.map((point) => point.join(' ')).join(' L ');
  const start = points[0];
  const end = points[points.length - 1];
  return (
    <g>
      <path d={d} fill="none" stroke={C.muted} strokeWidth="1.1" />
      {left && (
        <text x={start[0] + 8} y={start[1] - 6} fontSize="9" fill={C.ink} fontWeight="600">
          {left}
        </text>
      )}
      {right && (
        <text x={end[0] - 8} y={end[1] - 6} fontSize="9" fill={C.ink} fontWeight="600" textAnchor="end">
          {right}
        </text>
      )}
    </g>
  );
}