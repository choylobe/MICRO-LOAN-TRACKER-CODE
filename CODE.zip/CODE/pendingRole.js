/** Remembers the role chosen at sign-up until the new account first logs in. */

const KEY = 'card.pendingStaffRole';

export function rememberPendingRole(role) {
  try {
    if (role) localStorage.setItem(KEY, role);
  } catch (err) {
    // storage unavailable — the account keeps its derived role
  }
}

export function consumePendingRole() {
  try {
    const role = localStorage.getItem(KEY);
    if (role) localStorage.removeItem(KEY);
    return role;
  } catch (err) {
    return null;
  }
}