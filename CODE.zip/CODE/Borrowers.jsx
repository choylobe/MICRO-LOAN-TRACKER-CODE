import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Plus, ChevronRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { borrowerVisibleToOfficer, pesoShort } from '@/lib/loan';
import { useAuth } from '@/lib/AuthContext';

export default function Borrowers() {
  const { user } = useAuth();
  const [search, setSearch] = useState('');
  const [borrowers, setBorrowers] = useState(null);
  const [loans, setLoans] = useState([]);

  useEffect(() => {
    (async () => {
      const [borrowerPage, loanPage] = await Promise.all([
        base44.entities.Borrower.list({ sort: 'full_name', limit: 100 }),
        base44.entities.Loan.list({ sort: '-created_date', limit: 200 }),
      ]);
      setBorrowers(borrowerPage.items);
      setLoans(loanPage.items);
    })();
  }, []);

  const term = search.trim().toLowerCase();
  const filtered = (borrowers || [])
    .filter((borrower) => borrowerVisibleToOfficer(user, borrower))
    .filter(
      (borrower) =>
        !term ||
        borrower.full_name?.toLowerCase().includes(term) ||
        borrower.borrower_no?.toLowerCase().includes(term) ||
        borrower.center_group?.toLowerCase().includes(term)
    );

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="font-heading text-[26px] font-semibold leading-tight">Borrowers</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {borrowers ? `${borrowers.length} profiles on file` : 'Loading profiles…'}
          </p>
        </div>
        <Link
          to="/loans/new"
          className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground"
          aria-label="New loan application"
        >
          <Plus className="h-4 w-4" />
        </Link>
      </div>

      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search name, borrower no. or center"
          className="h-11 rounded-xl pl-9"
        />
      </div>

      {!borrowers && (
        <div className="space-y-3">
          {[0, 1, 2].map((key) => (
            <div key={key} className="h-20 animate-pulse rounded-2xl bg-muted" />
          ))}
        </div>
      )}

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        {filtered.map((borrower) => {
          const own = loans.filter((loan) => loan.borrower_id === borrower.id);
          const active = own.find((loan) => loan.status === 'released');
          return (
            <Link
              key={borrower.id}
              to={`/borrowers/${borrower.id}`}
              className="flex items-center gap-3 border-b border-border/70 px-4 py-3 last:border-0 transition hover:bg-muted/40"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                {borrower.full_name
                  ?.split(' ')
                  .map((part) => part[0])
                  .slice(0, 2)
                  .join('')}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{borrower.full_name}</p>
                <p className="truncate text-[11px] text-muted-foreground">
                  {borrower.borrower_no} · {borrower.center_group || borrower.branch || 'Walk-in'}
                </p>
              </div>
              <div className="text-right">
                <p className="text-xs font-medium tabular-nums">
                  {active ? pesoShort(active.outstanding_balance) : '—'}
                </p>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
                  {active ? 'Balance' : `${own.length} loan${own.length === 1 ? '' : 's'}`}
                </p>
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </Link>
          );
        })}
        {borrowers && !filtered.length && (
          <p className="px-4 py-8 text-center text-sm text-muted-foreground">
            No borrower matches “{search}”.
          </p>
        )}
      </div>
    </div>
  );
}