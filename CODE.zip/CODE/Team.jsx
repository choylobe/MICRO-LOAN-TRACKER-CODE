import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { ROLE_META } from '@/lib/roles';
import RoleBadge from '@/components/RoleBadge';
import TeamMemberCard from '@/components/team/TeamMemberCard';
import GroupReassignDialog from '@/components/team/GroupReassignDialog';
import { logAudit } from '@/lib/audit';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowRightLeft, Search, Users } from 'lucide-react';

export default function Team() {
  const { user } = useAuth();
  const [rows, setRows] = useState(null);
  const [borrowers, setBorrowers] = useState([]);
  const [search, setSearch] = useState('');
  const [savingId, setSavingId] = useState(null);
  const [error, setError] = useState('');
  const [reassign, setReassign] = useState(false);

  useEffect(() => {
    (async () => {
      const [users, borrowerPage] = await Promise.all([
        base44.entities.User.list(),
        base44.entities.Borrower.filter({}, { sort: 'full_name', limit: 300 }),
      ]);
      setRows(users);
      setBorrowers(borrowerPage.items);
    })();
  }, []);

  const reloadUsers = async () => {
    const users = await base44.entities.User.list();
    setRows(users);
  };

  const groups = useMemo(() => {
    const names = new Set(
      borrowers.map((borrower) => borrower.center_group).filter(Boolean)
    );
    (rows || []).forEach((record) => {
      if (record.assigned_group) names.add(record.assigned_group);
      (Array.isArray(record.assigned_groups) ? record.assigned_groups : []).forEach((name) =>
        names.add(name)
      );
    });
    return [...names].sort();
  }, [borrowers, rows]);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    const list = rows || [];
    if (!term) return list;
    return list.filter((record) =>
      `${record.full_name || ''} ${record.email || ''}`.toLowerCase().includes(term)
    );
  }, [rows, search]);

  const save = async (record, patch) => {
    setSavingId(record.id);
    setError('');
    try {
      const updated = await base44.entities.User.update(record.id, patch);
      await logAudit({
        user,
        action: 'Team account updated',
        entity_type: 'User',
        entity_id: record.id,
        reference: record.full_name || record.email,
        details: Object.entries(patch)
          .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(', ') || 'none' : value}`)
          .join(' · '),
      });
      setRows((list) =>
        list.map((item) =>
          item.id === record.id ? { ...item, ...patch, ...(updated || {}) } : item
        )
      );
    } catch (err) {
      setError('That change could not be saved. Please try again.');
    } finally {
      setSavingId(null);
    }
  };

  const disabledCount = (rows || []).filter((record) => record.account_status === 'disabled').length;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-heading text-[26px] font-semibold leading-tight">Team &amp; clients</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Signed in as <span className="font-medium text-foreground">{user?.full_name || 'Manager'}</span> ·{' '}
          <RoleBadge user={user} size="sm" />
        </p>
      </div>

      <div className="rounded-2xl border border-border bg-card p-4 text-xs text-muted-foreground">
        <p className="font-medium text-foreground">Admin controls</p>
        <ul className="mt-2 space-y-1.5">
          <li>Edit a client's or account officer's name.</li>
          <li>Assign the client group an account officer handles.</li>
          <li>Enable or disable a login across all users.</li>
          <li>Appoint another branch admin while the manager is on leave.</li>
        </ul>
        <p className="mt-2">
          {ROLE_META.manager.label} — {ROLE_META.manager.summary}.
        </p>
        <Button
          type="button"
          size="sm"
          variant="outline"
          className="mt-3 w-full sm:w-auto"
          onClick={() => setReassign(true)}
        >
          <ArrowRightLeft className="h-3.5 w-3.5" /> Reassign a client group
        </Button>
      </div>

      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search name or email"
          className="pl-9"
        />
      </div>

      {error && <p className="rounded-xl bg-rose-50 px-3 py-2 text-xs text-rose-700">{error}</p>}

      {rows && (
        <p className="text-[11px] text-muted-foreground">
          {rows.length} account{rows.length === 1 ? '' : 's'} · {disabledCount} disabled
        </p>
      )}

      {!rows && (
        <div className="space-y-2">
          {[0, 1, 2].map((key) => (
            <div key={key} className="h-32 animate-pulse rounded-2xl bg-muted" />
          ))}
        </div>
      )}

      {rows && (
        <div className="space-y-2">
          {filtered.map((record) => (
            <TeamMemberCard
              key={record.id}
              record={record}
              borrowers={borrowers}
              groups={groups}
              onSave={save}
              saving={savingId === record.id}
            />
          ))}

          {!filtered.length && (
            <p className="rounded-2xl border border-dashed border-border p-6 text-sm text-muted-foreground">
              No team member matches that search.
            </p>
          )}
        </div>
      )}

      <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
        <Users className="h-3.5 w-3.5" /> Invite new staff and clients from App Users in the dashboard.
      </p>

      <GroupReassignDialog
        open={reassign}
        onOpenChange={setReassign}
        rows={rows || []}
        groups={groups}
        onDone={reloadUsers}
      />
    </div>
  );
}