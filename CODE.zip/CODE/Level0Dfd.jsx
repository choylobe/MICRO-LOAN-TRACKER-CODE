import React from 'react';
import { Frame, DfdEntity, DfdProcess, DataStore, Flow, C } from '@/components/docs/diagram';

export default function Level0Dfd() {
  return (
    <Frame
      width={1320}
      height={640}
      caption="Level-0 DFD · four logical processes, four data stores. Inputs and outputs balance with the context diagram."
    >
      <DfdEntity x={90} y={110} w={110} h={50} label="Borrower" />
      <DfdEntity x={90} y={470} w={110} h={50} label="Loan Officer" />
      <DfdEntity x={1210} y={110} w={110} h={50} label="Branch Manager" />

      <DfdProcess x={380} y={110} label="1.0 Manage Borrower Records" />
      <DfdProcess x={700} y={110} label="2.0 Process Loan Application" />
      <DfdProcess x={1020} y={110} label="3.0 Evaluate and Approve Loan" />
      <DfdProcess x={700} y={470} label="4.0 Record Payments and Monitor Portfolio" />

      <DataStore x={380} y={260} w={180} id="D1" label="Borrowers" />
      <DataStore x={700} y={260} w={160} id="D2" label="Loans" />
      <DataStore x={1020} y={260} w={190} id="D3" label="Loan Status History" />
      <DataStore x={1020} y={470} w={170} id="D4" label="Payments" />

      <Flow points={[[145, 110], [326, 110]]} label="borrower details" at={[240, 102]} />
      <Flow points={[[90, 84], [90, 40], [700, 40], [700, 58]]} label="loan application" at={[400, 32]} />
      <Flow points={[[1020, 58], [1020, 24], [90, 24], [90, 84]]} label="application status, decision" at={[600, 16]} />

      <Flow points={[[380, 162], [380, 243]]} label="borrower record" at={[440, 200]} />
      <Flow points={[[470, 268], [664, 146]]} label="borrower verification" at={[590, 214]} />
      <Flow points={[[700, 162], [700, 243]]} label="loan record" at={[752, 200]} />
      <Flow points={[[752, 110], [966, 110]]} label="application for approval" at={[860, 102]} />
      <Flow points={[[790, 262], [968, 152]]} label="loan terms" at={[900, 226]} />
      <Flow points={[[1020, 162], [1020, 243]]} label="decision, new status" at={[1088, 200]} />

      <Flow points={[[1155, 96], [1072, 96]]} label="approval / rejection" at={[1118, 88]} />
      <Flow points={[[1072, 124], [1155, 124]]} label="pending applications" at={[1118, 138]} />

      <Flow points={[[145, 462], [646, 462]]} label="collections, field verification" at={[390, 454]} />
      <Flow points={[[648, 486], [145, 486]]} label="collection list, receipts" at={[390, 502]} />
      <Flow points={[[700, 277], [700, 416]]} label="outstanding balance" at={[752, 350]} />
      <Flow points={[[752, 470], [933, 470]]} label="payment record" at={[842, 462]} />
      <Flow points={[[1010, 277], [742, 434]]} label="status history" at={[900, 360]} />
      <Flow points={[[744, 440], [1160, 440], [1160, 136]]} label="portfolio, arrears, collection report" at={[960, 432]} />

      <text x={20} y={620} fontSize="9" fill={C.muted}>
        D1–D4 map directly to the prototype entities: Borrower, Loan, LoanStatusHistory and Payment.
      </text>
    </Frame>
  );
}