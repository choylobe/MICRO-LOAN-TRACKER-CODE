import React, { useState } from 'react';
import { Check, Link2, Send } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

export default function ShareLink({ borrowerNo }) {
  const [copied, setCopied] = useState(false);
  const url = `${window.location.origin}/status/${borrowerNo}`;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({
        title: 'Client link copied',
        description: 'Paste it in Messenger to send the status link.',
      });
    } catch {
      window.prompt('Copy this link', url);
    }
  };

  const share = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `CARD LoanTrack — ${borrowerNo}`,
          text: `Check your loan status (${borrowerNo}): ${url}`,
          url,
        });
        return;
      } catch {
        return;
      }
    }
    copy();
  };

  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        onClick={copy}
        className="inline-flex items-center gap-1 rounded-lg border border-border bg-background px-2.5 py-1.5 text-[11px] font-medium text-muted-foreground transition hover:text-foreground"
      >
        {copied ? <Check className="h-3.5 w-3.5" /> : <Link2 className="h-3.5 w-3.5" />}
        {copied ? 'Link copied' : 'Copy status link'}
      </button>
      <button
        type="button"
        onClick={share}
        className="inline-flex items-center gap-1 rounded-lg border border-border bg-background px-2.5 py-1.5 text-[11px] font-medium text-muted-foreground transition hover:text-foreground"
      >
        <Send className="h-3.5 w-3.5" /> Send via Messenger
      </button>
    </div>
  );
}