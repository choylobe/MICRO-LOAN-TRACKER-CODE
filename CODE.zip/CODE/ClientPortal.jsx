import React, { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { AlertCircle, CheckCircle2, Landmark, Loader2, Search } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import PortalLoan from '@/components/portal/PortalLoan';
import { peso } from '@/lib/loan';

export default function ClientPortal() {
  const { borrowerNo } = useParams();
  const [query, setQuery] = useState(borrowerNo || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [flash, setFlash] = useState('');
  const [data, setData] = useState(null);
  const [selectedId, setSelectedId] = useState(null);

  const lookup = useCallback(async (term) => {
    const value = term.trim();
    if (value.length < 2) {
      setError('Enter at least 2 characters of your name or your borrower ID.');
      return;
    }
    setLoading(true);
    setError('');
    setFlash('');
    try {
      const response = await base44.functions.invoke('clientPortal', { action: 'lookup', query: value });
      const payload = response.data || {};
      if (payload.error) throw new Error(payload.error);
      const matches = payload.borrowers || [];
      setData(payload);
      setSelectedId(matches.length === 1 ? matches[0].id : null);
      if (!matches.length) setError('No client found for that name or ID. Check the spelling or ask your branch officer.');
    } catch (err) {
      setData(null);
      setError(err?.response?.data?.error || err.message || 'Could not reach the branch records right now.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (borrowerNo) lookup(borrowerNo);
  }, [borrowerNo, lookup]);

  const submitSearch = (event) => {
    event.preventDefault();
    lookup(query);
  };

  const borrower = data?.borrowers?.find((item) => item.id === selectedId) || null;
  const loans = borrower ? (data?.loans || []).filter((loan) => loan.borrower_id === borrower.id) : [];
  const payments = data?.payments || [];

  const handleRepay = async (payload) => {
    const response = await base44.functions.invoke('clientPortal', { action: 'repay', ...payload });
    const body = response.data || {};
    if (body.error) throw new Error(body.error);
    await lookup(borrower.borrower_no);
    setFlash(
      body.fullyPaid
        ? 'Fully paid — this loan is now closed. Thank you!'
        : `Repayment recorded. Receipt no. ${body.receipt_no}.`
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-primary text-primary-foreground">
        <div className="mx-auto flex max-w-2xl items-center gap-3 px-4 py-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-foreground/15">
            <Landmark className="h-5 w-5" />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-[0.18em] opacity-70">CARD Inc · LoanTrack</p>
            <h1 className="font-heading text-lg font-semibold leading-tight">Client loan status</h1>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-2xl space-y-4 px-4 py-5">
        <form onSubmit={submitSearch} className="rounded-2xl border border-border bg-card p-4">
          <label htmlFor="portal-search" className="text-xs font-medium">
            Find your loan by name or borrower ID
          </label>
          <p className="mt-1 text-[11px] text-muted-foreground">
            Example: <span className="font-medium text-foreground">Maria Santos</span> or{' '}
            <span className="font-medium text-foreground">BR-0001</span>
          </p>
          <div className="mt-3 flex gap-2">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="portal-search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Your name or borrower ID"
                className="pl-9"
                autoComplete="off"
              />
            </div>
            <Button type="submit" disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Check status'}
            </Button>
          </div>
        </form>

        {error && (
          <p className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-800">
            <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {error}
          </p>
        )}

        {flash && (
          <p className="flex items-start gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-medium text-emerald-800">
            <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {flash}
          </p>
        )}

        {!borrower && (data?.borrowers?.length || 0) > 1 && (
          <div className="rounded-2xl border border-border bg-card p-4">
            <p className="text-sm font-medium">Which client are you?</p>
            <div className="mt-2 space-y-2">
              {data.borrowers.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setSelectedId(item.id)}
                  className="flex w-full items-center justify-between gap-3 rounded-xl border border-border px-3 py-2 text-left transition hover:border-primary/40"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{item.full_name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {item.borrower_no} · {item.center_group || item.branch || 'Branch client'}
                    </p>
                  </div>
                  <span className="shrink-0 text-[11px] font-medium text-primary">Open</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {borrower && (
          <>
            <div className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h2 className="truncate font-heading text-xl font-semibold">{borrower.full_name}</h2>
                  <p className="mt-1 text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
                    Borrow ID {borrower.borrower_no}
                  </p>
                </div>
                <span className="shrink-0 rounded-full border border-border bg-muted/60 px-2.5 py-1 text-[11px] font-medium">
                  {loans.length} loan{loans.length === 1 ? '' : 's'}
                </span>
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                {borrower.center_group || 'Walk-in'} · {borrower.branch || 'Branch'}
              </p>
              {loans[0] && (
                <p className="mt-2 text-xs text-muted-foreground">
                  Outstanding balance{' '}
                  <span className="font-medium text-foreground">{peso(loans[0].outstanding_balance)}</span>
                </p>
              )}
            </div>

            {loans.map((loan) => (
              <PortalLoan
                key={loan.id}
                loan={loan}
                payments={payments.filter((payment) => payment.loan_id === loan.id)}
                onRepay={handleRepay}
              />
            ))}

            {!loans.length && (
              <p className="rounded-2xl border border-dashed border-border p-6 text-sm text-muted-foreground">
                No loan application filed yet for this client.
              </p>
            )}
          </>
        )}

        {!borrower && !data && !error && (
          <p className="rounded-2xl border border-dashed border-border p-6 text-xs text-muted-foreground">
            Open the link your branch officer sent you, or search above to see your application status,
            repayment schedule and balance.
          </p>
        )}

        <p className="pt-2 text-center text-[11px] text-muted-foreground">
          Repayments recorded here are confirmed by your branch officer on collection.{' '}
          <Link to="/login" className="underline underline-offset-2">
            Branch staff sign in
          </Link>
        </p>
      </main>
    </div>
  );
}