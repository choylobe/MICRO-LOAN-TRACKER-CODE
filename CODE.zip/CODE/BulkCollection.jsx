import React, { useMemo, useState } from 'react';
import { format } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { collectionPosition, fullName, peso, postPayment } from '@/lib/loan';
import { logAudit } from '@/lib/audit';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CheckCircle2, ClipboardList } from 'lucide-react';

const payableOf = (loan) => Number(loan.outstanding_balance || 0);

/** Due amount suggestion for one active loan. */
function suggestedAmount(loan) {
  const position = collectionPosition(loan);
  const due = position.arrears > 1 ? position.arrears : Number(loan.installment_amount || 0);
  return Math.min(due, payableOf(loan)) || 0;
}

/** Bulk collection: tick the clients paying today, post one cash receipt. */
export default function BulkCollection({ loans, user, onPosted }) {
  const [selected, setSelected] = useState({});
  const [cash, setCash] = useState('');
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState('');
  const [posted, setPosted] = useState(null);

  const active = useMemo(
    () => (loans || []).filter((loan) => loan.status === 'released'),
    [loans]
  );

  const rows = active.map((loan) => ({ loan, suggested: suggestedAmount(loan) }));
  const total = Object.entries(selected).reduce(
    (sum, [, amount]) => sum + (Number(amount) || 0),
    0
  );
  const count = Object.keys(selected).length;

  const toggle = (loan) => {
    setPosted(null);
    setSelected((current) => {
      const next = { ...current };
      if (next[loan.id] !== undefined) delete next[loan.id];
      else next[loan.id] = String(suggestedAmount(loan).toFixed(2));
      return next;
    });
  };

  const setAmount = (id, value) =>
    setSelected((current) => ({ ...current, [id]: value }));

  const selectAllDue = () => {
    const next = {};
    rows.forEach(({ loan, suggested }) => {
      if (suggested > 0) next[loan.id] = String(suggested.toFixed(2));
    });
    setSelected(next);
  };

  const clear = () => {
    setSelected({});
    setCash('');
    setError('');
  };

  const post = async () => {
    setError('');
    if (!count) {
      setError('Tick at least one client to collect from.');
      return;
    }
    const receipt = Number(cash);
    if (!receipt || receipt + 0.01 < total) {
      setError(`Cash received must cover the ${peso(total)} collections total.`);
      return;
    }
    setPosting(true);
    try {
      const today = format(new Date(), 'yyyy-MM-dd');
      for (const loan of active) {
        const amount = Number(selected[loan.id]);
        if (!amount) continue;
        await postPayment(loan, {
          amount,
          payment_date: today,
          collected_by: fullName(user),
          method: 'cash',
          remarks: 'Bulk collection at center',
        });
      }
      await logAudit({
        user,
        action: 'Bulk collection posted',
        entity_type: 'Payment',
        entity_id: '',
        reference: `${count} account${count === 1 ? '' : 's'}`,
        details: `Cash receipt ${peso(receipt)} · collected ${peso(total)}`,
        amount: total,
      });
      setPosted({ count, total, receipt, change: receipt - total });
      setSelected({});
      setCash('');
      await onPosted?.();
    } catch (err) {
      setError('Some collections could not be posted. Please try again.');
    } finally {
      setPosting(false);
    }
  };

  return (
    <section className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 font-heading text-lg font-semibold">
            <ClipboardList className="h-4 w-4 text-primary" /> Collection summary
          </h2>
          <p className="text-[11px] text-muted-foreground">
            Tick clients, enter the total cash receipt, and every payment posts to their account.
          </p>
        </div>
        <button
          type="button"
          onClick={selectAllDue}
          className="shrink-0 text-xs font-medium text-primary hover:underline"
        >
          Select all
        </button>
      </div>

      <div className="mt-3 max-h-72 space-y-1.5 overflow-y-auto pr-1">
        {rows.map(({ loan, suggested }) => {
          const on = selected[loan.id] !== undefined;
          return (
            <div
              key={loan.id}
              className={`flex items-center gap-2.5 rounded-xl border px-2.5 py-2 transition ${
                on ? 'border-primary/40 bg-primary/5' : 'border-border'
              }`}
            >
              <input
                type="checkbox"
                checked={on}
                onChange={() => toggle(loan)}
                className="h-4 w-4 shrink-0 accent-[hsl(var(--primary))]"
                aria-label={`Collect from ${loan.borrower_name}`}
              />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{loan.borrower_name}</p>
                <p className="truncate text-[11px] text-muted-foreground">
                  {loan.loan_no} · bal {peso(payableOf(loan))}
                </p>
              </div>
              <Input
                type="number"
                step="0.01"
                value={on ? selected[loan.id] : ''}
                placeholder={suggested ? suggested.toFixed(0) : '0'}
                onChange={(event) => setAmount(loan.id, event.target.value)}
                onFocus={() => !on && toggle(loan)}
                className="h-8 w-24 text-right tabular-nums"
              />
            </div>
          );
        })}
        {!rows.length && (
          <p className="rounded-xl bg-muted/50 px-3 py-3 text-xs text-muted-foreground">
            No released loan to collect on yet.
          </p>
        )}
      </div>

      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        <div className="rounded-xl bg-muted/60 px-3 py-2.5">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
            Collections total
          </p>
          <p className="font-heading text-lg font-semibold tabular-nums">{peso(total)}</p>
          <p className="text-[11px] text-muted-foreground">
            {count} client{count === 1 ? '' : 's'} selected
          </p>
        </div>
        <div>
          <Label htmlFor="cash">Total cash received</Label>
          <Input
            id="cash"
            type="number"
            step="0.01"
            value={cash}
            onChange={(event) => setCash(event.target.value)}
            placeholder={total ? total.toFixed(2) : '0.00'}
            className="mt-1.5 tabular-nums"
          />
        </div>
      </div>

      {error && <p className="mt-2 text-xs text-destructive">{error}</p>}
      {posted && (
        <p className="mt-2 flex items-start gap-1.5 rounded-xl bg-emerald-50 px-3 py-2 text-[11px] text-emerald-800">
          <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          {posted.count} payment{posted.count === 1 ? '' : 's'} posted · collected {peso(posted.total)} · cash{' '}
          {peso(posted.receipt)} · change {peso(posted.change)}
        </p>
      )}

      <div className="mt-3 flex gap-2">
        <Button className="flex-1" onClick={post} disabled={posting || !count}>
          {posting ? 'Posting…' : 'Post collections'}
        </Button>
        <Button variant="outline" onClick={clear} disabled={posting || (!count && !cash)}>
          Clear
        </Button>
      </div>
    </section>
  );
}