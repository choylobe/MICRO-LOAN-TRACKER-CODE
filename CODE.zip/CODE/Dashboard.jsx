import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import LoanCard from '@/components/loans/LoanCard';
import StatusBadge from '@/components/loans/StatusBadge';
import { collectionPosition, isManager, officerCenters, peso, pesoShort } from '@/lib/loan';
import { canRecommend, ensureUserRole, isClient, roleMeta, userRole } from '@/lib/roles';
import RoleBadge from '@/components/RoleBadge';
import ClientHome from '@/pages/ClientHome';
import OfficerQueue from '@/components/dashboard/OfficerQueue';
import LoanStatusPanel from '@/components/dashboard/LoanStatusPanel';
import RepaymentPanel from '@/components/dashboard/RepaymentPanel';
import DisbursementPanel from '@/components/dashboard/DisbursementPanel';
import BulkCollection from '@/components/dashboard/BulkCollection';
import { format } from 'date-fns';
import { ArrowRight, ArrowUpRight, AlertTriangle, Clock, Plus, Wallet } from 'lucide-react';

function Stat({ label, value, hint, icon: Icon }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-center gap-1.5 text-muted-foreground">
        <Icon className="h-3.5 w-3.5" strokeWidth={1.75} />
        <p className="text-[10px] uppercase tracking-[0.12em]">{label}</p>
      </div>
      <p className="mt-2 font-heading text-2xl font-semibold leading-none tabular-nums">{value}</p>
      <p className="mt-1.5 text-[11px] text-muted-foreground">{hint}</p>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const [loans, setLoans] = useState(null);
  const [payments, setPayments] = useState([]);

  // Accounts invited without a role get one from their user record on first landing.
  useEffect(() => {
    ensureUserRole(user).catch(() => {});
  }, [user?.id, user?.staff_role]);

  const load = useCallback(async () => {
    if (isClient(user)) return;
    const [loanPage, paymentPage] = await Promise.all([
      base44.entities.Loan.filter({}, { sort: '-created_date', limit: 200 }),
      base44.entities.Payment.filter({}, { sort: '-payment_date', limit: 4 }),
    ]);
    const centers = userRole(user) === 'account_officer' ? officerCenters(user) : [];
    const scoped = centers.length
      ? loanPage.items.filter((loan) => centers.includes(loan.center_group))
      : loanPage.items;
    const scopedIds = new Set(scoped.map((loan) => loan.id));
    setLoans(scoped);
    setPayments(
      centers.length
        ? paymentPage.items.filter((payment) => scopedIds.has(payment.loan_id))
        : paymentPage.items
    );
  }, [user]);

  useEffect(() => {
    load();
  }, [load]);

  if (isClient(user)) return <ClientHome />;

  if (!loans) {
    return (
      <div className="space-y-4">
        <div className="h-32 animate-pulse rounded-2xl bg-muted" />
        <div className="grid grid-cols-2 gap-3">
          {[0, 1, 2, 3].map((key) => (
            <div key={key} className="h-24 animate-pulse rounded-2xl bg-muted" />
          ))}
        </div>
      </div>
    );
  }

  const active = loans.filter((loan) => loan.status === 'released');
  const pending = loans.filter((loan) => ['submitted', 'under_review'].includes(loan.status));
  const overdue = active.filter((loan) => collectionPosition(loan).isOverdue);
  const outstanding = active.reduce((sum, loan) => sum + Number(loan.outstanding_balance || 0), 0);
  const collected = active.reduce((sum, loan) => sum + Number(loan.amount_paid || 0), 0);
  const portfolio = outstanding + collected;
  const collectedPct = portfolio > 0 ? Math.round((collected / portfolio) * 100) : 0;

  const queue = [...pending, ...active]
    .sort((a, b) => new Date(a.submitted_at || a.created_date) - new Date(b.submitted_at || b.created_date))
    .slice(0, 3);

  const officer = canRecommend(user);
  const manager = isManager(user);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
            {format(new Date(), 'EEEE, d MMMM')}
          </p>
          <h1 className="mt-1 font-heading text-[26px] font-semibold leading-tight">
            Good day, {(user?.full_name || 'Officer').split(' ')[0]}
          </h1>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <RoleBadge user={user} size="sm" />
            <span className="text-[11px] text-muted-foreground">San Isidro branch</span>
          </div>
          <p className="mt-2 max-w-xs text-[11px] leading-relaxed text-muted-foreground">
            Signed in as {roleMeta(user).label} · {roleMeta(user).summary}
          </p>
        </div>
        {!manager && (
          <Link
            to="/loans/new"
            className="hidden items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition hover:opacity-90 md:flex"
          >
            <Plus className="h-4 w-4" /> New application
          </Link>
        )}
      </div>

      {officer && (
        <div className="space-y-6">
          <OfficerQueue loans={loans} />
          <DisbursementPanel loans={loans} />
          <BulkCollection loans={active} user={user} onPosted={load} />
          <LoanStatusPanel loans={loans} />
          <RepaymentPanel loans={active} />
        </div>
      )}

      {manager && <DisbursementPanel loans={loans} />}

      <section className="overflow-hidden rounded-3xl bg-primary px-5 py-5 text-primary-foreground">
        <p className="text-[11px] uppercase tracking-[0.16em] text-primary-foreground/70">
          Portfolio outstanding
        </p>
        <p className="mt-1.5 font-heading text-4xl font-semibold leading-none tabular-nums">
          {peso(outstanding)}
        </p>
        <div className="mt-4 h-1.5 w-full overflow-hidden rounded-full bg-primary-foreground/20">
          <div className="h-full rounded-full bg-accent" style={{ width: `${collectedPct}%` }} />
        </div>
        <div className="mt-2 flex items-center justify-between text-[11px] text-primary-foreground/75">
          <span>{collectedPct}% of released value collected</span>
          <span>{active.length} active loans</span>
        </div>
      </section>

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat
          label="Awaiting action"
          value={pending.length}
          hint="Applications in the approval queue"
          icon={Clock}
        />
        <Stat label="Past due" value={overdue.length} hint="Active loans with arrears" icon={AlertTriangle} />
        <Stat
          label="Collected"
          value={pesoShort(collected)}
          hint="Across active loans"
          icon={Wallet}
        />
        <Stat
          label="Borrowers"
          value={new Set(loans.map((loan) => loan.borrower_id)).size}
          hint="Profiles with applications"
          icon={ArrowUpRight}
        />
      </section>

      <section className={officer ? 'hidden' : undefined}>
        <div className="mb-3 flex items-end justify-between">
          <h2 className="font-heading text-lg font-semibold">Needs your attention</h2>
          <Link to="/loans" className="flex items-center gap-1 text-xs font-medium text-primary">
            All loans <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          {queue.map((loan) => (
            <LoanCard key={loan.id} loan={loan} />
          ))}
          {!queue.length && (
            <p className="rounded-2xl border border-dashed border-border p-6 text-sm text-muted-foreground">
              Nothing in the queue. Every application has been processed.
            </p>
          )}
        </div>
      </section>

      <section>
        <h2 className="mb-3 font-heading text-lg font-semibold">Latest collections</h2>
        <div className="divide-y divide-border overflow-hidden rounded-2xl border border-border bg-card">
          {payments.map((payment) => (
            <div key={payment.id} className="flex items-center justify-between px-4 py-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{payment.borrower_name}</p>
                <p className="text-[11px] text-muted-foreground">
                  {payment.loan_no} · {payment.method} · {format(new Date(payment.payment_date), 'd MMM')}
                </p>
              </div>
              <p className="text-sm font-semibold tabular-nums text-emerald-700">
                +{peso(payment.amount)}
              </p>
            </div>
          ))}
          {!payments.length && (
            <p className="px-4 py-6 text-sm text-muted-foreground">
              No collections recorded yet. Open a released loan to post a payment.
            </p>
          )}
        </div>
      </section>

      <section className="rounded-2xl border border-border bg-card p-4">
        <div className="flex items-center gap-2">
          <StatusBadge status="released" size="sm" />
          <p className="text-xs text-muted-foreground">Workflow statuses in this app</p>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {['submitted', 'under_review', 'approved', 'released', 'closed', 'rejected'].map((status) => (
            <StatusBadge key={status} status={status} size="sm" />
          ))}
        </div>
      </section>
    </div>
  );
}