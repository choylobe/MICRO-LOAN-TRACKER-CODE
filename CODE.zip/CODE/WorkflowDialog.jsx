import React, { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';

export default function WorkflowDialog({
  open,
  onOpenChange,
  title,
  description,
  confirmLabel = 'Confirm',
  danger = false,
  remarksLabel = 'Remarks',
  remarksPlaceholder = 'Add notes for the record',
  required = false,
  onSubmit,
  children,
}) {
  const [remarks, setRemarks] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (open) {
      setRemarks('');
      setSaving(false);
      setError('');
    }
  }, [open]);

  const submit = async () => {
    if (required && !remarks.trim()) {
      setError('Remarks are required for this step.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      await onSubmit(remarks.trim());
      onOpenChange(false);
    } catch (err) {
      setError(err?.message || 'The action could not be completed.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md rounded-2xl">
        <DialogHeader>
          <DialogTitle className="font-heading">{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>

        <div className="space-y-4">
          {children}
          <div>
            <Label htmlFor="workflow-remarks">{remarksLabel}</Label>
            <Textarea
              id="workflow-remarks"
              value={remarks}
              onChange={(event) => setRemarks(event.target.value)}
              placeholder={remarksPlaceholder}
              rows={3}
              className="mt-1.5"
            />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button variant={danger ? 'destructive' : 'default'} onClick={submit} disabled={saving}>
            {saving ? 'Working…' : confirmLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}