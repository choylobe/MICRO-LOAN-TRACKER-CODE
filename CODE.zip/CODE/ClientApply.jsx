import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { CalendarDays, CheckCircle2, Wallet } from 'lucide-react';
import { format } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { isClient } from '@/lib/roles';
import {
  DEFAULT_INTEREST_RATE,
  addHistory,
  computeTerms,
  nextLoanNo,
  peso,
  renewalStatus,
} from '@/lib/loan';
import { logAudit } from '@/lib/audit';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const TYPES = [
  { key: 'new', label: 'New loan', hint: 'A fresh micro-loan application' },
  { key: 'renewal', label: 'Renewal', hint: 'Continues an existing loan on a new cycle' },
];

export default function ClientApply() {
  const { user } = useAuth();
  const [borrower, setBorrower] = useState(null);
  const [loans, setLoans] = useState(null);
  const [type, setType] = useState('new');
  const [amount, setAmount] = useState('');
  const [dateNeeded, setDateNeeded] = useState('');
  const [term, setTerm] = useState('6');
  const [purpose, setPurpose] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [filed, setFiled] = useState(null);

  useEffect(() => {
    (async () => {
      if (!user?.borrower_id) {
        setLoans([]);
        return;
      }
      const record = await base44.entities.Borrower.get(user.borrower_id).catch(() => null);
      setBorrower(record);
      const page = await base44.entities.Loan.filter(
        { borrower_id: user.borrower_id },
        { sort: '-created_date', limit: 20 }
      );
      setLoans(page.items);
    })();
  }, [user?.borrower_id]);

  const renewal = useMemo(() => renewalStatus(loans || []), [loans]);
  const terms = computeTerms({
    principal: Number(amount) || 0,
    interest_rate: DEFAULT_INTEREST_RATE,
    term_months: Number(term),
    payment_frequency: 'weekly',
  });

  if (!isClient(user)) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-6 text-sm text-muted-foreground">
        Loan applications from this window are for client accounts. Staff file applications from{' '}
        <Link to="/loans/new" className="font-medium text-primary">
          New application
        </Link>
        .
      </div>
    );
  }

  if (!loans) {
    return <div className="h-40 animate-pulse rounded-2xl bg-muted" />;
  }

  if (!borrower) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-6 text-sm text-muted-foreground">
        Your login is not linked to a client record yet. Ask your account officer to link it before
        filing an application.
      </div>
    );
  }

  const submit = async () => {
    setError('');
    const principal = Number(amount);
    if (!principal || principal <= 0) {
      setError('Enter the amount you need to apply for.');
      return;
    }
    if (!dateNeeded) {
      setError('Tell us the date you need the proceeds.');
      return;
    }
    if (type === 'renewal' && !renewal.eligible) {
      setError(renewal.reason);
      return;
    }
    setSaving(true);
    try {
      const loanNo = await nextLoanNo();
      const cycle = (loans?.length || 0) + 1;
      const created = await base44.entities.Loan.create({
        loan_no: loanNo,
        borrower_id: borrower.id,
        borrower_name: borrower.full_name,
        center_group: borrower.center_group || '',
        loan_product: type === 'renewal' ? 'Micro Loan — Renewal' : 'Micro Loan — Weekly',
        application_type: type,
        date_needed: dateNeeded,
        requested_by_client: true,
        principal,
        interest_rate: DEFAULT_INTEREST_RATE,
        term_months: Number(term),
        payment_frequency: 'weekly',
        purpose,
        status: 'submitted',
        risk_rating: 'medium',
        officer_name: '',
        loan_cycle: cycle,
        reloan_of: type === 'renewal' ? renewal.current?.id || '' : '',
        submitted_at: new Date().toISOString(),
        total_interest: terms.interest,
        total_payable: terms.total,
        installment_amount: terms.installment,
      });

      await addHistory(created, 'submitted', 'Client loan application filed', {
        remarks: `${type === 'renewal' ? 'Renewal' : 'New loan'} · ${peso(principal)} · needed ${dateNeeded}`,
        actor: borrower.full_name,
      });
      await logAudit({
        user,
        actor_name: borrower.full_name,
        actor_role: 'client',
        action: 'Client loan application filed',
        entity_type: 'Loan',
        entity_id: created.id,
        reference: loanNo,
        details: `${type === 'renewal' ? 'Renewal' : 'New loan'} · needed ${dateNeeded} · center ${borrower.center_group || 'Walk-in'}`,
        amount: principal,
      });

      const response = await base44.functions
        .invoke('notifyOfficer', { loan_id: created.id })
        .catch(() => null);

      setFiled({
        loan_no: loanNo,
        type,
        amount: principal,
        dateNeeded,
        officer: response?.data?.officer || '',
      });
    } catch (err) {
      setError('Your application could not be filed. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  if (filed) {
    return (
      <div className="space-y-4">
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-emerald-900">
          <p className="flex items-center gap-2 text-sm font-semibold">
            <CheckCircle2 className="h-4 w-4" /> Application submitted
          </p>
          <p className="mt-1 text-xs">
            {filed.officer
              ? `${filed.officer} has been emailed and it now shows in their desk for CI.`
              : 'Your branch will assign an account officer for CI.'}
          </p>
        </div>

        <section className="rounded-2xl border border-border bg-card p-4">
          <h2 className="font-heading text-base font-semibold">Application summary</h2>
          <div className="mt-2 divide-y divide-border">
            <div className="flex items-center justify-between py-2">
              <span className="text-xs text-muted-foreground">Loan type</span>
              <span className="text-sm font-medium">
                {filed.type === 'renewal' ? 'Renewal' : 'New loan'}
              </span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-xs text-muted-foreground">Applied amount</span>
              <span className="text-sm font-medium tabular-nums">{peso(filed.amount)}</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-xs text-muted-foreground">Date needed</span>
              <span className="text-sm font-medium">
                {format(new Date(filed.dateNeeded), 'd MMM yyyy')}
              </span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-xs text-muted-foreground">Reference</span>
              <span className="text-sm font-medium">{filed.loan_no}</span>
            </div>
          </div>
        </section>

        <Button asChild className="w-full">
          <Link to="/">Back to my loan</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-heading text-[26px] font-semibold leading-tight">Apply for a loan</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {borrower.full_name} · {borrower.borrower_no} · {borrower.center_group || 'Walk-in'}
        </p>
      </div>

      <section className="rounded-2xl border border-border bg-card p-4">
        <Label>Loan type</Label>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {TYPES.map((option) => (
            <button
              key={option.key}
              type="button"
              onClick={() => {
                setType(option.key);
                setError('');
                if (option.key === 'renewal' && !renewal.eligible) setError(renewal.reason);
              }}
              className={`rounded-xl border px-3 py-2.5 text-left transition ${
                type === option.key
                  ? 'border-primary bg-primary/5'
                  : 'border-border hover:bg-muted/50'
              }`}
            >
              <p className="text-sm font-medium">{option.label}</p>
              <p className="mt-0.5 text-[11px] text-muted-foreground">{option.hint}</p>
            </button>
          ))}
        </div>
        {type === 'renewal' && (
          <p
            className={`mt-2 rounded-xl px-3 py-2 text-[11px] ${
              renewal.eligible
                ? 'bg-emerald-50 text-emerald-800'
                : 'bg-rose-50 text-rose-700'
            }`}
          >
            {renewal.eligible
              ? `Renewable — the running balance ${peso(renewal.balance)} is within 30% of the ${peso(renewal.current.principal)} principal.`
              : renewal.reason || 'This loan is not yet renewable.'}
          </p>
        )}

        <div className="mt-4 grid grid-cols-2 gap-2">
          <div className="col-span-2">
            <Label htmlFor="amount">Amount applied for</Label>
            <Input
              id="amount"
              type="number"
              inputMode="decimal"
              value={amount}
              onChange={(event) => setAmount(event.target.value)}
              placeholder="15000"
              className="mt-1.5"
            />
          </div>
          <div>
            <Label htmlFor="needed">Date needed</Label>
            <Input
              id="needed"
              type="date"
              value={dateNeeded}
              onChange={(event) => setDateNeeded(event.target.value)}
              className="mt-1.5"
            />
          </div>
          <div>
            <Label>Term</Label>
            <Select value={term} onValueChange={setTerm}>
              <SelectTrigger className="mt-1.5">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="6">6 months · weekly</SelectItem>
                <SelectItem value="12">12 months · weekly</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <Label htmlFor="purpose">Purpose</Label>
            <Textarea
              id="purpose"
              rows={2}
              value={purpose}
              onChange={(event) => setPurpose(event.target.value)}
              placeholder="Additional stock for my sari-sari store"
              className="mt-1.5"
            />
          </div>
        </div>
      </section>

      <section className="rounded-2xl bg-primary px-4 py-4 text-primary-foreground">
        <div className="flex items-center gap-2">
          <Wallet className="h-4 w-4 opacity-80" />
          <p className="text-[11px] uppercase tracking-[0.14em] text-primary-foreground/70">
            Application summary
          </p>
        </div>
        <div className="mt-2 flex items-end justify-between gap-3">
          <div>
            <p className="text-xs text-primary-foreground/80">
              {type === 'renewal' ? 'Renewal' : 'New loan'}
            </p>
            <p className="font-heading text-2xl font-semibold leading-tight tabular-nums">
              {peso(amount || 0)}
            </p>
          </div>
          <div className="text-right text-[11px] text-primary-foreground/75">
            <p className="flex items-center justify-end gap-1">
              <CalendarDays className="h-3 w-3" />
              {dateNeeded ? format(new Date(dateNeeded), 'd MMM yyyy') : 'date needed'}
            </p>
            <p className="mt-0.5">
              approx. {peso(terms.installment)} / week · {peso(terms.total)} total
            </p>
          </div>
        </div>
      </section>

      {error && <p className="rounded-xl bg-rose-50 px-3 py-2 text-xs text-rose-700">{error}</p>}

      <div className="flex gap-2">
        <Button asChild variant="outline" className="flex-1">
          <Link to="/">Cancel</Link>
        </Button>
        <Button className="flex-1" onClick={submit} disabled={saving}>
          {saving ? 'Submitting…' : 'Submit application'}
        </Button>
      </div>
      <p className="text-[11px] text-muted-foreground">
        Filing sends a notice to your account officer for credit investigation. The final amount and
        deductions appear in your Loan Disclosure Agreement for your signature.
      </p>
    </div>
  );
}